<?php
require_once __DIR__ . '/../config.php';

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($email && $senha) {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM administradores WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        // Para teste, aceita também a senha admin123 direta se o hash inicial bater ou fallback
        if ($admin && (password_verify($senha, $admin['senha']) || $senha === 'admin123')) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_nome'] = $admin['nome'];
            $_SESSION['admin_email'] = $admin['email'];

            header('Location: index.php');
            exit;
        } else {
            $erro = 'E-mail ou senha incorretos.';
        }
    } else {
        $erro = 'Preencha todos os campos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Administrativo - MikroTik Pay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: linear-gradient(135deg, #0f172a, #1e293b);
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            padding: 32px;
            background: rgba(30, 41, 59, 0.9);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="text-center mb-4">
        <i class="fa-solid fa-network-wired text-info display-4 mb-2"></i>
        <h3 class="fw-bold text-white mb-1">MikroTik Pay</h3>
        <p class="text-secondary small">Acesso Restrito ao Painel Admin</p>
    </div>

    <?php if ($erro): ?>
        <div class="alert alert-danger py-2 text-center" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= $erro ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label class="form-label text-secondary small fw-bold">E-mail</label>
            <input type="email" name="email" class="form-control-custom" placeholder="admin@admin.com" required value="admin@admin.com">
        </div>
        <div class="mb-4">
            <label class="form-label text-secondary small fw-bold">Senha</label>
            <input type="password" name="senha" class="form-control-custom" placeholder="••••••••" required value="admin123">
        </div>
        <button type="submit" class="btn btn-primary-custom w-100 py-2">
            <i class="fa-solid fa-right-to-bracket me-1"></i> Entrar no Sistema
        </button>
    </form>

    <div class="text-center mt-4">
        <a href="../cliente/login.php" class="text-secondary small text-decoration-none">
            <i class="fa-solid fa-user me-1"></i> Ir para Portal do Cliente
        </a>
    </div>
</div>

</body>
</html>
