<?php
require_once __DIR__ . '/../config.php';
unset($_SESSION['admin_id']);
unset($_SESSION['admin_nome']);
unset($_SESSION['admin_email']);
session_destroy();
header('Location: login.php');
exit;
