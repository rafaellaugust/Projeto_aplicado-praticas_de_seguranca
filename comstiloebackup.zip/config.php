<?php
/**
 * Configuração Geral do Sistema & Conexão com Banco de Dados
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configurações do Banco de Dados MySQL / MariaDB
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'spaconet_aplicacao');
define('DB_USER', 'spaconet_aplicacao');
define('DB_PASS', 'B8XJJnt6VTy9Kvx3mU4s');
define('DB_CHAR', 'utf8mb4');

// Timezone
date_default_timezone_set('America/Sao_Paulo');

// Autoload de classes do diretório /src
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/src/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// URL Base do Sistema - Permite forçar manualmente aqui caso deseje
if (!defined('CUSTOM_APP_URL')) {
    define('CUSTOM_APP_URL', ''); // Opcional: preencha caso queira forçar via arquivo (ex: 'https://mk.spaconett.com')
}

/**
 * Retorna a URL Base do Sistema de forma flexível:
 * 1. Se CUSTOM_APP_URL estiver preenchido no config.php, usa ele;
 * 2. Se houver 'app_url' configurado no Banco de Dados (admin/configuracoes.php), usa ele;
 * 3. Se for acesso web via navegador, detecta automaticamente protocolo (HTTP/HTTPS) e host atual;
 * 4. Fallback padrão seguro para scripts de linha de comando (CLI / Cron).
 */
function getSystemBaseUrl(): string {
    static $cachedUrl = null;
    if ($cachedUrl !== null) {
        return $cachedUrl;
    }

    // 1. Forçado no config.php
    if (defined('CUSTOM_APP_URL') && !empty(CUSTOM_APP_URL)) {
        $cachedUrl = rtrim(CUSTOM_APP_URL, '/');
        return $cachedUrl;
    }

    // 2. Busca na tabela de configuracoes
    try {
        if (class_exists('Database')) {
            $db = Database::getInstance();
            $dbUrl = $db->query("SELECT app_url FROM configuracoes WHERE id = 1")->fetchColumn();
            if (!empty($dbUrl)) {
                $cachedUrl = rtrim($dbUrl, '/');
                return $cachedUrl;
            }
        }
    } catch (Exception $e) {
        // Segue para detecção automática
    }

    // 3. Detecção automática pelo cabeçalho HTTP da requisição atual
    if (!empty($_SERVER['HTTP_HOST'])) {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
            || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
        $protocol = $isHttps ? 'https' : 'http';
        $host = preg_replace('#^https?://#', '', $_SERVER['HTTP_HOST']);
        $cachedUrl = $protocol . '://' . rtrim($host, '/');
        return $cachedUrl;
    }

    // 4. Fallback padrão
    $cachedUrl = 'https://aplicacao.spaconett.com';
    return $cachedUrl;
}

if (!defined('BASE_URL')) {
    define('BASE_URL', getSystemBaseUrl());
}

/**
 * Função Auxiliar para Sanitização de Input
 */
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Função Auxiliar para Formatar Moeda (R$)
 */
function formatMoeda($valor) {
    return 'R$ ' . number_format((float)$valor, 2, ',', '.');
}

/**
 * Função Auxiliar para Formatar Data Brasileira
 */
function formatData($dataStr) {
    if (!$dataStr) return '-';
    $timestamp = strtotime($dataStr);
    return date('d/m/Y', $timestamp);
}

/**
 * Funções de Sessão e Autenticação
 */
function checkAdminLogin() {
    if (empty($_SESSION['admin_id'])) {
        header('Location: ' . BASE_URL . '/admin/login.php');
        exit;
    }
}

function checkClienteLogin() {
    if (empty($_SESSION['cliente_id'])) {
        header('Location: ' . BASE_URL . '/cliente/login.php');
        exit;
    }
}
