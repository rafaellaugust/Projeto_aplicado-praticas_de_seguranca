<?php
require_once __DIR__ . '/../config.php';
unset($_SESSION['cliente_id']);
unset($_SESSION['cliente_nome']);
unset($_SESSION['cliente_pppoe']);
session_destroy();
header('Location: login.php');
exit;
