-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 14-Set-2026 às 10:43
-- Versão do servidor: 8.0.46
-- versão do PHP: 8.1.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dados: `spaconet_aplicacao`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `administradores`
--

CREATE TABLE `administradores` (
  `id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `administradores`
--

INSERT INTO `administradores` (`id`, `nome`, `email`, `senha`, `criado_em`) VALUES
(1, 'Administrador', 'admin@admin.com', '$2y$10$wT8fS03G00m.8w6/qY4l8u7Z3Zz5k4X4y6Z7W8v9U0t1S2R3Q4P5O', '2026-08-19 15:50:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int NOT NULL,
  `nome` varchar(150) NOT NULL,
  `cpf_cnpj` varchar(20) NOT NULL,
  `whatsapp` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `endereco` text,
  `pppoe_usuario` varchar(100) NOT NULL,
  `pppoe_senha` varchar(100) NOT NULL,
  `plano_id` int DEFAULT NULL,
  `roteador_id` int DEFAULT '1',
  `status` enum('ativo','suspenso','cancelado','aviso') DEFAULT 'ativo',
  `vencimento_dia` int DEFAULT '10',
  `data_expiracao` date DEFAULT NULL,
  `sincronizado_mikrotik` tinyint(1) DEFAULT '0',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `cpf_cnpj`, `whatsapp`, `email`, `endereco`, `pppoe_usuario`, `pppoe_senha`, `plano_id`, `roteador_id`, `status`, `vencimento_dia`, `data_expiracao`, `sincronizado_mikrotik`, `criado_em`) VALUES
(184, 'ppp8', '99991445196', '8299334425', '', '', 'ppp8', '12345', 10, 1, 'ativo', 10, NULL, 1, '2026-09-08 13:56:29'),
(185, 'ppp7', '99974716599', '8296934434', '', '', 'ppp7', '12345', 3, 1, 'ativo', 10, '2026-10-10', 1, '2026-09-08 13:56:29');

-- --------------------------------------------------------

--
-- Estrutura da tabela `configuracoes`
--

CREATE TABLE `configuracoes` (
  `id` int NOT NULL DEFAULT '1',
  `empresa_nome` varchar(150) DEFAULT 'Meu Provedor ISP',
  `empresa_cnpj` varchar(20) DEFAULT '',
  `empresa_telefone` varchar(20) DEFAULT '',
  `wa_api_url` varchar(255) DEFAULT 'http://localhost:21465',
  `wa_session` varchar(100) DEFAULT 'default',
  `wa_token` varchar(255) DEFAULT '',
  `wa_status` tinyint(1) DEFAULT '0',
  `telegram_bot_token` varchar(255) DEFAULT '',
  `telegram_chat_id` varchar(100) DEFAULT '',
  `telegram_ativo` tinyint(1) DEFAULT '0',
  `gateway_provider` varchar(50) DEFAULT 'mercadopago',
  `mp_public_key` varchar(255) DEFAULT '',
  `mp_access_token` varchar(255) DEFAULT '',
  `mp_client_id` varchar(100) DEFAULT '',
  `mp_client_secret` varchar(255) DEFAULT '',
  `mp_sandbox` tinyint(1) DEFAULT '0',
  `asaas_api_key` varchar(255) DEFAULT '',
  `pix_chave_estatica` varchar(255) DEFAULT 'financeiro@spaconett.com',
  `pix_nome_beneficiario` varchar(100) DEFAULT 'SPACONETT PROVEDOR',
  `pix_cidade_beneficiario` varchar(100) DEFAULT 'SAO PAULO',
  `webhook_secret` varchar(100) DEFAULT 'secret123',
  `atualizado_em` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `webhook_callback_url` varchar(255) DEFAULT NULL,
  `webhook_callback_ativo` tinyint(1) DEFAULT '0',
  `wa_disparo_hora` varchar(5) DEFAULT '08:00',
  `wa_disparo_delay` int DEFAULT '5',
  `wa_disparo_ativo` tinyint(1) DEFAULT '0',
  `wa_disparo_dias` int DEFAULT '3',
  `wa_ultimo_disparo` date DEFAULT NULL,
  `wa_modelo_mensagem` text,
  `wa_delay_pix` int DEFAULT '2',
  `wa_modelo_confirmacao` text,
  `wa_aviso_ativo` tinyint(1) DEFAULT '1',
  `wa_aviso_tolerancia` int DEFAULT '5',
  `wa_modelo_aviso` text,
  `app_url` varchar(255) DEFAULT 'https://aplicacao.spaconett.com'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `configuracoes`
--

INSERT INTO `configuracoes` (`id`, `empresa_nome`, `empresa_cnpj`, `empresa_telefone`, `wa_api_url`, `wa_session`, `wa_token`, `wa_status`, `telegram_bot_token`, `telegram_chat_id`, `telegram_ativo`, `gateway_provider`, `mp_public_key`, `mp_access_token`, `mp_client_id`, `mp_client_secret`, `mp_sandbox`, `asaas_api_key`, `pix_chave_estatica`, `pix_nome_beneficiario`, `pix_cidade_beneficiario`, `webhook_secret`, `atualizado_em`, `webhook_callback_url`, `webhook_callback_ativo`, `wa_disparo_hora`, `wa_disparo_delay`, `wa_disparo_ativo`, `wa_disparo_dias`, `wa_ultimo_disparo`, `wa_modelo_mensagem`, `wa_delay_pix`, `wa_modelo_confirmacao`, `wa_aviso_ativo`, `wa_aviso_tolerancia`, `wa_modelo_aviso`, `app_url`) VALUES
(1, 'SpacoNett', '', '82999334425', 'http://aplicacao.spaconett.com/whatsapp', 'default', '81660848', 0, '1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0', '-494177619', 1, 'mercadopago', '', 'APP_USR-5748377013323719-120822-e8a932a0e159f5aa5925cab3764e776d-142008628', '', '', 0, '', '82999334425', 'RAFAEL AUGUSTO DA CONCEICAO', 'Arapiraca', 'secret123', '2026-09-14 11:17:58', 'https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;amp;amp;text=foi', 1, '11:15', 5, 1, 1, '2026-09-11', '🔔 *FATURA DISPONÍVEL - {EMPRESA_NOME}*\r\n\r\nOlá, *{NOME_CLIENTE}*!\r\nSua fatura de internet já está disponível para pagamento.\r\n\r\n💰 *Valor:* {VALOR_FATURA}\r\n📅 *Vencimento:* {DATA_VENCIMENTO}\r\n\r\n🔗 *Acesse sua fatura online:* {LINK_FATURA}\r\n\r\nObrigado por utilizar nossos serviços!', 5, '✅ *PAGAMENTO CONFIRMADO!*\r\n\r\nOlá, *{NOME_CLIENTE}*!\r\nConfirmamos o recebimento do seu pagamento no valor de *{VALOR_FATURA}* referente à fatura #{FATURA_ID}.\r\n\r\n🔗 *Acesse seu histórico de faturas online:* \r\nEm : https://aplicacao.spaconett.com\r\n\r\nSeu acesso à internet continua ativo. Agradecemos a preferência!', 1, 4, '⚠️ *AVISO DE VENCIMENTO - ALERTA DE BLOQUEIO*\r\n\r\nOlá, *{NOME_CLIENTE}*!\r\nIdentificamos que sua fatura no valor de *{VALOR_FATURA}* com vencimento em *{DATA_VENCIMENTO}* continua pendente.\r\n\r\nO seu acesso entrará em *bloqueio automático* caso o pagamento não seja identificado.\r\n\r\n🔗 *Acesse sua fatura online:* {LINK_FATURA}\r\n\r\nPara evitar o suspenção do sinal, efetue o pagamento pelo PIX Copia e Cola abaixo:', 'https://graf.spaconett.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `faturas`
--

CREATE TABLE `faturas` (
  `id` int NOT NULL,
  `cliente_id` int NOT NULL,
  `plano_id` int DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `meses_cobertos` int NOT NULL DEFAULT '1',
  `data_vencimento` date NOT NULL,
  `data_pagamento` datetime DEFAULT NULL,
  `status` enum('pendente','pago','atrasado','cancelado') DEFAULT 'pendente',
  `forma_pagamento` varchar(50) DEFAULT 'PIX',
  `pix_txid` varchar(100) DEFAULT NULL,
  `pix_copia_cola` text,
  `qr_code` text,
  `pix_qr_code_base64` longtext,
  `gateway_id` varchar(100) DEFAULT NULL,
  `mp_payment_id` varchar(100) DEFAULT NULL,
  `gateway_status` varchar(50) DEFAULT 'pending',
  `expiration_date` datetime DEFAULT NULL,
  `external_reference` varchar(255) DEFAULT NULL,
  `notificado_wa` tinyint(1) DEFAULT '0',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  `notificado_aviso` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `faturas`
--

INSERT INTO `faturas` (`id`, `cliente_id`, `plano_id`, `valor`, `descricao`, `meses_cobertos`, `data_vencimento`, `data_pagamento`, `status`, `forma_pagamento`, `pix_txid`, `pix_copia_cola`, `qr_code`, `pix_qr_code_base64`, `gateway_id`, `mp_payment_id`, `gateway_status`, `expiration_date`, `external_reference`, `notificado_wa`, `criado_em`, `notificado_aviso`) VALUES
(37, 184, 10, 1.00, 'Mensalidade 09/2026', 1, '2026-09-10', NULL, 'pendente', 'PIX', 'FATURA_37_371c40b2cb_1789391455', '00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter1789396824906304D717', '00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter1789396824906304D717', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX///8AAABVwtN+AAAKx0lEQVR42uzdQXLquhIGYFEMGLIElpKlwdJYSpaQIQMqfnXyEFK35ZDk3Btzq75/QuUcbH9m1tVSq4iIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIjIv5vdNMu5bMLfp9vfp/tF22l6LaX+/8dNPv6+tPu+TO/h8/jnm29/Pq+l7NvNP/7zMEfQ0tLS0tLS0tLS0tLS0v4D2tf09/nP58cN32//uGkPqg8ON66vfPmjy3kPF51uNz/dlKX/bK9KS0tLS0tLS0tLS0tL+8Ta8OBa857vX9qEcvV0r3n/r/9QhrK11r77BW0tnKdeG1+ZlpaWlpaWlpaWlpaW9r+orU3OruZtD9jeCubdvOkZOqf7VutO91fONS8tLS0tLS0tLS0tLS3tf1T7/xuf07rbtoR2uim30yi1+fnx5Ze+g7rvv3alpaWlpaWlpaWlpaWlpf0FbVotvEkPeG/93bd+tfB1fpOXvkLvyvtyv2m35Pi1L/d/vLaZlpaWlpaWlpaWlpaW9je1w8lFb32L9pPVwoc0ueilbxZ/4yZ/N2eJlpaWlpaWlpaWlpaW9ne0w2xCmXqaTS7Kq4ZjzdsSat33tlq4jArnH4eWlpaWlpaWlpaWlpb2N7WHtu42POil75x2OS6UqWFyUV53245i2YZFveGiw6P1t7S0tLS0tLS0tLS0tLTravP6267mDUOHym3X5luZncU53ZbS1nFHbexRTV7E211Uf69wk4mWlpaWlpaWlpaWlpaW9u+1Ya9p3nMaW7bt2JZtuGE942WoDZV6bhKXdnDM1/ac0tLS0tLS0tLS0tLS0q6rjTVvOPTzfF8lPIXWbHhQGF07pVd+65vD76kGrs3ia+vvHr6wQ5aWlpaWlpaWlpaWlpb2CbRdzdtWB8cHltT0bJ+X8jDHz/achs7pV1YL09LS0tLS0tLS0tLS0q6j7c4weUnbRUPN233Oa96uYM57TcORLCUV0Id+He6OlpaWlpaWlpaWlpaWlvZf0CZl3CY6zQbwDhb6HtrFt4p9M19q/Nb6vKd+42roNOcNq7S0tLS0tLS0tLS0tLTPqr3VvrVcLQvTeqd26Odwz+mldOOP4p7TPP5ovk559/nkIlpaWlpaWlpaWlpaWtoVtd3/vYy2j5ZUvk59udpph4Vzt+T4uFg4f6dzSktLS0tLS0tLS0tLS7u69nVUrobEcvXYr7vNJ4jm01Na4Ty1iz+dXERLS0tLS0tLS0tLS0tL+89oSxu4Ox+0u7lV5Hnhb37QcMFvd/xo6VcJ59XC1293pWlpaWlpaWlpaWlpaWnX0uY+byhXN23IUH1A0NbjWXah7K03S6uF88Ex3WrhWus+DC0tLS0tLS0tLS0tLe3q2to5nWZN0PFC37bnNGpDzTvdtXXubdd+rUuOPy7aphp398nkIlpaWlpaWlpaWlpaWtp1tcPvbIZLaU/90KFpmtr821rzXlITtCxoh5OL8k9AS0tLS0tLS0tLS0tL+9Ta0ARdWjobFu0OjtM89+tvp9EuzsHkokHhTEtLS0tLS0tLS0tLS0v7t9pdq5OX5gXNW7T1QXFa78LG1fyq2wfN4gd7TmlpaWlpaWlpaWlpaWlX1JbQmk3zbuuDNm2vaWkt2mk2B7ee+XJpF5/7m4TmcPfK35l/S0tLS0tLS0tLS0tLS7uu9rB4AMom6I/9g7qOafu8LC89Pt0/t/MxR6F3+yC0tLS0tLS0tLS0tLS062rLaHJR1/T80O7bg053bd5zmscehQJ6E87iPJXBQZ7T6HejpaWlpaWlpaWlpaWlpf0bbaqPu5NDwzbRPGepS7fkOPR5hz9B6UcAX79dodPS0tLS0tLS0tLS0tKupd21Fu3LfdvoZrnmzdrc583Hj9acRjVv6Zcc7xZuQktLS0tLS0tLS0tLS/s82npN+M7mNv92CieHnvpDP1/TMS3z8UexcC73TuqUXnXQfn3Y56WlpaWlpaWlpaWlpaVdRxsrzWGTs6Ttop8unQ3t1yntPQ3zcLdh/u00feXkUFpaWlpaWlpaWlpaWlrar2s79XDO0tvtzJd9eouw5zTrL7djR8NNpvaq3WrhsOv1i31eWlpaWlpaWlpaWlpa2rW0u3nleS6fT+s93k8MvQ5fue05LWnjat1juu+n9v5kzyktLS0tLS0tLS0tLS3tatr6nbxd9NyXp2/9Z90mum01bndwTHjltmG1Zjs8hrQVzg9qXlpaWlpaWlpaWlpaWtp1ta+9etce0A5AKekUlXG5GrT14pekzR3U8MoPa19aWlpaWlpaWlpaWlra59J2eZnymZzXtg63K1PbZ/fK5/suznwUS0k3iYXzvPqmpaWlpaWlpaWlpaWlpf2ZttwW/nZnvrTieqmYvrY9p91xLW218NQvNc5jkLpX726afydaWlpaWlpaWlpaWlraJ9V25WoYOjSNVgl3/d685DhMLgrzb/cLG1cP6Savsw2rtLS0tLS0tLS0tLS0tE+ljeXq8PzOYzpd5Zianq1wntLC31Jmp6fkWvcnJ4fS0tLS0tLS0tLS0tLSrqtt20VrzVsWzubct38arrvNCUexVGU3/igs5i1fPTmUlpaWlpaWlpaWlpaWlvaxdrhdNKqy9nQbsDvdz36Z5sV1Ozm0tDlL3U1PM108fYaWlpaWlpaWlpaWlpb2ebXD74RBu8NpvVMYe1T7u7c/cuH8vtDf3aYxSLtP+ry0tLS0tLS0tLS0tLS062pzpZnPfFnaexrm3tby9dJ0Yf7txyt2c3A7bf6dvtznpaWlpaWlpaWlpaWlpV1Re+kf2B36WdrS2eOs6XkdFsytg7pfnoN7HGkPn0/ppaWlpaWlpaWlpaWlpaX9jrbr8577hb9v86m9bbto3CYajh19aZ9BPS00jYdLjr+yWpiWlpaWlpaWlpaWlpZ2Ne18lfBH6qDdTSpXp9Acng8fenTmS53a+/HkbVpyPD1c20xLS0tLS0tLS0tLS0u7ljZ3TsN20a5zGiYZ5WNbpnTo564vnPNS46XJRbX6vnyjz0tLS0tLS0tLS0tLS0v769p5v7LbLpoP/eyanvOhQ3lS0X55A2vo2dZXPXyh5qWlpaWlpaWlpaWlpaVdUTvQ52Zn0+Ylstt+3FGXy6jdGjunueZNF9PS0tLS0tLS0tLS0tLS/uPakhb65gfV/u7rvFlcK/TQ5y33yUXvrcwvfYV+HXacaWlpaWlpaWlpaWlpaZ9Ru5sXnef0gHZcy7WpD6nmfZ2d+VLCkuOmrjfplh4f2iuGMUi0tLS0tLS0tLS0tLS0z6d9nXVON/P5t9020ePs9JRc83bt1nZyaAk1b7vJNUloaWlpaWlpaWlpaWlpn10bHnxeWG87b3qOM69139r4o3CKymCIbi2caWlpaWlpaWlpaWlpaWn/FW2es7QZavNnmNZ7Hp35UpXdXtQ8Z+kHFTotLS0tLS0tLS0tLS3tutquRZun9Ya9p52y07YaNh83OrVRv6e057Rd/MMKnZaWlpaWlpaWlpaWlvbXtPPVwtNo/m0+MfS6oLy0E0Nb53RqG1f3aYjua1/7PjihhpaWlpaWlpaWlpaWlnZd7XxyURke9nnsP0Nzc5cuLk2bTxI93S/aLkwu+iy0tLS0tLS0tLS0tLS0tF/XioiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiDx1/hcAAP//sHnm7yqDq/wAAAAASUVORK5CYII=', '178939682490', '178939682490', 'pending', '2026-09-15 10:10:55', 'FATURA_37_371c40b2cb_1789391455', 0, '2026-09-10 12:25:46', 1),
(38, 185, 3, 1.00, 'Mensalidade 09/2026', 1, '2026-09-10', '2026-09-10 13:07:16', 'pago', 'PIX', 'FATURA_38_2c16d72811_1789055209', '00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter177326600029630449E1', '00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter177326600029630449E1', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX///8AAABVwtN+AAAKw0lEQVR42uzdQXLiyBIGYBEsWPoIHIWjwdF8FB3BSxaE9cJ+FJWZkoxn3GPoiO/fqJkB6ZN3GVmVNYiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIjIf5vdNMvrsLn+6/36pf9/Pn388+XjX5fP/9q+/3mT8ePzud/3cP1xux4/vvn2cb1cb9J+PAzDfo6gpaWlpaWlpaWlpaWlpf0D2rF8fr2ppqtyc33Q/x9YH9Bf+fyhqwna8Mqn602GeO2vSktLS0tLS0tLS0tLS/vE2vTgXvNW7eX64Fbztus51cC99n1Z0X5mm2re+sq0tLS0tLS0tLS0tLS0f532vde+CzXv5wPH3n7t19o5fSlt18Wal5aWlpaWlpaWlpaWlvYv1dbO6VCW0E5X5XZaSmt+fn75EDuoL/FrF1paWlpaWlpaWlpaWlraX9CW1cK1Qm9F9rZrp773NN3kECv0UN4Pt5te+quPsdz/12ubaWlpaWlpaWlpaWlpaX9Tuzi56C22aDdp6NDp2t/tZWuYXHSIzeJ/cJOfzVmipaWlpaWlpaWlpaWl/R3tYjapTF3bc5qanqHm7Um17nsanjsvnP91aGlpaWlpaWlpaWlpaX9Tu+/rbtODDrFzGnJcKVPT5KK67vZ0e/VtWtSbfrS/t/6WlpaWlpaWlpaWlpaW9uHatZo3DR0arrs2367XMT4obwG9tl9D6iLeNAc3HMmS9pPS0tLS0tLS0tLS0tLS0v5Y2+ritnq4nvkyxYlFocgebkV2OPOlalOlXpvE4eCYlAMtLS0tLS0tLS0tLS3tM2vn//GlbxudH/oZHpRG1zZleOXXW3P4vdTArVl86X+v/Tf2nNLS0tLS0tLS0tLS0tI+ULtLTc/r5/fUQe0PCBl7udoL5i9y/GrPaeqcnu/Ov6WlpaWlpaWlpaWlpaV9lHahX3koc3BTx/Qt1rz5IJTFvabpSJahFNBBOR+iS0tLS0tLS0tLS0tLS0v7Y22abtQq9Zf5iKQ+gDdoU0u27Tk9D2FKb1hqHMr9U9y4Opabvn7xN6WlpaWlpaWlpaWlpaV9Dm2vfVu5mvu7p1vLdkoP6ntO07WNP8p7Tuv4o3kBvfsHk4toaWlpaWlpaWlpaWlpf1cb/t+hLAiu20VTB7Vq9/M5uGnJ8bGMQarKf7a2mZaWlpaWlpaWlpaWlvZh2nHWr8zzb0/xgW/95NDaQa2177xwbj/+cnIRLS0tLS0tLS0tLS0tLe2f0Q594G4/rqXNV9okbWvRLmrHuFo43ORQpvSeZquF67Cm3TdmC9PS0tLS0tLS0tLS0tI+Rpv7vOnGrzftQtkaytV05stU+rm1edwPjtnOxx7dDS0tLS0tLS0tLS0tLe3DtWNsfqbVwq1j+l60OSsHx0yp5j3GPadtyfHnj7aL449oaWlpaWlpaWlpaWlpn1G7+J3NfArtSzxFZeEB08qG1UXt2uSi9Oq0tLS0tLS0tLS0tLS0T62dYhN0belsWrS7cJxmf1B45Vowv60ox7gOl5aWlpaWlpaWlpaWlpb2Z9pdr5PX5gXNW7TtQWG76L70efvG1fqq264e55V5/0xLS0tLS0tLS0tLS0v7fNqhP7BXoLXW3fS9pkNv0U5xglEYXbs4//Z0G6p7KU++LJ1dSktLS0tLS0tLS0tLS/us2n1Z4NsftEn6Y3xQ6pjmV15ceny6Xbcrte13VgnT0tLS0tLS0tLS0tLSPlw7LE0uCk3P6Tq56BQ7p/tevq6PPUoF9CadxXmKr5xypqWlpaWlpaWlpaWlpaX9g9r5dtG3+IApnRw6zIrsvOQ49XkX/wRDHPl7mQsO352zREtLS0tLS0tLS0tLS/u72jAv6HDbNrpZr3nf5n3efj3Pjx9tOS3VvENcchxOn7l7Qg0tLS0tLS0tLS0tLS3tY7Rhoe+h1LyHeGJoXeiblNPS+KNcOA+3TupUbpJrXlpaWlpaWlpaWlpaWtpn1uaatyyhrdtGF2rehaQfpZukebjbNP92ms3DpaWlpaWlpaWlpaWlpaX9mTao65ylnvd0+GdfLbxQXLdto628f41LjsOBMceiWm8W09LS0tLS0tLS0tLS0j6PdjevPF/LKuE+rTf0e8dycmh45TJ8KGun22rh7fqe0+Fen5eWlpaWlpaWlpaWlpb2YdrFeUELQ4fq6NpW+9aFvouvfLrdebt4DGlvx96peWlpaWlpaWlpaWlpaWkfqx2jelc6pa3ZGSYXrY2uTdpWKB+KtnZQU7v1bu1LS0tLS0tLS0tLS0tL+1zaYd70nNfAl/6V/fVH+1779iG6U1l/W282xsW8536zAy0tLS0tLS0tLS0tLS3tz7VDX/B7iBV6004rLdr9Vb2PJ4fuYp93k5rEw2xDa1tqfOnKFlpaWlpaWlpaWlpaWtrn1YZKcz4HN5SraYFvKpAXJhel+bdp4+qlX/flJuNswyotLS0tLS0tLS0tLS3tU2nreZ2p6ZkX+Cb9OFfPF/4utl/zK6fCOUloaWlpaWlpaWlpaWlpn1IbKs30oFr71nW4i+tua/r62/fUfp0fxZJfmZaWlpaWlpaWlpaWlpb2D2inCFh4YNXOz3yZ5sV1Pzl06HOW0vCmbTptpp4+Q0tLS0tLS0tLS0tLS/uk2rHs9DxcdWnQbjjssx/6OaWxR71wnqYwrXdKn4d4k9YsHuO65d3dPi8tLS0tLS0tLS0tLS3to7RDmTq7i0OHwtkvde9pmns79LbrIXZMw/V066Be0hkwtcb9uualpaWlpaWlpaWlpaWlfay2jq49X2vdoV+Pt2trerYbtzm4Cw9sHdO1ObjH0natr05LS0tLS0tLS0tLS0tL+1NtfkC68SFW6K01W+cs1T5vahbXab0LTePFJcfTvRNqaGlpaWlpaWlpaWlpaR+jDauFh7hd9DNt0G4+QbRpp3JN/d4vz3xpU3s/a9z6ytP31jbT0tLS0tLS0tLS0tLSPky7sl00q/vZL/fK1F0snOtS49p+zZ3TuyeH0tLS0tLS0tLS0tLS0j5WO39g2C7aDkBZa3qu7TntG1brNazD3ffxR58/3n+j5qWlpaWlpaWlpaWlpaV9oHZBX5udPXXubT6Ls+cc265D2Qq6PLmo/JiWlpaWlpaWlpaWlpaW9o9rh7LQd5j3dxePaUkHx+xiJV5H/176c/bxc+4409LS0tLS0tLS0tLS0j6jdjcvOuuZL72/O/SyNS30DQ86lFZtWnIcXjn9CULh3K+0tLS0tLS0tLS0tLS0T6kdZ53TTZl/mzuox1j7TvOatx/F8hJPDh1SzXu8HcFyKRJaWlpaWlpaWlpaWlraZ9em8rWvv53Wm551PW7auBpeefhq4+pY1t+GwpmWlpaWlpaWlpaWlpaW9j/R5jlLtUXbVwnna1rou35y6DbtRV2cszTR0tLS0tLS0tLS0tLS/kXaobdo241rizZtGz2nqb39Jqk5PF37vdve9w193n7qzL+s0GlpaWlpaWlpaWlpaWl/TTtfLTyVVcIvZXJR2C5ajh2d+t7T1DltJ4deUlt2iB3Udv3qhBpaWlpaWlpaWlpaWlrax2rnk4uGxcM+j/E6lRo3FcxD19aTRE+zxbt1ctFXoaWlpaWlpaWlpaWlpaX9vlZERERERERERERERERERERERERERERERERERETkqfO/AAAA//9f3Dzo1Qy2EgAAAABJRU5ErkJggg==', '177326600029', '177326600029', 'approved', '2026-09-11 12:46:50', 'FATURA_38_2c16d72811_1789055209', 1, '2026-09-10 12:25:46', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `historico_pagamentos`
--

CREATE TABLE `historico_pagamentos` (
  `id` int NOT NULL,
  `cliente_id` int NOT NULL,
  `fatura_id` int DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `forma_pagamento` varchar(50) DEFAULT 'PIX',
  `data_pagamento` datetime DEFAULT CURRENT_TIMESTAMP,
  `comprovante_ref` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `historico_pagamentos`
--

INSERT INTO `historico_pagamentos` (`id`, `cliente_id`, `fatura_id`, `valor`, `forma_pagamento`, `data_pagamento`, `comprovante_ref`) VALUES
(16, 185, 38, 1.00, 'PIX', '2026-09-10 13:07:16', 'MP_177326600029');

-- --------------------------------------------------------

--
-- Estrutura da tabela `logs`
--

CREATE TABLE `logs` (
  `id` int NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `mensagem` text NOT NULL,
  `detalhes` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `logs`
--

INSERT INTO `logs` (`id`, `tipo`, `mensagem`, `detalhes`, `criado_em`) VALUES
(567, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 10:56:52'),
(568, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177035107434\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177035107434\",\"topic\":\"payment\"}}', '2026-09-03 11:16:44'),
(569, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177035107434\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"177035107434\"},\"date_created\":\"2026-09-03T14:16:43Z\",\"id\":137062140965,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-03 11:16:44'),
(570, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 11:16:44'),
(571, 'webhook', 'Consulta MP 177035107434 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1KT23YH5A5S37XQ7XGKPXRN\\\",\\\"id\\\":\\\"177035107434-001\\\",\\\"last_updated\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T10:16:43.738-04:00\\\",\\\"execution_id\\\":\\\"01M1KT23X55MH19DT2KTREZHRJ\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-03 11:16:44'),
(572, 'webhook', 'Consulta MP 177035107434 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1KT23YH5A5S37XQ7XGKPXRN\\\",\\\"id\\\":\\\"177035107434-001\\\",\\\"last_updated\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T10:16:43.738-04:00\\\",\\\"execution_id\\\":\\\"01M1KT23X55MH19DT2KTREZHRJ\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-03 11:16:44'),
(573, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 11:16:49'),
(574, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-03 12:02:52'),
(575, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-03 12:50:03'),
(576, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 12:56:32'),
(577, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 12:56:37'),
(578, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:08:36'),
(579, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:08:41'),
(580, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:10:52'),
(581, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:10:57'),
(582, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:16:09'),
(583, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:16:14'),
(584, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:24:26'),
(585, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 13:24:31'),
(586, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177066940168\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177066940168\",\"topic\":\"payment\"}}', '2026-09-03 13:53:42'),
(587, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177066940168\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"177066940168\"},\"date_created\":\"2026-09-03T16:53:42Z\",\"id\":137068464267,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-03 13:53:42'),
(588, 'webhook', 'Consulta MP 177066940168 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1M31HRX4XRCAA29A6G87F06\\\",\\\"id\\\":\\\"177066940168-001\\\",\\\"last_updated\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T12:53:42.311-04:00\\\",\\\"execution_id\\\":\\\"01M1M31HQKHSGKYYN19ANDHV0R\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-03 13:53:43'),
(589, 'webhook', 'Consulta MP 177066940168 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1M31HRX4XRCAA29A6G87F06\\\",\\\"id\\\":\\\"177066940168-001\\\",\\\"last_updated\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T12:53:42.311-04:00\\\",\\\"execution_id\\\":\\\"01M1M31HQKHSGKYYN19ANDHV0R\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-03 13:53:43'),
(590, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177066940168\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177066940168\",\"topic\":\"payment\"}}', '2026-09-03 14:51:06'),
(591, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177066940168\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"177066940168\"},\"date_created\":\"2026-09-03T16:53:42Z\",\"id\":137070729093,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-03 14:51:06'),
(592, 'webhook', 'Consulta MP 177066940168 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1M31HRX4XRCAA29A6G87F06\\\",\\\"id\\\":\\\"177066940168-001\\\",\\\"last_updated\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T12:53:42.311-04:00\\\",\\\"execution_id\\\":\\\"01M1M31HQKHSGKYYN19ANDHV0R\\\"}},\\\"collector_id\\\":142008628,\\\"corpo\"}', '2026-09-03 14:51:06'),
(593, 'webhook', 'Consulta MP 177066940168 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1M31HRX4XRCAA29A6G87F06\\\",\\\"id\\\":\\\"177066940168-001\\\",\\\"last_updated\\\":\\\"2026-09-03T12:53:42.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T12:53:42.311-04:00\\\",\\\"execution_id\\\":\\\"01M1M31HQKHSGKYYN19ANDHV0R\\\"}},\\\"collector_id\\\":142008628,\\\"corpo\"}', '2026-09-03 14:51:06'),
(594, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-10/Espera [R1]', NULL, '2026-09-03 14:51:07'),
(595, 'mikrotik', 'Webhook pagamento: ppp7 → S1-R.NORMAL-10/Espera (1 meses)', NULL, '2026-09-03 14:51:08'),
(596, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-10/Espera [R1]', NULL, '2026-09-03 14:51:12'),
(597, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-03 14:51:13'),
(598, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-03 14:51:14'),
(599, 'mikrotik', 'Webhook pagamento: ppp7 → S1-R.NORMAL-10/Espera (1 meses)', NULL, '2026-09-03 14:51:14'),
(600, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-03 14:51:14'),
(601, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-03 14:51:14'),
(602, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-03 14:51:14'),
(603, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-03 14:51:15'),
(604, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:00:05'),
(605, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:01:04'),
(606, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:02:04'),
(607, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:03:04'),
(608, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:04:04'),
(609, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:05:04'),
(610, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:06:04'),
(611, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:07:04'),
(612, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:08:04'),
(613, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:09:04'),
(614, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:10:04'),
(615, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:11:04'),
(616, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:12:04'),
(617, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:13:04'),
(618, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:14:04'),
(619, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:15:05'),
(620, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:16:04'),
(621, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:17:04'),
(622, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:18:04'),
(623, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:19:04'),
(624, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:20:04'),
(625, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:21:04'),
(626, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:22:04'),
(627, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:23:04'),
(628, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:24:04'),
(629, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:25:04'),
(630, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:26:04'),
(631, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:27:04'),
(632, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:28:04'),
(633, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:29:04'),
(634, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:30:05'),
(635, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:31:04'),
(636, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:32:04'),
(637, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:33:04'),
(638, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:34:04'),
(639, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:35:04'),
(640, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:36:04'),
(641, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:37:04'),
(642, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:38:04'),
(643, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:39:04'),
(644, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:40:04'),
(645, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:41:04'),
(646, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:42:04'),
(647, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:43:04'),
(648, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:44:04'),
(649, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:45:05'),
(650, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:46:04'),
(651, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:47:04'),
(652, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:48:04'),
(653, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:49:04'),
(654, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:50:04'),
(655, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:51:04'),
(656, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:52:04'),
(657, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:53:04'),
(658, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:54:04'),
(659, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:55:04'),
(660, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:56:04'),
(661, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:57:04'),
(662, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:58:04'),
(663, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-04 04:59:04'),
(664, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177035107434\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177035107434\",\"topic\":\"payment\"}}', '2026-09-04 11:21:56'),
(665, 'webhook', 'Consulta MP 177035107434 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1KT23YH5A5S37XQ7XGKPXRN\\\",\\\"id\\\":\\\"177035107434-001\\\",\\\"last_updated\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T10:16:43.738-04:00\\\",\\\"execution_id\\\":\\\"01M1KT23X55MH19DT2KTREZHRJ\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-04 11:21:56'),
(666, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177035107434\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"177035107434\"},\"date_created\":\"2026-09-03T14:16:43Z\",\"id\":137107488391,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-04 11:21:56'),
(667, 'webhook', 'Consulta MP 177035107434 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1KT23YH5A5S37XQ7XGKPXRN\\\",\\\"id\\\":\\\"177035107434-001\\\",\\\"last_updated\\\":\\\"2026-09-03T10:16:43.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-03T10:16:43.738-04:00\\\",\\\"execution_id\\\":\\\"01M1KT23X55MH19DT2KTREZHRJ\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-04 11:21:56'),
(668, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":0,\"response\":false}', '2026-09-04 19:40:21'),
(669, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-04 19:41:39'),
(670, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176363613421\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176363613421\",\"topic\":\"payment\"}}', '2026-09-04 19:43:38'),
(671, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176363613421\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176363613421\"},\"date_created\":\"2026-09-04T22:43:37Z\",\"id\":137126051429,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-04 19:43:38'),
(672, 'webhook', 'Consulta MP 176363613421 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9F02T7TYNSWMFH0KNW4NR\\\",\\\"id\\\":\\\"176363613421-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:43:37.698-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9F01BTPG67TXW2CP3DCXN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-04 19:43:38'),
(673, 'webhook', 'Consulta MP 176363613421 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9F02T7TYNSWMFH0KNW4NR\\\",\\\"id\\\":\\\"176363613421-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:43:37.698-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9F01BTPG67TXW2CP3DCXN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-04 19:43:38'),
(674, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-04 19:44:02'),
(675, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177325868426\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177325868426\",\"topic\":\"payment\"}}', '2026-09-04 19:44:02'),
(676, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177325868426\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"177325868426\"},\"date_created\":\"2026-09-04T22:44:01Z\",\"id\":137289453178,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-04 19:44:02'),
(677, 'webhook', 'Consulta MP 177325868426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9FQQ5RFWNGSNAW81DT4MY\\\",\\\"id\\\":\\\"177325868426-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:44:01.902-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9FQNXZQXX1967TMH3QVDV\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-04 19:44:02'),
(678, 'webhook', 'Consulta MP 177325868426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9FQQ5RFWNGSNAW81DT4MY\\\",\\\"id\\\":\\\"177325868426-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:44:01.902-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9FQNXZQXX1967TMH3QVDV\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-04 19:44:02'),
(679, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-04 19:44:07'),
(680, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:00:05'),
(681, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:01:04'),
(682, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:02:04'),
(683, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:03:04'),
(684, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:04:08'),
(685, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:05:05'),
(686, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:06:04'),
(687, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:07:06'),
(688, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:08:04'),
(689, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:09:04'),
(690, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:10:05'),
(691, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:11:04'),
(692, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:12:04'),
(693, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:13:04'),
(694, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:14:04'),
(695, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:15:05'),
(696, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:16:04'),
(697, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:17:04'),
(698, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:18:04'),
(699, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:19:04'),
(700, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:20:05'),
(701, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:21:04'),
(702, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:22:04'),
(703, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:23:04'),
(704, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:24:04'),
(705, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:25:05'),
(706, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:26:04'),
(707, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:27:04'),
(708, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:28:05'),
(709, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:29:04'),
(710, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:30:06'),
(711, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:31:04'),
(712, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:32:05'),
(713, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:33:04'),
(714, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:34:04'),
(715, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:35:04'),
(716, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:36:04'),
(717, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:37:04'),
(718, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:38:04'),
(719, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:39:04'),
(720, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:40:04'),
(721, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:41:04'),
(722, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:42:04'),
(723, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:43:04'),
(724, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:44:04'),
(725, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:45:05'),
(726, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:46:04'),
(727, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:47:04'),
(728, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:48:04'),
(729, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:49:04'),
(730, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:50:04'),
(731, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:51:05'),
(732, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:52:04'),
(733, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:53:04'),
(734, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:54:04'),
(735, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:55:05'),
(736, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:56:04'),
(737, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:57:04'),
(738, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:58:04'),
(739, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-05 04:59:04'),
(740, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":0,\"response\":false}', '2026-09-05 19:33:18'),
(741, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-05 19:33:57'),
(742, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-05 19:34:02'),
(743, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176363613421\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176363613421\"},\"date_created\":\"2026-09-04T22:43:37Z\",\"id\":137161107369,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-05 19:48:37'),
(744, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176363613421\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176363613421\",\"topic\":\"payment\"}}', '2026-09-05 19:48:37'),
(745, 'webhook', 'Consulta MP 176363613421 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9F02T7TYNSWMFH0KNW4NR\\\",\\\"id\\\":\\\"176363613421-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:43:37.698-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9F01BTPG67TXW2CP3DCXN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-05 19:48:37'),
(746, 'webhook', 'Consulta MP 176363613421 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9F02T7TYNSWMFH0KNW4NR\\\",\\\"id\\\":\\\"176363613421-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:43:37.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:43:37.698-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9F01BTPG67TXW2CP3DCXN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-05 19:48:42'),
(747, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177325868426\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177325868426\",\"topic\":\"payment\"}}', '2026-09-05 19:50:39'),
(748, 'webhook', 'Consulta MP 177325868426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9FQQ5RFWNGSNAW81DT4MY\\\",\\\"id\\\":\\\"177325868426-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:44:01.902-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9FQNXZQXX1967TMH3QVDV\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-05 19:50:39'),
(749, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177325868426\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"177325868426\"},\"date_created\":\"2026-09-04T22:44:01Z\",\"id\":137324728902,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-05 19:50:39'),
(750, 'webhook', 'Consulta MP 177325868426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.172.1-hotfix-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1Q9FQQ5RFWNGSNAW81DT4MY\\\",\\\"id\\\":\\\"177325868426-001\\\",\\\"last_updated\\\":\\\"2026-09-04T18:44:01.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-04T18:44:01.902-04:00\\\",\\\"execution_id\\\":\\\"01M1Q9FQNXZQXX1967TMH3QVDV\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_\"}', '2026-09-05 19:50:39'),
(751, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:00:10'),
(752, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:01:04'),
(753, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:02:04'),
(754, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:03:04'),
(755, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:04:09'),
(756, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:05:05'),
(757, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:06:04'),
(758, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:07:09'),
(759, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:08:04'),
(760, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:09:04'),
(761, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:10:04'),
(762, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:11:04'),
(763, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:12:08'),
(764, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:13:09'),
(765, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:14:04'),
(766, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:15:04'),
(767, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:16:09'),
(768, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:17:09'),
(769, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:18:04'),
(770, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:19:04'),
(771, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:20:09'),
(772, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:21:04'),
(773, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:22:09'),
(774, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:23:04'),
(775, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:24:04'),
(776, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:25:04'),
(777, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:26:04'),
(778, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:27:09'),
(779, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:28:04'),
(780, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:29:04'),
(781, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:30:05'),
(782, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:31:04'),
(783, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:32:14'),
(784, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:33:04'),
(785, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:34:04'),
(786, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:35:05'),
(787, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:36:04'),
(788, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:37:04'),
(789, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:38:04'),
(790, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:39:08'),
(791, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:40:05'),
(792, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:41:04'),
(793, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:42:05'),
(794, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:43:09'),
(795, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:44:04'),
(796, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:45:05'),
(797, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:46:04'),
(798, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:47:04'),
(799, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:48:05'),
(800, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:49:04'),
(801, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:50:04'),
(802, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:51:04'),
(803, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:52:04'),
(804, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:53:04'),
(805, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:54:04'),
(806, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:55:09'),
(807, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:56:04'),
(808, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:57:04'),
(809, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:58:08'),
(810, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-06 04:59:04'),
(811, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":0,\"response\":false}', '2026-09-06 11:46:54'),
(812, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:00:10'),
(813, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:01:04'),
(814, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:02:04');
INSERT INTO `logs` (`id`, `tipo`, `mensagem`, `detalhes`, `criado_em`) VALUES
(815, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:03:09'),
(816, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:04:09'),
(817, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:05:04'),
(818, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:06:04'),
(819, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:07:04'),
(820, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:08:04'),
(821, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:09:04'),
(822, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:10:04'),
(823, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:11:09'),
(824, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:12:08'),
(825, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:13:04'),
(826, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:14:04'),
(827, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:15:10'),
(828, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:16:04'),
(829, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:17:04'),
(830, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:18:04'),
(831, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:19:04'),
(832, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:20:04'),
(833, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:21:09'),
(834, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:22:04'),
(835, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:23:04'),
(836, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:24:04'),
(837, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:25:04'),
(838, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:26:04'),
(839, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:27:09'),
(840, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:28:04'),
(841, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:29:04'),
(842, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:30:05'),
(843, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:31:05'),
(844, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:32:04'),
(845, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:33:04'),
(846, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:34:04'),
(847, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:35:09'),
(848, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:36:04'),
(849, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:37:04'),
(850, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:38:04'),
(851, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:39:09'),
(852, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:40:04'),
(853, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:41:04'),
(854, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:42:04'),
(855, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:43:04'),
(856, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:44:09'),
(857, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:45:04'),
(858, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:46:04'),
(859, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:47:04'),
(860, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:48:04'),
(861, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:49:04'),
(862, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:50:04'),
(863, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:51:05'),
(864, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:52:09'),
(865, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:53:04'),
(866, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:54:04'),
(867, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:55:09'),
(868, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:56:04'),
(869, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:57:09'),
(870, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:58:04'),
(871, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-07 04:59:04'),
(872, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:00:09'),
(873, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:01:04'),
(874, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:02:09'),
(875, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:03:04'),
(876, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:04:04'),
(877, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:05:04'),
(878, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:06:04'),
(879, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:07:05'),
(880, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:08:09'),
(881, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:09:04'),
(882, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:10:04'),
(883, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:11:04'),
(884, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:12:04'),
(885, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:13:04'),
(886, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:14:04'),
(887, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:15:05'),
(888, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:16:10'),
(889, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:17:04'),
(890, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:18:04'),
(891, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:19:09'),
(892, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:20:04'),
(893, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:21:04'),
(894, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:22:09'),
(895, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:23:04'),
(896, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:24:09'),
(897, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:25:04'),
(898, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:26:04'),
(899, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:27:04'),
(900, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:28:04'),
(901, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:29:04'),
(902, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:30:09'),
(903, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:31:04'),
(904, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:32:08'),
(905, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:33:08'),
(906, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:34:04'),
(907, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:35:09'),
(908, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:36:04'),
(909, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:37:04'),
(910, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:38:04'),
(911, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:39:09'),
(912, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:40:04'),
(913, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:41:04'),
(914, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:42:04'),
(915, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:43:05'),
(916, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:44:09'),
(917, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:45:04'),
(918, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:46:04'),
(919, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:47:04'),
(920, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:48:04'),
(921, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:49:04'),
(922, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:50:04'),
(923, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:51:04'),
(924, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:52:10'),
(925, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:53:04'),
(926, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:54:04'),
(927, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:55:04'),
(928, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:56:09'),
(929, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:57:04'),
(930, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:58:04'),
(931, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-08 04:59:04'),
(932, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 08:49:27'),
(933, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 08:49:38'),
(934, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 08:49:43'),
(935, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 09:00:58'),
(936, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 09:34:10'),
(937, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 09:34:27'),
(938, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176922361329\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176922361329\"},\"date_created\":\"2026-09-08T12:41:59Z\",\"id\":137236134329,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 09:41:59'),
(939, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176922361329\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176922361329\",\"topic\":\"payment\"}}', '2026-09-08 09:41:59'),
(940, 'whatsapp', 'Mensagem enviada com sucesso para 5511939058859', NULL, '2026-09-08 09:41:59'),
(941, 'webhook', 'Consulta MP 176922361329 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20GM7JTTZ5FF70SBC1WAN39\\\",\\\"id\\\":\\\"176922361329-001\\\",\\\"last_updated\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T08:41:59.139-04:00\\\",\\\"execution_id\\\":\\\"01M20GM7HTJV6SRD4QJZ3ZD7SP\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 09:42:00'),
(942, 'webhook', 'Consulta MP 176922361329 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20GM7JTTZ5FF70SBC1WAN39\\\",\\\"id\\\":\\\"176922361329-001\\\",\\\"last_updated\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T08:41:59.139-04:00\\\",\\\"execution_id\\\":\\\"01M20GM7HTJV6SRD4QJZ3ZD7SP\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 09:42:04'),
(943, 'whatsapp', 'Mensagem enviada com sucesso para 5511939058859', NULL, '2026-09-08 09:42:05'),
(944, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 09:45:18'),
(945, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 09:45:23'),
(946, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176922361329\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176922361329\"},\"date_created\":\"2026-09-08T12:41:59Z\",\"id\":137400295090,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 09:49:10'),
(947, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176922361329\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176922361329\",\"topic\":\"payment\"}}', '2026-09-08 09:49:10'),
(948, 'webhook', 'Consulta MP 176922361329 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20GM7JTTZ5FF70SBC1WAN39\\\",\\\"id\\\":\\\"176922361329-001\\\",\\\"last_updated\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T08:41:59.139-04:00\\\",\\\"execution_id\\\":\\\"01M20GM7HTJV6SRD4QJZ3ZD7SP\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 09:49:10'),
(949, 'webhook', 'Consulta MP 176922361329 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20GM7JTTZ5FF70SBC1WAN39\\\",\\\"id\\\":\\\"176922361329-001\\\",\\\"last_updated\\\":\\\"2026-09-08T08:41:59.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T08:41:59.139-04:00\\\",\\\"execution_id\\\":\\\"01M20GM7HTJV6SRD4QJZ3ZD7SP\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 09:49:10'),
(950, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-09-08 09:49:16'),
(951, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-09-08 09:49:16'),
(952, 'mikrotik', 'Webhook pagamento: ppp7 → S1-R.NORMAL-01/Espera (1 meses)', NULL, '2026-09-08 09:49:17'),
(953, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 09:49:17'),
(954, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-08 09:49:18'),
(955, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-08 09:49:18'),
(956, 'mikrotik', 'Webhook pagamento: ppp7 → S1-R.NORMAL-01/Espera (1 meses)', NULL, '2026-09-08 09:49:23'),
(957, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 09:49:23'),
(958, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-08 09:49:23'),
(959, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-08 09:49:24'),
(960, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177900126828\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177900126828\",\"topic\":\"payment\"}}', '2026-09-08 10:53:12'),
(961, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177900126828\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"177900126828\"},\"date_created\":\"2026-09-08T13:53:11Z\",\"id\":137237709053,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 10:53:12'),
(962, 'webhook', 'Consulta MP 177900126828 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20MPKWFXGN4FWNF03N95V5N\\\",\\\"id\\\":\\\"177900126828-001\\\",\\\"last_updated\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T09:53:11.578-04:00\\\",\\\"execution_id\\\":\\\"01M20MPKVDXWGKBG2D9ECWFJ1W\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 10:53:12'),
(963, 'webhook', 'Consulta MP 177900126828 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20MPKWFXGN4FWNF03N95V5N\\\",\\\"id\\\":\\\"177900126828-001\\\",\\\"last_updated\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T09:53:11.578-04:00\\\",\\\"execution_id\\\":\\\"01M20MPKVDXWGKBG2D9ECWFJ1W\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 10:53:12'),
(964, 'whatsapp', 'Erro ao enviar WhatsApp para 5582999334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-08 10:53:16'),
(965, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 10:54:02'),
(966, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 10:54:08'),
(967, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177900126828\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"177900126828\"},\"date_created\":\"2026-09-08T13:53:11Z\",\"id\":137237889195,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 10:58:48'),
(968, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177900126828\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177900126828\",\"topic\":\"payment\"}}', '2026-09-08 10:58:48'),
(969, 'webhook', 'Consulta MP 177900126828 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20MPKWFXGN4FWNF03N95V5N\\\",\\\"id\\\":\\\"177900126828-001\\\",\\\"last_updated\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T09:53:11.578-04:00\\\",\\\"execution_id\\\":\\\"01M20MPKVDXWGKBG2D9ECWFJ1W\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 10:58:48'),
(970, 'webhook', 'Consulta MP 177900126828 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20MPKWFXGN4FWNF03N95V5N\\\",\\\"id\\\":\\\"177900126828-001\\\",\\\"last_updated\\\":\\\"2026-09-08T09:53:11.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T09:53:11.578-04:00\\\",\\\"execution_id\\\":\\\"01M20MPKVDXWGKBG2D9ECWFJ1W\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 10:58:48'),
(971, 'mikrotik', 'PPPoE ppp8 -> S2-R.SUPER-01/Espera [R1]', NULL, '2026-09-08 10:58:51'),
(972, 'mikrotik', 'Webhook pagamento: ppp8 → S2-R.SUPER-01/Espera (1 meses)', NULL, '2026-09-08 10:58:53'),
(973, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 10:58:53'),
(974, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-08 10:58:54'),
(975, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-08 10:58:54'),
(976, 'mikrotik', 'PPPoE ppp8 -> S2-R.SUPER-01/Espera [R1]', NULL, '2026-09-08 10:58:54'),
(977, 'mikrotik', 'Webhook pagamento: ppp8 → S2-R.SUPER-01/Espera (1 meses)', NULL, '2026-09-08 10:58:56'),
(978, 'whatsapp', 'Mensagem enviada com sucesso para 5582999334425', NULL, '2026-09-08 10:58:56'),
(979, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-08 10:58:56'),
(980, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-08 10:58:57'),
(981, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176939728305\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176939728305\"},\"date_created\":\"2026-09-08T14:12:06Z\",\"id\":137402157914,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 11:12:07'),
(982, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176939728305\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176939728305\",\"topic\":\"payment\"}}', '2026-09-08 11:12:07'),
(983, 'webhook', 'Consulta MP 176939728305 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20NS8F6B6NCH1K8Z3S1N1TA\\\",\\\"id\\\":\\\"176939728305-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:12:06.767-04:00\\\",\\\"execution_id\\\":\\\"01M20NS8E2WBYNW4Z3RM2J88E3\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 11:12:07'),
(984, 'webhook', 'Consulta MP 176939728305 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20NS8F6B6NCH1K8Z3S1N1TA\\\",\\\"id\\\":\\\"176939728305-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:12:06.767-04:00\\\",\\\"execution_id\\\":\\\"01M20NS8E2WBYNW4Z3RM2J88E3\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 11:12:07'),
(985, 'whatsapp', 'Erro ao enviar WhatsApp para 5582999334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-08 11:12:11'),
(986, 'whatsapp', 'Erro ao enviar WhatsApp para 5582999334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-08 11:12:35'),
(987, 'whatsapp', 'Erro ao enviar WhatsApp para 5582999334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-08 11:45:43'),
(988, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:46:09'),
(989, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:46:14'),
(990, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176939728305\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176939728305\"},\"date_created\":\"2026-09-08T14:12:06Z\",\"id\":137403133710,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 11:47:27'),
(991, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176939728305\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176939728305\",\"topic\":\"payment\"}}', '2026-09-08 11:47:27'),
(992, 'webhook', 'Consulta MP 176939728305 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20NS8F6B6NCH1K8Z3S1N1TA\\\",\\\"id\\\":\\\"176939728305-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:12:06.767-04:00\\\",\\\"execution_id\\\":\\\"01M20NS8E2WBYNW4Z3RM2J88E3\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 11:47:28'),
(993, 'webhook', 'Consulta MP 176939728305 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20NS8F6B6NCH1K8Z3S1N1TA\\\",\\\"id\\\":\\\"176939728305-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:12:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:12:06.767-04:00\\\",\\\"execution_id\\\":\\\"01M20NS8E2WBYNW4Z3RM2J88E3\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 11:47:28'),
(994, 'webhook', 'Fatura #31 já estava processada como PAGA. Notificação duplicada ignorada.', NULL, '2026-09-08 11:47:28'),
(995, 'mikrotik', 'PPPoE ppp8 -> S2-R.MAIOR-20/Espera [R1]', NULL, '2026-09-08 11:47:34'),
(996, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:47:34'),
(997, 'mikrotik', 'Webhook pagamento: ppp8 → S2-R.MAIOR-20/Espera (1 meses)', NULL, '2026-09-08 11:47:36'),
(998, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:47:36'),
(999, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-08 11:47:37'),
(1000, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-08 11:47:37'),
(1001, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:47:39'),
(1002, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:48:13'),
(1003, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177908931426\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"177908931426\"},\"date_created\":\"2026-09-08T14:50:06Z\",\"id\":137239164551,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 11:50:07'),
(1004, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177908931426\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177908931426\",\"topic\":\"payment\"}}', '2026-09-08 11:50:07'),
(1005, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:50:07'),
(1006, 'webhook', 'Consulta MP 177908931426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20QYV1H8MYX8JTX0BW2AE41\\\",\\\"id\\\":\\\"177908931426-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:50:06.778-04:00\\\",\\\"execution_id\\\":\\\"01M20QYV0DD0TTDB9VYCC2X1V4\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 11:50:07'),
(1007, 'webhook', 'Consulta MP 177908931426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20QYV1H8MYX8JTX0BW2AE41\\\",\\\"id\\\":\\\"177908931426-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:50:06.778-04:00\\\",\\\"execution_id\\\":\\\"01M20QYV0DD0TTDB9VYCC2X1V4\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 11:50:07'),
(1008, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:50:12'),
(1009, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177908931426\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"177908931426\"},\"date_created\":\"2026-09-08T14:50:06Z\",\"id\":137403270260,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 11:50:58'),
(1010, 'webhook', 'Consulta MP 177908931426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20QYV1H8MYX8JTX0BW2AE41\\\",\\\"id\\\":\\\"177908931426-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:50:06.778-04:00\\\",\\\"execution_id\\\":\\\"01M20QYV0DD0TTDB9VYCC2X1V4\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 11:50:58'),
(1011, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177908931426\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177908931426\",\"topic\":\"payment\"}}', '2026-09-08 11:50:58'),
(1012, 'webhook', 'Consulta MP 177908931426 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20QYV1H8MYX8JTX0BW2AE41\\\",\\\"id\\\":\\\"177908931426-001\\\",\\\"last_updated\\\":\\\"2026-09-08T10:50:06.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T10:50:06.778-04:00\\\",\\\"execution_id\\\":\\\"01M20QYV0DD0TTDB9VYCC2X1V4\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 11:50:59'),
(1013, 'webhook', 'Fatura #32 já estava processada como PAGA. Notificação duplicada ignorada.', NULL, '2026-09-08 11:50:59'),
(1014, 'mikrotik', 'PPPoE ppp8 -> S2-R.MAIOR-20/Espera [R1]', NULL, '2026-09-08 11:51:00'),
(1015, 'mikrotik', 'Webhook pagamento: ppp8 → S2-R.MAIOR-20/Espera (1 meses)', NULL, '2026-09-08 11:51:02'),
(1016, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 11:51:02'),
(1017, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-08 11:51:03'),
(1018, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-08 11:51:03'),
(1019, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-08 12:29:07'),
(1020, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 12:32:47'),
(1021, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 12:32:52'),
(1022, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 12:33:35'),
(1023, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 12:33:40'),
(1024, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176962219083\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176962219083\",\"topic\":\"payment\"}}', '2026-09-08 13:11:58'),
(1025, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176962219083\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176962219083\"},\"date_created\":\"2026-09-08T16:11:57Z\",\"id\":137241335857,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 13:11:58'),
(1026, 'webhook', 'Consulta MP 176962219083 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20WMPQKHGRTSR18YN5HFKWV\\\",\\\"id\\\":\\\"176962219083-001\\\",\\\"last_updated\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T12:11:57.565-04:00\\\",\\\"execution_id\\\":\\\"01M20WMPPKNHGT34W4TVZ0TYXB\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 13:11:58'),
(1027, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 13:11:59'),
(1028, 'webhook', 'Consulta MP 176962219083 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20WMPQKHGRTSR18YN5HFKWV\\\",\\\"id\\\":\\\"176962219083-001\\\",\\\"last_updated\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T12:11:57.565-04:00\\\",\\\"execution_id\\\":\\\"01M20WMPPKNHGT34W4TVZ0TYXB\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 13:12:03');
INSERT INTO `logs` (`id`, `tipo`, `mensagem`, `detalhes`, `criado_em`) VALUES
(1029, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 13:12:06'),
(1030, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 13:16:46'),
(1031, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 13:16:53'),
(1032, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176962219083\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176962219083\"},\"date_created\":\"2026-09-08T16:11:57Z\",\"id\":137405857204,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 13:24:18'),
(1033, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176962219083\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176962219083\",\"topic\":\"payment\"}}', '2026-09-08 13:24:18'),
(1034, 'webhook', 'Consulta MP 176962219083 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20WMPQKHGRTSR18YN5HFKWV\\\",\\\"id\\\":\\\"176962219083-001\\\",\\\"last_updated\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T12:11:57.565-04:00\\\",\\\"execution_id\\\":\\\"01M20WMPPKNHGT34W4TVZ0TYXB\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 13:24:18'),
(1035, 'webhook', 'Consulta MP 176962219083 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M20WMPQKHGRTSR18YN5HFKWV\\\",\\\"id\\\":\\\"176962219083-001\\\",\\\"last_updated\\\":\\\"2026-09-08T12:11:57.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T12:11:57.565-04:00\\\",\\\"execution_id\\\":\\\"01M20WMPPKNHGT34W4TVZ0TYXB\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-09-08 13:24:18'),
(1036, 'webhook', 'Fatura #33 já estava processada como PAGA. Notificação duplicada ignorada.', NULL, '2026-09-08 13:24:18'),
(1037, 'mikrotik', 'PPPoE ppp8 -> S2-R.MAIOR-20/Espera [R1]', NULL, '2026-09-08 13:24:24'),
(1038, 'mikrotik', 'Webhook pagamento: ppp8 → S2-R.MAIOR-20/Espera (1 meses)', NULL, '2026-09-08 13:24:31'),
(1039, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-08 13:24:33'),
(1040, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-08 13:24:33'),
(1041, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-08 13:24:34'),
(1042, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177045881395\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"177045881395\"},\"date_created\":\"2026-09-08T23:39:28Z\",\"id\":137419360518,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-08 20:39:29'),
(1043, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177045881395\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177045881395\",\"topic\":\"payment\"}}', '2026-09-08 20:39:29'),
(1044, 'webhook', 'Consulta MP 177045881395 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M21P84FM81FZ5TAS1ETB3Z7S\\\",\\\"id\\\":\\\"177045881395-001\\\",\\\"last_updated\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T19:39:28.635-04:00\\\",\\\"execution_id\\\":\\\"01M21P84EMD8XSXG2HNRC8NVWX\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 20:39:29'),
(1045, 'webhook', 'Consulta MP 177045881395 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M21P84FM81FZ5TAS1ETB3Z7S\\\",\\\"id\\\":\\\"177045881395-001\\\",\\\"last_updated\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T19:39:28.635-04:00\\\",\\\"execution_id\\\":\\\"01M21P84EMD8XSXG2HNRC8NVWX\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-08 20:39:29'),
(1046, 'whatsapp', 'Erro ao enviar WhatsApp para 558296934434', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-08 20:39:33'),
(1047, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-09-08 20:40:08'),
(1048, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-09-08 20:40:14'),
(1049, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-09-08 20:43:20'),
(1050, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-09-08 20:43:27'),
(1051, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:00:09'),
(1052, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:01:05'),
(1053, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:02:14'),
(1054, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:03:04'),
(1055, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:04:04'),
(1056, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:05:04'),
(1057, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:06:09'),
(1058, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:07:04'),
(1059, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:08:04'),
(1060, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:09:04'),
(1061, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:10:05'),
(1062, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:11:09'),
(1063, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:12:04'),
(1064, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:13:04'),
(1065, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:14:04'),
(1066, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:15:05'),
(1067, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:16:04'),
(1068, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:17:04'),
(1069, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:18:04'),
(1070, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:19:04'),
(1071, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:20:05'),
(1072, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:21:04'),
(1073, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:22:05'),
(1074, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:23:04'),
(1075, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:24:04'),
(1076, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:25:09'),
(1077, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:26:04'),
(1078, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:27:09'),
(1079, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:28:09'),
(1080, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:29:05'),
(1081, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:30:04'),
(1082, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:31:04'),
(1083, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:32:09'),
(1084, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:33:04'),
(1085, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:34:04'),
(1086, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:35:05'),
(1087, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:36:04'),
(1088, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:37:09'),
(1089, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:38:04'),
(1090, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:39:04'),
(1091, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:40:09'),
(1092, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:41:05'),
(1093, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:42:04'),
(1094, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:43:04'),
(1095, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:44:04'),
(1096, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:45:04'),
(1097, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:46:09'),
(1098, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:47:09'),
(1099, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:48:04'),
(1100, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:49:04'),
(1101, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:50:09'),
(1102, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:51:04'),
(1103, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:52:32'),
(1104, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:53:03'),
(1105, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:54:04'),
(1106, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:55:09'),
(1107, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:56:04'),
(1108, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:57:05'),
(1109, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:58:04'),
(1110, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-09 04:59:09'),
(1111, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177045881395\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"177045881395\"},\"date_created\":\"2026-09-08T23:39:28Z\",\"id\":137452553038,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-09 20:46:33'),
(1112, 'webhook', 'Consulta MP 177045881395 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M21P84FM81FZ5TAS1ETB3Z7S\\\",\\\"id\\\":\\\"177045881395-001\\\",\\\"last_updated\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T19:39:28.635-04:00\\\",\\\"execution_id\\\":\\\"01M21P84EMD8XSXG2HNRC8NVWX\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-09 20:46:34'),
(1113, 'webhook', 'Fatura não encontrada ext FATURA_36_604de51b7d_1788910767', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.173.0-rc-9\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-09-08T19:39:28.000-04:00\",\"external_charge_id\":\"01M21P84FM81FZ5TAS1ETB3Z7S\",\"id\":\"177045881395-001\",\"last_updated\":\"2026-09-08T19:39:28.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-09-08T19:39:28.635-04:00\",\"execution_id\":\"01M21P84EMD8XSXG2HNRC8NVWX\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-09-08T19:39:28.000-04:00\",\"date_last_updated\":\"2026-09-09T19:46:33.000-04:00\",\"date_of_expiration\":\"2026-09-09T19:39:28.000-04:00\",\"deduction_schema\":null,\"description\":\"Mensalidade - S1-40Megas-10 - ppp7\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_36_604de51b7d_1788910767\",\"fee_details\":[],\"financing_group\":null,\"id\":177045881395,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_36_604de51b7d_1788910767_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"https:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3673661283\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17704588139563043253\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKoElEQVR42uzdT3Iiu7IHYBEMGHoJXgpLs5fGUrwEDxkQ6EW7q5AyJdz0n2vXefH9JgR9TOmrO8ubUqqIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIyP82hzrkdPuPu1rfS3n58Y\\/vP77vl++XUp5\\/\\/OP6GX9c63n5\\/dPyj+\\/Lw7q8\\/nhYrfXj755HBC0tLS0tLS0tLS0tLS3tP9C+pe+n\\/sEfuuvHwq\\/Ln3zoux813aF\\/1e6Va\\/px98qrNvzkSEtLS0tLS0tLS0tLS7tlbas01wWf2mfIWgOvWdUfZeu5LXT88Yo\\/F241byica6h5W\\/V9pqWlpaWlpaWlpaWlpf1vaWPNuzZB12bnqmyd03N45NJB3bXPT9qvtLS0tLS0tLS0tLS0tP9vtNel5l0\\/L0E9LlTbgiU9pHVOL+07LS0tLS0tLS0tLS0tLe3\\/XJt2C8czp+3s6SUsXFLF3vq6XWXezp5ew48+XrlrEv\\/F3mZaWlpaWlpaWlpaWlrar9SOk4t+LnS8latZuw993lY4r+Xq4fcf8hdzlmhpaWlpaWlpaWlpaWm\\/TDtN1\\/Qs\\/eSifRhd23YNx5o3l6\\/Lj3INXFO1\\/cehpaWlpaWlpaWlpaWl\\/Upt3kJ7Gi486c6cvrffhZp3LFd34UqW+1exdDt\\/w+wkWlpaWlpaWlpaWlpa2k1qS2t6Lp\\/XZf7tLs27vbTTnM93mptt\\/m0eezR52PM4RPeRspeWlpaWlpaWlpaWlpaW9ne0P4vpMKU3bPQN2nWB\\/Z1W7aE\\/Y7oLZX5+5dYsPodyn5aWlpaWlpaWlpaWlnaj2vw3x0HbtWpDP3efFip3Cufav3LX7w2vfHhs9zAtLS0tLS0tLS0tLS3t92pzuXpaytO20Xd+i0qdXf55urVhY\\/u1zHYN5\\/tbfntyES0tLS0tLS0tLS0tLe13aKd\\/E2rep775mWveMDy3tI7pWjjnDuqq7vbdhs7p6YH9t7S0tLS0tLS0tLS0tLS0j2tPaaPv8UZYp\\/Ze2me4puXcFmyvWu9o96ldfFkEk4fQ0tLS0tLS0tLS0tLSbkx7aHt11xZtK1fz8KF9KFvHrcZdudr6vCVop2dOa3p1WlpaWlpaWlpaWlpa2v+ItvYbfNeRtddp5zS3W8P3qfZ9VjhfmuSXu4VpaWlpaWlpaWlpaWlpv1c7ubukNTu7rbI1nTmdXnxymA3RnRTOn04ueuSeU1paWlpaWlpaWlpaWlrah7TdBt9QJ59KCXe+jP3dfRiR1HYJn\\/utxrWV+WXR5eRXPz4wFYqWlpaWlpaWlpaWlpb227Srri10b+hQt2s43PlShi3HJfV5JwX0c6\\/9zWm9tLS0tLS0tLS0tLS0tN+gPbSTnsfbsdF4TUtb6NLK1g\\/lZMHxjGnunHZbjqfzbz8LLS0tLS0tLS0tLS0t7Za07dLPMmt+xqFDrQl6Dg9L7de1YP58ctF0JzAtLS0tLS0tLS0tLS3txrRx12tYYLp19j3VvnU2\\/\\/bQ17oTbZ5clOfgnmhpaWlpaWlpaWlpaWlp\\/5V23C3cZVyott3Cq\\/Kt\\/\\/F51ufdjf3e537U7zl80tLS0tLS0tLS0tLS0m5f28rWp1T7hho459wOrrbjortU88b5ty+zPu\\/4EFpaWlpaWlpaWlpaWtpNaQ\\/t5GcYXTudXNSNrg0ja\\/Mu4W5yUZ2NP+oyfeXTJ3ubaWlpaWlpaWlpaWlpab9R280NOg67YCcLPLUOalPn0bXd+KNwF2eefxu0dWm\\/0tLS0tLS0tLS0tLS0tL+G22e1lv6jb7XNGD3ErT3yvx05jS\\/ag3\\/E7SHHdIFMrS0tLS0tLS0tLS0tLTb1eZytbZdw693fjpdaBz5ew3K2te83eSiNOKXlpaWlpaWlpaWlpaWdsPa9tnVvPk3L32t+9xf05K3HHcFc\\/ic9mwvdwpnWlpaWlpaWlpaWlpa2q1qpxOK1uFDL30TdB0+9LbUvM+zH5\\/7fbe7MO4oHFyt939MS0tLS0tLS0tLS0tLS\\/uvtOc0Z2miLkPfd9+X9fGh7czpNfzoZdgtXNtDnvvrR2lpaWlpaWlpaWlpaWm3rl2+dwN2O2Wdla3rLuHnpF6VbeHdeGHMWxt\\/FMYg0dLS0tLS0tLS0tLS0m5U21Wep\\/7YaN4tHC79rK1zem+j773O6Tr+qL1y136lpaWlpaWlpaWlpaWl3bi2O2salL86LhpuUVm\\/n\\/vOaUkTi67jEN0wuag7yPrLE7K0tLS0tLS0tLS0tLS036Pt7uIsQ807P8VZh+bnOWin829f+x+\\/9yvnIboP3hxKS0tLS0tLS0tLS0tLS\\/uQdjrBKFfqryWeOc1\\/P25Bfm\\/ql9tD9u3M6cfK+7Tl+HDnICstLS0tLS0tLS0tLS3t92sPd\\/bo3lM+tTI1jKwdm8fXcddw7bX7ZeV9ewgtLS0tLS0tLS0tLS3t9rXdf2sbe0vpJhetHdS1ybkPI2vXhcIFKHly0cut9q3p4Gr+PH\\/SNqWlpaWlpaWlpaWlpaX9Xm1sgoaad6yBu62zZVxgXOgpXcWSJxetNe\\/bTEBLS0tLS0tLS0tLS0tL+3fars8bEi793I13vdQ0YHeq7oY05Qq9lffdtN6aynxaWlpaWlpaWlpaWlra7Wnrskf3lBbKk4vWPm\\/r98axR6lpvFteuS6vunvozhdaWlpaWlpaWlpaWlra7WvH3FsoJB4Xbc3Pew8ND8nayZZjWlpaWlpaWlpaWlpa2o1qw9\\/81J1uHdP1s7TmZ22ja6ebeI81zr8N+3G7Nuy4mbf+cnIRLS0tLS0tLS0tLS0tLe2D2jDd6NCUta\\/Q38fKvPV5a9pyfC5xSFP3qqXfctzNVwqSIy0tLS0tLS0tLS0tLe02tbFcbQvVervzpfbHRfOln1nd+ryf3PnyXrqJRZe05bjQ0tLS0tLS0tLS0tLSblabhw7VZe5tN7r25aa+tBtESypX15xuD+leuZRh\\/m1TRm0T0NLS0tLS0tLS0tLS0m5SW\\/tytbQts8ebsoZy9WVZYCyYaz\\/+KF47Wvr261Pfbl0L6EP7\\/uAJWVpaWlpaWlpaWlpaWtqv1k71sekZ5t8+9Qcw4zWa05xmyjCxqI77cU+l0NLS0tLS0tLS0tLS0tL+a20pd69ryde0lKHfuxbXh75ZfA0PHc+cXsL\\/V5AujqGlpaWlpaWlpaWlpaXdlPYwK1NLq3m7s6ftuOikv9sNHVo+r2nLcfzMZ07\\/pCtNS0tLS0tLS0tLS0tL+w3at\\/T91N+ikhdaa9+uXB1r3lA4d2OPupo3PyQNzy20tLS0tLS0tLS0tLS029W2M6eHpjzeat3duA\\/3ue+g5sL53ArmcSvtvj4SWlpaWlpaWlpaWlpaWtov0NZUXIfjoZMzp+khNcxZerlN6+1Uuc\\/7NxU6LS0tLS0tLS0tLS0t7VdrY16GVu0nN4ee7jSLx2m9kybx8x\\/VvLS0tLS0tLS0tLS0tLRfrB13C68L1FnNe2lN0Ldxo28qga9hglF45dKfOS3t80hLS0tLS0tLS0tLS0u7We2vJhe93tRZuQ8d1PTQTvmUVlg3876N44+mVTctLS0tLS0tLS0tLS0t7R9oRURERERERERERERERERERERERERERERERERERDad\\/wsAAP\\/\\/hLHihEyO4qMAAAAASUVORK5CYII=\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/177045881395\\/ticket?caller_id=3673661283&hash=940a35ff-6dc4-4799-9574-bb91963107aa\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-09-09 20:46:34'),
(1114, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177045881395\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177045881395\",\"topic\":\"payment\"}}', '2026-09-09 20:46:34'),
(1115, 'webhook', 'Consulta MP 177045881395 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M21P84FM81FZ5TAS1ETB3Z7S\\\",\\\"id\\\":\\\"177045881395-001\\\",\\\"last_updated\\\":\\\"2026-09-08T19:39:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-08T19:39:28.635-04:00\\\",\\\"execution_id\\\":\\\"01M21P84EMD8XSXG2HNRC8NVWX\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-09 20:46:34'),
(1116, 'webhook', 'Fatura não encontrada ext FATURA_36_604de51b7d_1788910767', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.173.0-rc-9\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-09-08T19:39:28.000-04:00\",\"external_charge_id\":\"01M21P84FM81FZ5TAS1ETB3Z7S\",\"id\":\"177045881395-001\",\"last_updated\":\"2026-09-08T19:39:28.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-09-08T19:39:28.635-04:00\",\"execution_id\":\"01M21P84EMD8XSXG2HNRC8NVWX\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-09-08T19:39:28.000-04:00\",\"date_last_updated\":\"2026-09-09T19:46:33.000-04:00\",\"date_of_expiration\":\"2026-09-09T19:39:28.000-04:00\",\"deduction_schema\":null,\"description\":\"Mensalidade - S1-40Megas-10 - ppp7\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_36_604de51b7d_1788910767\",\"fee_details\":[],\"financing_group\":null,\"id\":177045881395,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_36_604de51b7d_1788910767_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"https:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3673661283\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17704588139563043253\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKoElEQVR42uzdT3Iiu7IHYBEMGHoJXgpLs5fGUrwEDxkQ6EW7q5AyJdz0n2vXefH9JgR9TOmrO8ubUqqIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIyP82hzrkdPuPu1rfS3n58Y\\/vP77vl++XUp5\\/\\/OP6GX9c63n5\\/dPyj+\\/Lw7q8\\/nhYrfXj755HBC0tLS0tLS0tLS0tLS3tP9C+pe+n\\/sEfuuvHwq\\/Ln3zoux813aF\\/1e6Va\\/px98qrNvzkSEtLS0tLS0tLS0tLS7tlbas01wWf2mfIWgOvWdUfZeu5LXT88Yo\\/F241byica6h5W\\/V9pqWlpaWlpaWlpaWlpf1vaWPNuzZB12bnqmyd03N45NJB3bXPT9qvtLS0tLS0tLS0tLS0tP9vtNel5l0\\/L0E9LlTbgiU9pHVOL+07LS0tLS0tLS0tLS0tLe3\\/XJt2C8czp+3s6SUsXFLF3vq6XWXezp5ew48+XrlrEv\\/F3mZaWlpaWlpaWlpaWlrar9SOk4t+LnS8latZuw993lY4r+Xq4fcf8hdzlmhpaWlpaWlpaWlpaWm\\/TDtN1\\/Qs\\/eSifRhd23YNx5o3l6\\/Lj3INXFO1\\/cehpaWlpaWlpaWlpaWl\\/Upt3kJ7Gi486c6cvrffhZp3LFd34UqW+1exdDt\\/w+wkWlpaWlpaWlpaWlpa2k1qS2t6Lp\\/XZf7tLs27vbTTnM93mptt\\/m0eezR52PM4RPeRspeWlpaWlpaWlpaWlpaW9ne0P4vpMKU3bPQN2nWB\\/Z1W7aE\\/Y7oLZX5+5dYsPodyn5aWlpaWlpaWlpaWlnaj2vw3x0HbtWpDP3efFip3Cufav3LX7w2vfHhs9zAtLS0tLS0tLS0tLS3t92pzuXpaytO20Xd+i0qdXf55urVhY\\/u1zHYN5\\/tbfntyES0tLS0tLS0tLS0tLe13aKd\\/E2rep775mWveMDy3tI7pWjjnDuqq7vbdhs7p6YH9t7S0tLS0tLS0tLS0tLS0j2tPaaPv8UZYp\\/Ze2me4puXcFmyvWu9o96ldfFkEk4fQ0tLS0tLS0tLS0tLSbkx7aHt11xZtK1fz8KF9KFvHrcZdudr6vCVop2dOa3p1WlpaWlpaWlpaWlpa2v+ItvYbfNeRtddp5zS3W8P3qfZ9VjhfmuSXu4VpaWlpaWlpaWlpaWlpv1c7ubukNTu7rbI1nTmdXnxymA3RnRTOn04ueuSeU1paWlpaWlpaWlpaWlrah7TdBt9QJ59KCXe+jP3dfRiR1HYJn\\/utxrWV+WXR5eRXPz4wFYqWlpaWlpaWlpaWlpb227Srri10b+hQt2s43PlShi3HJfV5JwX0c6\\/9zWm9tLS0tLS0tLS0tLS0tN+gPbSTnsfbsdF4TUtb6NLK1g\\/lZMHxjGnunHZbjqfzbz8LLS0tLS0tLS0tLS0t7Za07dLPMmt+xqFDrQl6Dg9L7de1YP58ctF0JzAtLS0tLS0tLS0tLS3txrRx12tYYLp19j3VvnU2\\/\\/bQ17oTbZ5clOfgnmhpaWlpaWlpaWlpaWlp\\/5V23C3cZVyott3Cq\\/Kt\\/\\/F51ufdjf3e537U7zl80tLS0tLS0tLS0tLS0m5f28rWp1T7hho459wOrrbjortU88b5ty+zPu\\/4EFpaWlpaWlpaWlpaWtpNaQ\\/t5GcYXTudXNSNrg0ja\\/Mu4W5yUZ2NP+oyfeXTJ3ubaWlpaWlpaWlpaWlpab9R280NOg67YCcLPLUOalPn0bXd+KNwF2eefxu0dWm\\/0tLS0tLS0tLS0tLS0tL+G22e1lv6jb7XNGD3ErT3yvx05jS\\/ag3\\/E7SHHdIFMrS0tLS0tLS0tLS0tLTb1eZytbZdw693fjpdaBz5ew3K2te83eSiNOKXlpaWlpaWlpaWlpaWdsPa9tnVvPk3L32t+9xf05K3HHcFc\\/ic9mwvdwpnWlpaWlpaWlpaWlpa2q1qpxOK1uFDL30TdB0+9LbUvM+zH5\\/7fbe7MO4oHFyt939MS0tLS0tLS0tLS0tLS\\/uvtOc0Z2miLkPfd9+X9fGh7czpNfzoZdgtXNtDnvvrR2lpaWlpaWlpaWlpaWm3rl2+dwN2O2Wdla3rLuHnpF6VbeHdeGHMWxt\\/FMYg0dLS0tLS0tLS0tLS0m5U21Wep\\/7YaN4tHC79rK1zem+j773O6Tr+qL1y136lpaWlpaWlpaWlpaWl3bi2O2salL86LhpuUVm\\/n\\/vOaUkTi67jEN0wuag7yPrLE7K0tLS0tLS0tLS0tLS036Pt7uIsQ807P8VZh+bnOWin829f+x+\\/9yvnIboP3hxKS0tLS0tLS0tLS0tLS\\/uQdjrBKFfqryWeOc1\\/P25Bfm\\/ql9tD9u3M6cfK+7Tl+HDnICstLS0tLS0tLS0tLS3t92sPd\\/bo3lM+tTI1jKwdm8fXcddw7bX7ZeV9ewgtLS0tLS0tLS0tLS3t9rXdf2sbe0vpJhetHdS1ybkPI2vXhcIFKHly0cut9q3p4Gr+PH\\/SNqWlpaWlpaWlpaWlpaX9Xm1sgoaad6yBu62zZVxgXOgpXcWSJxetNe\\/bTEBLS0tLS0tLS0tLS0tL+3fars8bEi793I13vdQ0YHeq7oY05Qq9lffdtN6aynxaWlpaWlpaWlpaWlra7Wnrskf3lBbKk4vWPm\\/r98axR6lpvFteuS6vunvozhdaWlpaWlpaWlpaWlra7WvH3FsoJB4Xbc3Pew8ND8nayZZjWlpaWlpaWlpaWlpa2o1qw9\\/81J1uHdP1s7TmZ22ja6ebeI81zr8N+3G7Nuy4mbf+cnIRLS0tLS0tLS0tLS0tLe2D2jDd6NCUta\\/Q38fKvPV5a9pyfC5xSFP3qqXfctzNVwqSIy0tLS0tLS0tLS0tLe02tbFcbQvVervzpfbHRfOln1nd+ryf3PnyXrqJRZe05bjQ0tLS0tLS0tLS0tLSblabhw7VZe5tN7r25aa+tBtESypX15xuD+leuZRh\\/m1TRm0T0NLS0tLS0tLS0tLS0m5SW\\/tytbQts8ebsoZy9WVZYCyYaz\\/+KF47Wvr261Pfbl0L6EP7\\/uAJWVpaWlpaWlpaWlpaWtqv1k71sekZ5t8+9Qcw4zWa05xmyjCxqI77cU+l0NLS0tLS0tLS0tLS0tL+a20pd69ryde0lKHfuxbXh75ZfA0PHc+cXsL\\/V5AujqGlpaWlpaWlpaWlpaXdlPYwK1NLq3m7s6ftuOikv9sNHVo+r2nLcfzMZ07\\/pCtNS0tLS0tLS0tLS0tL+w3at\\/T91N+ikhdaa9+uXB1r3lA4d2OPupo3PyQNzy20tLS0tLS0tLS0tLS029W2M6eHpjzeat3duA\\/3ue+g5sL53ArmcSvtvj4SWlpaWlpaWlpaWlpaWtov0NZUXIfjoZMzp+khNcxZerlN6+1Uuc\\/7NxU6LS0tLS0tLS0tLS0t7VdrY16GVu0nN4ee7jSLx2m9kybx8x\\/VvLS0tLS0tLS0tLS0tLRfrB13C68L1FnNe2lN0Ldxo28qga9hglF45dKfOS3t80hLS0tLS0tLS0tLS0u7We2vJhe93tRZuQ8d1PTQTvmUVlg3876N44+mVTctLS0tLS0tLS0tLS0t7R9oRURERERERERERERERERERERERERERERERERERDad\\/wsAAP\\/\\/hLHihEyO4qMAAAAASUVORK5CYII=\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/177045881395\\/ticket?caller_id=3673661283&hash=940a35ff-6dc4-4799-9574-bb91963107aa\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-09-09 20:46:34'),
(1117, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:00:15'),
(1118, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:01:04'),
(1119, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:02:05'),
(1120, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:03:04'),
(1121, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:04:04'),
(1122, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:05:04'),
(1123, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:06:04'),
(1124, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:07:04'),
(1125, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:08:04'),
(1126, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:09:04'),
(1127, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:10:05'),
(1128, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:11:04'),
(1129, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:12:04'),
(1130, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:13:04'),
(1131, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:14:04'),
(1132, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:15:05'),
(1133, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:16:04'),
(1134, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:17:09'),
(1135, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:18:04'),
(1136, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:19:04'),
(1137, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:20:05'),
(1138, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:21:04'),
(1139, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:22:09'),
(1140, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:23:04'),
(1141, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:24:04'),
(1142, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:25:04'),
(1143, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:26:04'),
(1144, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:27:04'),
(1145, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:28:04'),
(1146, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:29:04'),
(1147, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:30:05'),
(1148, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:31:04'),
(1149, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:32:04'),
(1150, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:33:04'),
(1151, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:34:05'),
(1152, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:35:05'),
(1153, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:36:09'),
(1154, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:37:04'),
(1155, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:38:05'),
(1156, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:39:04'),
(1157, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:40:04'),
(1158, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:41:04'),
(1159, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:42:04'),
(1160, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:43:04'),
(1161, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:44:04'),
(1162, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:45:05'),
(1163, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:46:04'),
(1164, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:47:04'),
(1165, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:48:04'),
(1166, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:49:04'),
(1167, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:50:05'),
(1168, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:51:09'),
(1169, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:52:04'),
(1170, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:53:09'),
(1171, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:54:04'),
(1172, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:55:09'),
(1173, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:56:04'),
(1174, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:57:04'),
(1175, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:58:04'),
(1176, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 04:59:04'),
(1177, 'mikrotik', 'Sync automático (cron): 2 clientes, 2 faturas criadas.', NULL, '2026-09-10 12:25:46'),
(1178, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-10 12:40:53'),
(1179, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177326600029\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177326600029\",\"topic\":\"payment\"}}', '2026-09-10 12:46:51'),
(1180, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177326600029\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"177326600029\"},\"date_created\":\"2026-09-10T15:46:50Z\",\"id\":137306560897,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-10 12:46:51'),
(1181, 'webhook', 'Consulta MP 177326600029 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M260051E7VPA9NBX2X9Y1F11\\\",\\\"id\\\":\\\"177326600029-001\\\",\\\"last_updated\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-10T11:46:50.550-04:00\\\",\\\"execution_id\\\":\\\"01M260050C9MC79135DTBBAPGK\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-10 12:46:51'),
(1182, 'webhook', 'Consulta MP 177326600029 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M260051E7VPA9NBX2X9Y1F11\\\",\\\"id\\\":\\\"177326600029-001\\\",\\\"last_updated\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-10T11:46:50.550-04:00\\\",\\\"execution_id\\\":\\\"01M260050C9MC79135DTBBAPGK\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-10 12:46:51'),
(1183, 'whatsapp', 'Erro ao enviar WhatsApp para 558296934434', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-10 12:46:55'),
(1184, 'whatsapp', 'Erro ao enviar WhatsApp para 558296934434', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-10 12:47:43'),
(1185, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-09-10 12:47:50'),
(1186, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-09-10 12:47:57'),
(1187, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"177326600029\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"177326600029\"},\"date_created\":\"2026-09-10T15:46:50Z\",\"id\":137307171639,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-10 13:07:16'),
(1188, 'webhook', 'MP notification', '{\"get\":{\"id\":\"177326600029\",\"topic\":\"payment\"},\"body\":{\"resource\":\"177326600029\",\"topic\":\"payment\"}}', '2026-09-10 13:07:16'),
(1189, 'webhook', 'Consulta MP 177326600029 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":false},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M260051E7VPA9NBX2X9Y1F11\\\",\\\"id\\\":\\\"177326600029-001\\\",\\\"last_updated\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-10T11:46:50.550-04:00\\\",\\\"execution_id\\\":\\\"01M260050C9MC79135DTBBAPGK\\\"}},\\\"collector_id\\\":142008628,\\\"corporat\"}', '2026-09-10 13:07:16'),
(1190, 'webhook', 'Consulta MP 177326600029 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":false},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M260051E7VPA9NBX2X9Y1F11\\\",\\\"id\\\":\\\"177326600029-001\\\",\\\"last_updated\\\":\\\"2026-09-10T11:46:50.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-10T11:46:50.550-04:00\\\",\\\"execution_id\\\":\\\"01M260050C9MC79135DTBBAPGK\\\"}},\\\"collector_id\\\":142008628,\\\"corporat\"}', '2026-09-10 13:07:21'),
(1191, 'webhook', 'Fatura #38 já estava processada como PAGA. Notificação duplicada ignorada.', NULL, '2026-09-10 13:07:21'),
(1192, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-10/Espera [R1]', NULL, '2026-09-10 13:07:23'),
(1193, 'mikrotik', 'Webhook pagamento: ppp7 → S1-R.NORMAL-10/Espera (1 meses)', NULL, '2026-09-10 13:07:25'),
(1194, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-09-10 13:07:26'),
(1195, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-09-10 13:07:27'),
(1196, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;amp;text=foi', NULL, '2026-09-10 13:07:27'),
(1197, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-11 04:00:10');
INSERT INTO `logs` (`id`, `tipo`, `mensagem`, `detalhes`, `criado_em`) VALUES
(1198, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"178467698616\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"178467698616\"},\"date_created\":\"2026-09-11T14:15:21Z\",\"id\":137502078160,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-11 11:15:21'),
(1199, 'webhook', 'MP notification', '{\"get\":{\"id\":\"178467698616\",\"topic\":\"payment\"},\"body\":{\"resource\":\"178467698616\",\"topic\":\"payment\"}}', '2026-09-11 11:15:21'),
(1200, 'webhook', 'Consulta MP 178467698616 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5B7TTHBT4D8VC85XBDV9\\\",\\\"id\\\":\\\"178467698616-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:21.092-04:00\\\",\\\"execution_id\\\":\\\"01M28D5B6VBJR7TN7B2WRG8006\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-11 11:15:21'),
(1201, 'webhook', 'Consulta MP 178467698616 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5B7TTHBT4D8VC85XBDV9\\\",\\\"id\\\":\\\"178467698616-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:21.092-04:00\\\",\\\"execution_id\\\":\\\"01M28D5B6VBJR7TN7B2WRG8006\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-11 11:15:21'),
(1202, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"178466289132\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"178466289132\"},\"date_created\":\"2026-09-11T14:15:22Z\",\"id\":137502038570,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-11 11:15:22'),
(1203, 'webhook', 'MP notification', '{\"get\":{\"id\":\"178466289132\",\"topic\":\"payment\"},\"body\":{\"resource\":\"178466289132\",\"topic\":\"payment\"}}', '2026-09-11 11:15:22'),
(1204, 'webhook', 'Consulta MP 178466289132 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5C63Y56HV9DP8AEE8S3Q\\\",\\\"id\\\":\\\"178466289132-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:22.060-04:00\\\",\\\"execution_id\\\":\\\"01M28D5C52G9EC1YEWBGQ0QG7S\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-11 11:15:22'),
(1205, 'webhook', 'Consulta MP 178466289132 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5C63Y56HV9DP8AEE8S3Q\\\",\\\"id\\\":\\\"178466289132-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:22.060-04:00\\\",\\\"execution_id\\\":\\\"01M28D5C52G9EC1YEWBGQ0QG7S\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-11 11:15:22'),
(1206, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-11 11:15:26'),
(1207, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-11 11:17:15'),
(1208, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-11 11:17:22'),
(1209, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-12 04:00:10'),
(1210, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"178466289132\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"178466289132\"},\"date_created\":\"2026-09-11T14:15:22Z\",\"id\":137535126602,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-12 11:20:46'),
(1211, 'webhook', 'MP notification', '{\"get\":{\"id\":\"178466289132\",\"topic\":\"payment\"},\"body\":{\"resource\":\"178466289132\",\"topic\":\"payment\"}}', '2026-09-12 11:20:46'),
(1212, 'webhook', 'Consulta MP 178466289132 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5C63Y56HV9DP8AEE8S3Q\\\",\\\"id\\\":\\\"178466289132-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:22.060-04:00\\\",\\\"execution_id\\\":\\\"01M28D5C52G9EC1YEWBGQ0QG7S\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-12 11:20:46'),
(1213, 'webhook', 'Consulta MP 178466289132 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5C63Y56HV9DP8AEE8S3Q\\\",\\\"id\\\":\\\"178466289132-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:22.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:22.060-04:00\\\",\\\"execution_id\\\":\\\"01M28D5C52G9EC1YEWBGQ0QG7S\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-12 11:20:46'),
(1214, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"178467698616\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"178467698616\"},\"date_created\":\"2026-09-11T14:15:21Z\",\"id\":137370425977,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-12 11:22:20'),
(1215, 'webhook', 'MP notification', '{\"get\":{\"id\":\"178467698616\",\"topic\":\"payment\"},\"body\":{\"resource\":\"178467698616\",\"topic\":\"payment\"}}', '2026-09-12 11:22:20'),
(1216, 'webhook', 'Consulta MP 178467698616 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5B7TTHBT4D8VC85XBDV9\\\",\\\"id\\\":\\\"178467698616-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:21.092-04:00\\\",\\\"execution_id\\\":\\\"01M28D5B6VBJR7TN7B2WRG8006\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-12 11:22:20'),
(1217, 'webhook', 'Consulta MP 178467698616 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.173.0-rc-9\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M28D5B7TTHBT4D8VC85XBDV9\\\",\\\"id\\\":\\\"178467698616-001\\\",\\\"last_updated\\\":\\\"2026-09-11T10:15:21.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-11T10:15:21.092-04:00\\\",\\\"execution_id\\\":\\\"01M28D5B6VBJR7TN7B2WRG8006\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-12 11:22:20'),
(1218, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-13 04:00:09'),
(1219, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-09-14 04:00:09'),
(1220, 'webhook', 'MP notification', '{\"get\":{\"id\":\"178939682490\",\"topic\":\"payment\"},\"body\":{\"resource\":\"178939682490\",\"topic\":\"payment\"}}', '2026-09-14 10:10:56'),
(1221, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"178939682490\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"178939682490\"},\"date_created\":\"2026-09-14T13:10:55Z\",\"id\":137428999421,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-09-14 10:10:56'),
(1222, 'webhook', 'Consulta MP 178939682490 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.174.0-rc-4\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-14T09:10:55.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M2G0NHDDBAXENCZDC9EN3BJS\\\",\\\"id\\\":\\\"178939682490-001\\\",\\\"last_updated\\\":\\\"2026-09-14T09:10:55.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-14T09:10:55.669-04:00\\\",\\\"execution_id\\\":\\\"01M2G0NHCC17MABZE0FH7PXT90\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-14 10:10:56'),
(1223, 'webhook', 'Consulta MP 178939682490 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.174.0-rc-4\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-09-14T09:10:55.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M2G0NHDDBAXENCZDC9EN3BJS\\\",\\\"id\\\":\\\"178939682490-001\\\",\\\"last_updated\\\":\\\"2026-09-14T09:10:55.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-09-14T09:10:55.669-04:00\\\",\\\"execution_id\\\":\\\"01M2G0NHCC17MABZE0FH7PXT90\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-09-14 10:10:56'),
(1224, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:10:57'),
(1225, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:11:04'),
(1226, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-14 10:12:45'),
(1227, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:13:27'),
(1228, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:13:33'),
(1229, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:14:01'),
(1230, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:14:08'),
(1231, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:15:18'),
(1232, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 10:15:24'),
(1233, 'whatsapp', 'Erro ao enviar WhatsApp para 558299334425', '{\"code\":503,\"response\":\"{\\\"error\\\":\\\"WhatsApp não conectado\\\"}\"}', '2026-09-14 11:03:40'),
(1234, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 11:06:11'),
(1235, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 11:06:18'),
(1236, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 11:23:44'),
(1237, 'whatsapp', 'Mensagem enviada com sucesso para 558299334425', NULL, '2026-09-14 11:23:50');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mikrotik_payment_history`
--

CREATE TABLE `mikrotik_payment_history` (
  `id` int NOT NULL,
  `cliente_id` int NOT NULL,
  `ano` int NOT NULL,
  `mes` int NOT NULL,
  `status` enum('paid','warning','overdue','npago') DEFAULT 'paid',
  `valor` decimal(10,2) DEFAULT '0.00',
  `data_atualizacao` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `mikrotik_payment_history`
--

INSERT INTO `mikrotik_payment_history` (`id`, `cliente_id`, `ano`, `mes`, `status`, `valor`, `data_atualizacao`) VALUES
(1453, 184, 2026, 9, 'warning', 0.00, '2026-09-10 12:25:46'),
(1454, 185, 2026, 9, 'paid', 1.00, '2026-09-10 13:07:16');

-- --------------------------------------------------------

--
-- Estrutura da tabela `planos`
--

CREATE TABLE `planos` (
  `id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `prefixo_grupo` varchar(20) DEFAULT 'S1',
  `profile_mikrotik` varchar(100) NOT NULL,
  `profile_aviso` varchar(100) DEFAULT NULL,
  `profile_bloqueado` varchar(100) NOT NULL,
  `velocidade_down` varchar(50) DEFAULT '40M',
  `velocidade_up` varchar(50) DEFAULT '20M',
  `valor` decimal(10,2) NOT NULL DEFAULT '0.00',
  `dias_validade` int NOT NULL DEFAULT '30',
  `descricao` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `planos`
--

INSERT INTO `planos` (`id`, `nome`, `prefixo_grupo`, `profile_mikrotik`, `profile_aviso`, `profile_bloqueado`, `velocidade_down`, `velocidade_up`, `valor`, `dias_validade`, `descricao`, `criado_em`) VALUES
(1, 'S1-40Megas-01', 'S1', 'S1-R.NORMAL-01/Espera', 'S1-R.NORMAL-01/Aviso', 'S1-R.NORMAL-01/Bloqueado', '40M', '20M', 1.00, 30, 'Plano Teste 40 Mega Grupo S1', '2026-08-19 15:50:59'),
(2, 'S2-40Megas-01', 'S2', 'S2-R.NORMAL-01/Espera', 'S2-R.NORMAL-01/Aviso', 'S2-R.NORMAL-01/Bloqueado', '40M', '20M', 1.00, 30, 'Plano 40 Mega Grupo S2', '2026-08-19 15:50:59'),
(3, 'S1-40Megas-10', 'S1', 'S1-R.NORMAL-10/Espera', 'S1-R.NORMAL-10/Aviso', 'S1-R.NORMAL-10/Bloqueado', '40M', '20M', 1.00, 30, 'Plano Teste 40 Mega Grupo S1', '2026-08-19 15:50:59'),
(4, 'S2-40Megas-10', 'S2', 'S2-R.NORMAL-10/Espera', 'S2-R.NORMAL-10/Aviso', 'S2-R.NORMAL-10/Bloqueado', '40M', '20M', 1.00, 30, 'Plano 40 Mega Grupo S2', '2026-08-19 15:50:59'),
(5, 'S1-40Megas-20', 'S1', 'S1-R.NORMAL-20/Espera', 'S1-R.NORMAL-20/Aviso', 'S1-R.NORMAL-20/Bloqueado', '40M', '20M', 1.00, 30, 'Plano Teste 40 Mega Grupo S1', '2026-08-19 15:50:59'),
(6, 'S2-40Megas-20', 'S2', 'S2-R.NORMAL-20/Espera', 'S2-R.NORMAL-20/Aviso', 'S2-R.NORMAL-20/Bloqueado', '40M', '20M', 1.00, 30, 'Plano 40 Mega Grupo S2', '2026-08-19 15:50:59'),
(7, 'S1-80Megas-01', 'S1', 'S1-R.MAIOR-01/Espera', 'S1-R.MAIOR-01/Aviso', 'S1-R.MAIOR-01/Bloqueado', '80M', '40M', 1.00, 30, 'Plano Teste 80 Mega Grupo S1', '2026-08-19 15:50:59'),
(8, 'S2-80Megas-01', 'S2', 'S2-R.MAIOR-01/Espera', 'S2-R.MAIOR-01/Aviso', 'S2-R.MAIOR-01/Bloqueado', '80M', '40M', 1.00, 30, 'Plano 80 Mega Grupo S2', '2026-08-19 15:50:59'),
(9, 'S1-80Megas-10', 'S1', 'S1-R.MAIOR-10/Espera', 'S1-R.MAIOR-10/Aviso', 'S1-R.MAIOR-10/Bloqueado', '80M', '40M', 1.00, 30, 'Plano Teste 80 Mega Grupo S1', '2026-08-19 15:50:59'),
(10, 'S2-80Megas-10', 'S2', 'S2-R.MAIOR-10/Espera', 'S2-R.MAIOR-10/Aviso', 'S2-R.MAIOR-10/Bloqueado', '80M', '40M', 1.00, 30, 'Plano 80 Mega Grupo S2', '2026-08-19 15:50:59'),
(11, 'S1-80Megas-20', 'S1', 'S1-R.MAIOR-20/Espera', 'S1-R.MAIOR-20/Aviso', 'S1-R.MAIOR-20/Bloqueado', '80M', '40M', 1.00, 30, 'Plano Teste 80 Mega Grupo S1', '2026-08-19 15:50:59'),
(12, 'S2-80Megas-20', 'S2', 'S2-R.MAIOR-20/Espera', 'S2-R.MAIOR-20/Aviso', 'S2-R.MAIOR-20/Bloqueado', '80M', '40M', 1.00, 30, 'Plano 80 Mega Grupo S2', '2026-08-19 15:50:59'),
(13, 'S1-100Megas-01', 'S1', 'S1-R.SUPER-01/Espera', 'S1-R.SUPER-01/Aviso', 'S1-R.SUPER-01/Bloqueado', '100M', '60M', 1.00, 30, 'Plano Teste 100 Mega Grupo S1', '2026-08-19 15:50:59'),
(14, 'S2-100Megas-01', 'S2', 'S2-R.SUPER-01/Espera', 'S2-R.SUPER-01/Aviso', 'S2-R.SUPER-01/Bloqueado', '100M', '60M', 1.00, 30, 'Plano 100 Mega Grupo S2', '2026-08-19 15:50:59'),
(15, 'S1-100Megas-10', 'S1', 'S1-R.SUPER-10/Espera', 'S1-R.SUPER-10/Aviso', 'S1-R.SUPER-10/Bloqueado', '100M', '60M', 1.00, 30, 'Plano Teste 100 Mega Grupo S1', '2026-08-19 15:50:59'),
(16, 'S2-100Megas-10', 'S2', 'S2-R.SUPER-10/Espera', 'S2-R.SUPER-10/Aviso', 'S2-R.SUPER-10/Bloqueado', '100M', '60M', 1.00, 30, 'Plano 100 Mega Grupo S2', '2026-08-19 15:50:59'),
(17, 'S1-100Megas-20', 'S1', 'S1-R.SUPER-20/Espera', 'S1-R.SUPER-20/Aviso', 'S1-R.SUPER-20/Bloqueado', '100M', '60M', 1.00, 30, 'Plano Teste 100 Mega Grupo S1', '2026-08-19 15:50:59'),
(18, 'S2-100Megas-20', 'S2', 'S2-R.SUPER-20/Espera', 'S2-R.SUPER-20/Aviso', 'S2-R.SUPER-20/Bloqueado', '100M', '60M', 1.00, 30, 'Plano 100 Mega Grupo S2', '2026-08-19 15:50:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `roteadores`
--

CREATE TABLE `roteadores` (
  `id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `ip_host` varchar(100) NOT NULL,
  `porta_api` int DEFAULT '8728',
  `usuario` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `usar_ssl` tinyint(1) DEFAULT '0',
  `status` varchar(20) DEFAULT 'desconectado',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `roteadores`
--

INSERT INTO `roteadores` (`id`, `nome`, `ip_host`, `porta_api`, `usuario`, `senha`, `usar_ssl`, `status`, `criado_em`) VALUES
(1, 'MikroTik Principal', 'd4440d2c5836.sn.mynetname.net', 8828, 'aplicacao', '81660848agape99334425', 0, 'desconectado', '2026-08-19 15:50:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `webhook_logs`
--

CREATE TABLE `webhook_logs` (
  `id` int NOT NULL,
  `tipo` varchar(50) DEFAULT 'webhook',
  `mensagem` text,
  `dados` longtext,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `whatsapp_disparos`
--

CREATE TABLE `whatsapp_disparos` (
  `id` int NOT NULL,
  `fatura_id` int NOT NULL,
  `cliente_id` int NOT NULL,
  `nome_cliente` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `whatsapp` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tipo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'cobranca',
  `status` enum('enviado','falhou') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'falhou',
  `erro_msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `whatsapp_disparos`
--

INSERT INTO `whatsapp_disparos` (`id`, `fatura_id`, `cliente_id`, `nome_cliente`, `whatsapp`, `tipo`, `status`, `erro_msg`, `criado_em`) VALUES
(14, 38, 185, 'ppp7', '8296934434', 'confirmacao', 'enviado', NULL, '2026-09-10 13:07:26'),
(15, 37, 184, 'ppp8', '8299334425', 'aviso_bloqueio', 'falhou', 'Falha ao enviar o corpo do aviso de vencimento.', '2026-09-11 11:15:26'),
(16, 37, 184, 'ppp8', '8299334425', 'aviso_bloqueio', 'enviado', NULL, '2026-09-11 11:17:22');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `administradores`
--
ALTER TABLE `administradores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf_cnpj` (`cpf_cnpj`),
  ADD UNIQUE KEY `pppoe_usuario` (`pppoe_usuario`),
  ADD KEY `plano_id` (`plano_id`),
  ADD KEY `roteador_id` (`roteador_id`);

--
-- Índices para tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `faturas`
--
ALTER TABLE `faturas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `plano_id` (`plano_id`),
  ADD KEY `idx_external_reference` (`external_reference`),
  ADD KEY `idx_gateway_status` (`gateway_status`);

--
-- Índices para tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Índices para tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `mikrotik_payment_history`
--
ALTER TABLE `mikrotik_payment_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_cli_ano_mes` (`cliente_id`,`ano`,`mes`);

--
-- Índices para tabela `planos`
--
ALTER TABLE `planos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `roteadores`
--
ALTER TABLE `roteadores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `webhook_logs`
--
ALTER TABLE `webhook_logs`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `whatsapp_disparos`
--
ALTER TABLE `whatsapp_disparos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fatura` (`fatura_id`),
  ADD KEY `idx_cliente` (`cliente_id`),
  ADD KEY `idx_criado` (`criado_em`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `administradores`
--
ALTER TABLE `administradores`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT de tabela `faturas`
--
ALTER TABLE `faturas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1238;

--
-- AUTO_INCREMENT de tabela `mikrotik_payment_history`
--
ALTER TABLE `mikrotik_payment_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1706;

--
-- AUTO_INCREMENT de tabela `planos`
--
ALTER TABLE `planos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `roteadores`
--
ALTER TABLE `roteadores`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `webhook_logs`
--
ALTER TABLE `webhook_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `whatsapp_disparos`
--
ALTER TABLE `whatsapp_disparos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`plano_id`) REFERENCES `planos` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `clientes_ibfk_2` FOREIGN KEY (`roteador_id`) REFERENCES `roteadores` (`id`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `faturas`
--
ALTER TABLE `faturas`
  ADD CONSTRAINT `faturas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `faturas_ibfk_2` FOREIGN KEY (`plano_id`) REFERENCES `planos` (`id`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  ADD CONSTRAINT `historico_pagamentos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `mikrotik_payment_history`
--
ALTER TABLE `mikrotik_payment_history`
  ADD CONSTRAINT `mikrotik_payment_history_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
