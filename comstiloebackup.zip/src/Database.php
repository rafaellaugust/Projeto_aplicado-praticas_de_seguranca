<?php

/**
 * Singleton PDO Database Wrapper
 */
class Database {
    private static ?PDO $instance = null;

    public static function getInstance(): PDO {
        if (self::$instance === null) {
            try {
                $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHAR;
                $options = [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ];
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                die("Erro de Conexão com o Banco de Dados: " . $e->getMessage());
            }
        }
        return self::$instance;
    }

    public static function log($tipo, $mensagem, $detalhes = null) {
        try {
            $db = self::getInstance();
            $stmt = $db->prepare("INSERT INTO logs (tipo, mensagem, detalhes) VALUES (?, ?, ?)");
            $stmt->execute([$tipo, $mensagem, is_array($detalhes) || is_object($detalhes) ? json_encode($detalhes, JSON_UNESCAPED_UNICODE) : $detalhes]);
        } catch (Exception $e) {
            // Ignora falhas no log para não travar a aplicação
        }
    }
}
