-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 29-Ago-2026 às 10:40
-- Versão do servidor: 8.0.46
-- versão do PHP: 8.1.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dados: `spaconet_aplicacao`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `administradores`
--

CREATE TABLE `administradores` (
  `id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `administradores`
--

INSERT INTO `administradores` (`id`, `nome`, `email`, `senha`, `criado_em`) VALUES
(1, 'Administrador', 'admin@admin.com', '$2y$10$wT8fS03G00m.8w6/qY4l8u7Z3Zz5k4X4y6Z7W8v9U0t1S2R3Q4P5O', '2026-08-19 15:50:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int NOT NULL,
  `nome` varchar(150) NOT NULL,
  `cpf_cnpj` varchar(20) NOT NULL,
  `whatsapp` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `endereco` text,
  `pppoe_usuario` varchar(100) NOT NULL,
  `pppoe_senha` varchar(100) NOT NULL,
  `plano_id` int DEFAULT NULL,
  `roteador_id` int DEFAULT '1',
  `status` enum('ativo','suspenso','cancelado','aviso') DEFAULT 'ativo',
  `vencimento_dia` int DEFAULT '10',
  `data_expiracao` date DEFAULT NULL,
  `sincronizado_mikrotik` tinyint(1) DEFAULT '0',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `cpf_cnpj`, `whatsapp`, `email`, `endereco`, `pppoe_usuario`, `pppoe_senha`, `plano_id`, `roteador_id`, `status`, `vencimento_dia`, `data_expiracao`, `sincronizado_mikrotik`, `criado_em`) VALUES
(5, 'ppp8', '99930351748', '558296934435', '', '', 'ppp8', '12345', 2, 1, 'ativo', 10, '2026-09-27', 1, '2026-08-27 08:33:32'),
(7, 'ppp7', '99974611646', '558296934434', '', '', 'ppp7', '12345', 1, 1, 'ativo', 10, '2026-09-27', 1, '2026-08-27 09:16:29');

-- --------------------------------------------------------

--
-- Estrutura da tabela `configuracoes`
--

CREATE TABLE `configuracoes` (
  `id` int NOT NULL DEFAULT '1',
  `empresa_nome` varchar(150) DEFAULT 'Meu Provedor ISP',
  `empresa_cnpj` varchar(20) DEFAULT '',
  `empresa_telefone` varchar(20) DEFAULT '',
  `wa_api_url` varchar(255) DEFAULT 'http://localhost:21465',
  `wa_session` varchar(100) DEFAULT 'default',
  `wa_token` varchar(255) DEFAULT '',
  `wa_status` tinyint(1) DEFAULT '0',
  `telegram_bot_token` varchar(255) DEFAULT '',
  `telegram_chat_id` varchar(100) DEFAULT '',
  `telegram_ativo` tinyint(1) DEFAULT '0',
  `gateway_provider` varchar(50) DEFAULT 'mercadopago',
  `mp_public_key` varchar(255) DEFAULT '',
  `mp_access_token` varchar(255) DEFAULT '',
  `mp_client_id` varchar(100) DEFAULT '',
  `mp_client_secret` varchar(255) DEFAULT '',
  `mp_sandbox` tinyint(1) DEFAULT '0',
  `asaas_api_key` varchar(255) DEFAULT '',
  `pix_chave_estatica` varchar(255) DEFAULT 'financeiro@spaconett.com',
  `pix_nome_beneficiario` varchar(100) DEFAULT 'SPACONETT PROVEDOR',
  `pix_cidade_beneficiario` varchar(100) DEFAULT 'SAO PAULO',
  `webhook_secret` varchar(100) DEFAULT 'secret123',
  `atualizado_em` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `app_url` varchar(255) DEFAULT 'https://aplicacao.spaconett.com',
  `webhook_callback_url` varchar(255) DEFAULT NULL,
  `webhook_callback_ativo` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `configuracoes`
--

INSERT INTO `configuracoes` (`id`, `empresa_nome`, `empresa_cnpj`, `empresa_telefone`, `app_url`, `wa_api_url`, `wa_session`, `wa_token`, `wa_status`, `telegram_bot_token`, `telegram_chat_id`, `telegram_ativo`, `gateway_provider`, `mp_public_key`, `mp_access_token`, `mp_client_id`, `mp_client_secret`, `mp_sandbox`, `asaas_api_key`, `pix_chave_estatica`, `pix_nome_beneficiario`, `pix_cidade_beneficiario`, `webhook_secret`, `atualizado_em`, `webhook_callback_url`, `webhook_callback_ativo`) VALUES
(1, 'SpacoNett', '', '', 'https://aplicacao.spaconett.com', 'http://aplicacao.spaconett.com/whatsapp', 'default', '81660848', 0, '1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0', '-494177619', 1, 'mercadopago', '', 'APP_USR-5748377013323719-120822-e8a932a0e159f5aa5925cab3764e776d-142008628', '', '', 0, '', '', '', '', 'secret123', '2026-08-29 10:16:56', 'https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;amp;amp;amp;amp;text=foi', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `faturas`
--

CREATE TABLE `faturas` (
  `id` int NOT NULL,
  `cliente_id` int NOT NULL,
  `plano_id` int DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `meses_cobertos` int NOT NULL DEFAULT '1',
  `data_vencimento` date NOT NULL,
  `data_pagamento` datetime DEFAULT NULL,
  `status` enum('pendente','pago','atrasado','cancelado') DEFAULT 'pendente',
  `forma_pagamento` varchar(50) DEFAULT 'PIX',
  `pix_txid` varchar(100) DEFAULT NULL,
  `pix_copia_cola` text,
  `qr_code` text,
  `pix_qr_code_base64` longtext,
  `gateway_id` varchar(100) DEFAULT NULL,
  `mp_payment_id` varchar(100) DEFAULT NULL,
  `gateway_status` varchar(50) DEFAULT 'pending',
  `expiration_date` datetime DEFAULT NULL,
  `external_reference` varchar(255) DEFAULT NULL,
  `notificado_wa` tinyint(1) DEFAULT '0',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `faturas`
--

INSERT INTO `faturas` (`id`, `cliente_id`, `plano_id`, `valor`, `descricao`, `meses_cobertos`, `data_vencimento`, `data_pagamento`, `status`, `forma_pagamento`, `pix_txid`, `pix_copia_cola`, `qr_code`, `pix_qr_code_base64`, `gateway_id`, `mp_payment_id`, `gateway_status`, `expiration_date`, `external_reference`, `notificado_wa`, `criado_em`) VALUES
(12, 5, 2, 1.00, 'Mensalidade 08/2026', 1, '2026-08-10', '2026-08-28 14:40:52', 'pago', 'PIX', 'FATURA_12_9a76ec1be9_1787937737', '00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17606025551863048E54', '00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17606025551863048E54', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX///8AAABVwtN+AAAKvElEQVR42uzdT3IaSxIH4FKwYKkjcBSOJh2No3AEliwI9cTINJWZXSD5+Q/tiO+3ke0Zuj+0y5dVmU1ERERERERERERERERERERERERERERERERERERE/my20yKH+L+/TtP79Y9v5f/X2ub6s7W2u/6cH3poL9N0am0/fZSHXK5/yh+eFg+npaWlpaWlpaWlpaWlpf1l7bH8fX5R+//P6fqizxduPv/9U30sL5yz//+/nPtXnaK2qnejr/rjIbS0tLS0tLS0tLS0tLTr1fZKc6D9zKmXq7M2lae7ey+4Puzt9pDp+vBaMM/V95mWlpaWlpaWlpaWlpb239LO5erU1afYOc3lam12Xl/4o9Y9xMI5dEzf41ekpaWlpaWlpaWlpaWl/fe1h1uT86PXunO5enx0iPd87aBO8at/pEO906JzSktLS0tLS0tLS0tLS0v7J7TltHArD55Kq/Zy/yH72CxO+ejK+ejx/KFfO9tMS0tLS0tLS0tLS0tL+ze1y8lFdejQS1eGF/WydS6cz0X7Ew/5hTlLtLS0tLS0tLS0tLS0tH9Ney+v/YPLoUP11HCuefvkonDntF9gDdr5778cWlpaWlpaWlpaWlpa2r+m3fWjsmmLyv523nZOvi7aX7Rdlqv7eGF1GtW843FHyz0utLS0tLS0tLS0tLS0tOvRhruTfejQdG16zudtP5a18Nz0rA/Zj8YfTf0WZ9UOO6Zfnr+lpaWlpaWlpaWlpaWlpf157bR8QYvFdejzLte2tKU2TS6q60fnhxzLfyuYaGlpaWlpaWlpaWlpadepHUyfbbfrornm7ROLBsr5q/cmcS6U32+nhnPTeNgs/qIrTUtLS0tLS0tLS0tLS/tc7Z2atx743ZS7prX5eS4vPhVtunNajxy33rtttLS0tLS0tLS0tLS0tOvUDirNuVxdnr/d9F2cqem5LXdNz/0rHuLkorSKpeZMS0tLS0tLS0tLS0tLS/u7tXVdS1/yOejzvpYKfX7BbnFdNPd1q+49NotTx7nR0tLS0tLS0tLS0tLS/gvalNdYruYX9n7v1K+LpiZxqnnzndOpHDnuY5DOveP8aHIRLS0tLS0tLS0tLS0t7RO1rZzVnZud4ecUr4/WzaHDI8fn/pX73Nu6QKaVwnmeWLR9PLmIlpaWlpaWlpaWlpaW9onabS9b9/HaaOtl6xSPzD44OtsnFz0YQvS2qHkHq1i+6JzS0tLS0tLS0tLS0tLS0n5HO5izVJd+vrf2cF1LbdGmsn4fjx7PDwvqfvR42y+wHmhpaWlpaWlpaWlpaWnXqR2Wp2HnS+rzbkrNe1nufEmnhcPimHb7yq2cGh5X37S0tLS0tLS0tLS0tLRr1Oa1LdeKM18XXa5r2QzvmvYXpV/BSx9/9Lp8yHKBzHc6p7S0tLS0tLS0tLS0tLTP0W6jsqXm5+G2MbSWq/OwocE53H1/WBp/9Pbl5KKpTOKlpaWlpaWlpaWlpaWlXbW2lqmpc/oa597OZWrYxXksD10+JJ+/nWvc/jP/3mhpaWlpaWlpaWlpaWlpf4P2GO+azqeFpzJoN70wL/1MRfbhduB3MOL31Cvz98WH6/gjWlpaWlpaWlpaWlpa2vVpB3dPp0WtG/q898rVNER3Wl5kraeFu/JSqu/vhJaWlpaWlpaWlpaWlvZp2l28LjrXvA+bnnPHNNw93ZUX9YlF+bTwPES3fuV5iO53pvXS0tLS0tLS0tLS0tLSPks7rHXzi1qped+u52/TuKNpNP4oPeQltV1T5zTcPS2/N1paWlpaWlpaWlpaWlraX9SWLmtV5r/3XNKR4/svel3+Kt5Gfd5jGf1LS0tLS0tLS0tLS0tLuzJt6LLuF+VqfmFa+rmLE4y2adDucm1LWByTat76kOl7XWlaWlpaWlpaWlpaWlraJ2pT7dt6kzOtawkTjPrkosH827459CM9bLrdOZ3Sr6LeOf2y5qWlpaWlpaWlpaWlpaV9onbbX7g8f5vzdn3w2+2o7Ob++dtZd7gVyh/Dh9Xzt2USLy0tLS0tLS0tLS0tLS3tf9bOdfK5zFmaK/Sqn0clHe+X+enDh1t/ty1H/6aRv0HSaGlpaWlpaWlpaWlpaVer3X1RrvaJRWH5573roenOaah1l5tD68jf7fdqXlpaWlpaWlpaWlpaWtrnasOLrrVv1c6nhi/p1PCy1k0XV1sqoNOF1TRE9/Lo3DItLS0tLS0tLS0tLS3t2rS7coT2cNN/9LL1NQ4d2txZvXIud05fv+6c9jFI5zJDiZaWlpaWlpaWlpaWlnZ92jC6tsUy9d4Wldabn3107Xx0NtTC+5F2mE26R/q4LKelpaWlpaWlpaWlpaWl/b42qA/xZ1j2+R7vnoYhQ728D0eOD7cLrB/DjaFVOcUJRsfWaGlpaWlpaWlpaWlpaVeurS9Kp4fnnS+1RZvWtdRTw1O5uBoK6c9Twq9xcUzYXbqcoURLS0tLS0tLS0tLS0u7Km0+JVxe9FJq3stw/m16Ucpge8pnrXuKHdOwiuX4jcqclpaWlpaWlpaWlpaW9onaYX6Up/vbi176C07xBffm4G57p3R/m3/7USYXDTqlu9vh3YmWlpaWlpaWlpaWlpaW9jdow3SjPmcpFddZO7+oLIoJDzl35f525LhW7lPq86Y7p7S0tLS0tLS0tLS0tLQr19Z9ncOdL/XFm2Fr9trvnQvn+a7poHAOfd761WlpaWlpaWlpaWlpaWnXqK3zb7flgG/d+ZJq3suwXC3rR1/6xdXW14/2rxYK6Pnn4cHZZlpaWlpaWlpaWlpaWtqna9OL2vWO6fyZXuvmzaGp7VrvnvY2bF3B0tLF1WnRhm1fbg6lpaWlpaWlpaWlpaWlpf2mdop93m1/QWrRTnFa76BFe7x9OGhPXT3dKvTw1Y+ttaKmpaWlpaWlpaWlpaWlXbM2zAu6P3B3ShOL3uPSz9TnTQd9X5basOulbwy9LKvvR6GlpaWlpaWlpaWlpaV9ojafFk4d0/1UUzeF5nUt0yjL9mtYP7qLk4uC6EBLS0tLS0tLS0tLS0u7Wu1UptG2qD3F2vfSX9SW82+Hh3jTEN0HeSihpaWlpaWlpaWlpaWlXYl2oB9evAxla2p67pYvKso6RDfv4lx+7vwTm0NpaWlpaWlpaWlpaWlpab+vTQd96+bQesR40++a3r8u+pIurs5l/rJ5HDrOtLS0tLS0tLS0tLS0tCvVbu8c8A13TZfzb4M2TC7qL9r2hxyiNmwOHS6OoaWlpaWlpaWlpaWlpV2/9ninc1pPCydtK03PuoplLpj3t4lFczapg5pq3i87p7S0tLS0tLS0tLS0tLRr0Kabn73mzUdoU7NzV5qe9fpofcjbaIvKg7untLS0tLS0tLS0tLS0tLR/RJsr9LdYqc9F9jGeGs4vuDaLX3rTuLWwfrQ2h6vyO7OFaWlpaWlpaWlpaWlpaVerrXdO3xa1bxg6VBfH9CZxaBaflg+p22doaWlpaWlpaWlpaWlp16sdnhZusVw93fn8bhpnWevOX/WSPtzXj+YjyLS0tLS0tLS0tLS0tLQr1X41uajFBSjh7mmdXPSZfue0Piycvz3F9uumV9vHUcFMS0tLS0tLS0tLS0tLS/vftCIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiKrzv8CAAD//7hGrBYXEAbOAAAAAElFTkSuQmCC', '176060255518', '176060255518', 'pending', '2026-08-29 14:22:17', 'FATURA_12_9a76ec1be9_1787937737', 0, '2026-08-28 14:19:00'),
(13, 7, 1, 1.00, 'Mensalidade 08/2026', 1, '2026-08-10', NULL, 'pendente', 'PIX', NULL, NULL, NULL, NULL, NULL, NULL, 'pending', NULL, NULL, 1, '2026-08-28 14:19:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `historico_pagamentos`
--

CREATE TABLE `historico_pagamentos` (
  `id` int NOT NULL,
  `cliente_id` int NOT NULL,
  `fatura_id` int DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `forma_pagamento` varchar(50) DEFAULT 'PIX',
  `data_pagamento` datetime DEFAULT CURRENT_TIMESTAMP,
  `comprovante_ref` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logs`
--

CREATE TABLE `logs` (
  `id` int NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `mensagem` text NOT NULL,
  `detalhes` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `logs`
--

INSERT INTO `logs` (`id`, `tipo`, `mensagem`, `detalhes`, `criado_em`) VALUES
(1, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:51:15'),
(2, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:51:23'),
(3, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:51:46'),
(4, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:51:49'),
(5, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:03'),
(6, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:07'),
(7, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:13'),
(8, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:25'),
(9, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:36'),
(10, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:51'),
(11, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:52'),
(12, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:52:56'),
(13, 'mikrotik', 'Erro de conexão socket com 192.168.88.1:8728 (Connection refused)', NULL, '2026-08-19 15:54:27'),
(14, 'whatsapp', 'Erro ao enviar WhatsApp para 5511972532239', '{\"code\":0,\"response\":false}', '2026-08-26 08:46:24'),
(15, 'whatsapp', 'Erro ao enviar WhatsApp para 5511972532239', '{\"code\":0,\"response\":false}', '2026-08-26 08:53:30'),
(16, 'mikrotik', 'Conexao estabelecida com d4440d2c5836.sn.mynetname.net:8828 (login novo)', NULL, '2026-08-26 13:35:19'),
(17, 'mikrotik', 'Conexao estabelecida com d4440d2c5836.sn.mynetname.net:8828 (login novo)', NULL, '2026-08-26 13:35:20'),
(18, 'mikrotik', 'Conexao estabelecida com d4440d2c5836.sn.mynetname.net:8828 (login novo)', NULL, '2026-08-26 13:35:22'),
(19, 'mikrotik', 'Conexao estabelecida com d4440d2c5836.sn.mynetname.net:8828 (login novo)', NULL, '2026-08-26 13:35:38'),
(20, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Bloqueado [R1]', NULL, '2026-08-26 13:43:30'),
(21, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-26 13:45:05'),
(22, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-08-26 14:13:41'),
(23, 'whatsapp', 'Erro ao enviar WhatsApp para 5511972532239', '{\"code\":0,\"response\":false}', '2026-08-26 15:39:06'),
(24, 'gateway', 'MP falhou fatura #1: Invalid user identification number', '{\"success\":false,\"message\":\"Invalid user identification number\",\"http_code\":400,\"response\":\"{\\\"cause\\\":[{\\\"code\\\":2067,\\\"data\\\":\\\"26-08-2026T22:32:59UTC;f5146736-e305-4d03-83dd-9337852ce17b\\\",\\\"description\\\":\\\"Invalid user identification number\\\"}],\\\"error\\\":\\\"bad_request\\\",\\\"message\\\":\\\"Invalid user identification number\\\",\\\"status\\\":400}\"}', '2026-08-26 19:32:59'),
(25, 'webhook', 'MP notification', '{\"get\":{\"id\":\"174896141791\",\"topic\":\"payment\"},\"body\":{\"resource\":\"174896141791\",\"topic\":\"payment\"}}', '2026-08-27 08:15:37'),
(26, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"174896141791\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"174896141791\"},\"date_created\":\"2026-08-27T11:15:36Z\",\"id\":136761690239,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-27 08:15:37'),
(27, 'webhook', 'Consulta MP 174896141791 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M11EXEBXR7A09RCX07ECA320\\\",\\\"id\\\":\\\"174896141791-001\\\",\\\"last_updated\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-27T07:15:36.454-04:00\\\",\\\"execution_id\\\":\\\"01M11EXEATJ16KE508PSNARH5Z\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-27 08:15:37'),
(28, 'webhook', 'Consulta MP 174896141791 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M11EXEBXR7A09RCX07ECA320\\\",\\\"id\\\":\\\"174896141791-001\\\",\\\"last_updated\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-27T07:15:36.454-04:00\\\",\\\"execution_id\\\":\\\"01M11EXEATJ16KE508PSNARH5Z\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-27 08:15:37'),
(29, 'webhook', 'MP notification', '{\"get\":{\"id\":\"174896141791\",\"topic\":\"payment\"},\"body\":{\"resource\":\"174896141791\",\"topic\":\"payment\"}}', '2026-08-27 08:22:17'),
(30, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"174896141791\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"174896141791\"},\"date_created\":\"2026-08-27T11:15:36Z\",\"id\":136922808008,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-27 08:22:18'),
(31, 'webhook', 'Consulta MP 174896141791 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":false},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M11EXEBXR7A09RCX07ECA320\\\",\\\"id\\\":\\\"174896141791-001\\\",\\\"last_updated\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-27T07:15:36.454-04:00\\\",\\\"execution_id\\\":\\\"01M11EXEATJ16KE508PSNARH5Z\\\"}},\\\"collector_id\\\":142008628,\\\"corporat\"}', '2026-08-27 08:22:18'),
(32, 'webhook', 'Consulta MP 174896141791 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":false},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M11EXEBXR7A09RCX07ECA320\\\",\\\"id\\\":\\\"174896141791-001\\\",\\\"last_updated\\\":\\\"2026-08-27T07:15:36.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-27T07:15:36.454-04:00\\\",\\\"execution_id\\\":\\\"01M11EXEATJ16KE508PSNARH5Z\\\"}},\\\"collector_id\\\":142008628,\\\"corporat\"}', '2026-08-27 08:22:18'),
(33, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 08:22:19'),
(34, 'whatsapp', 'Erro ao enviar WhatsApp para 5511972532239', '{\"code\":0,\"response\":false}', '2026-08-27 08:22:20'),
(35, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 08:22:24'),
(36, 'whatsapp', 'Erro ao enviar WhatsApp para 5511972532239', '{\"code\":0,\"response\":false}', '2026-08-27 08:22:25'),
(37, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 08:25:07'),
(38, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 08:25:16'),
(39, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-10/Espera [R1]', NULL, '2026-08-27 10:09:23'),
(40, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-10/Espera [R1]', NULL, '2026-08-27 10:09:40'),
(41, 'mikrotik', 'PPPoE ppp7 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 11:35:47'),
(42, 'mikrotik', 'PPPoE ppp7 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 11:36:05'),
(43, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-10/Espera [R1]', NULL, '2026-08-27 11:37:19'),
(44, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 11:37:44'),
(45, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 11:38:05'),
(46, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Bloqueado [R1]', NULL, '2026-08-27 11:38:27'),
(47, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 11:38:45'),
(48, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Bloqueado [R1]', NULL, '2026-08-27 11:41:33'),
(49, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 11:41:47'),
(50, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 11:53:19'),
(51, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 11:53:37'),
(52, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Bloqueado [R1]', NULL, '2026-08-27 11:53:48'),
(53, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Bloqueado [R1]', NULL, '2026-08-27 11:53:54'),
(54, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 11:54:11'),
(55, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 11:54:45'),
(56, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 11:55:07'),
(57, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 11:55:22'),
(58, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 12:59:48'),
(59, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:03:59'),
(60, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 13:04:18'),
(61, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:04:42'),
(62, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 13:05:45'),
(63, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:10:25'),
(64, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:11:00'),
(65, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 13:11:11'),
(66, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:11:41'),
(67, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:14:05'),
(68, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 13:14:46'),
(69, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:15:27'),
(70, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Bloqueado [R1]', NULL, '2026-08-27 13:15:49'),
(71, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 13:16:27'),
(72, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:16:56'),
(73, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-08-27 13:17:11'),
(74, 'mikrotik', 'PPPoE ppp8 -> S1-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 13:18:36'),
(75, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-27 13:18:52'),
(76, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176001496964\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176001496964\"},\"date_created\":\"2026-08-28T11:03:07Z\",\"id\":136963323438,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 08:03:08'),
(77, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176001496964\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176001496964\",\"topic\":\"payment\"}}', '2026-08-28 08:03:08'),
(78, 'webhook', 'Consulta MP 176001496964 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M140KA5MPQFYE15F4N94J1NT\\\",\\\"id\\\":\\\"176001496964-001\\\",\\\"last_updated\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T07:03:07.710-04:00\\\",\\\"execution_id\\\":\\\"01M140KA4B5ATH9Z3J3VK626PN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 08:03:08'),
(79, 'webhook', 'Consulta MP 176001496964 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M140KA5MPQFYE15F4N94J1NT\\\",\\\"id\\\":\\\"176001496964-001\\\",\\\"last_updated\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T07:03:07.710-04:00\\\",\\\"execution_id\\\":\\\"01M140KA4B5ATH9Z3J3VK626PN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 08:03:08'),
(80, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-28 10:16:25'),
(81, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"175070123435\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"175070123435\"},\"date_created\":\"2026-08-28T13:17:09Z\",\"id\":136805536209,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 10:17:10'),
(82, 'webhook', 'MP notification', '{\"get\":{\"id\":\"175070123435\",\"topic\":\"payment\"},\"body\":{\"resource\":\"175070123435\",\"topic\":\"payment\"}}', '2026-08-28 10:17:10'),
(83, 'webhook', 'Consulta MP 175070123435 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1488QJB0NNN1WQ5XTVT86BZ\\\",\\\"id\\\":\\\"175070123435-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:17:09.588-04:00\\\",\\\"execution_id\\\":\\\"01M1488QH8CY9E9R7MF9HS58DQ\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 10:17:10'),
(84, 'webhook', 'Consulta MP 175070123435 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1488QJB0NNN1WQ5XTVT86BZ\\\",\\\"id\\\":\\\"175070123435-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:17:09.588-04:00\\\",\\\"execution_id\\\":\\\"01M1488QH8CY9E9R7MF9HS58DQ\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 10:17:10'),
(85, 'webhook', 'MP notification', '{\"get\":{\"id\":\"175070123435\",\"topic\":\"payment\"},\"body\":{\"resource\":\"175070123435\",\"topic\":\"payment\"}}', '2026-08-28 10:18:13'),
(86, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"175070123435\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"175070123435\"},\"date_created\":\"2026-08-28T13:17:09Z\",\"id\":136966787638,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 10:18:13'),
(87, 'webhook', 'Consulta MP 175070123435 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1488QJB0NNN1WQ5XTVT86BZ\\\",\\\"id\\\":\\\"175070123435-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:17:09.588-04:00\\\",\\\"execution_id\\\":\\\"01M1488QH8CY9E9R7MF9HS58DQ\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-08-28 10:18:13'),
(88, 'webhook', 'Consulta MP 175070123435 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1488QJB0NNN1WQ5XTVT86BZ\\\",\\\"id\\\":\\\"175070123435-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:17:09.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:17:09.588-04:00\\\",\\\"execution_id\\\":\\\"01M1488QH8CY9E9R7MF9HS58DQ\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-08-28 10:18:13'),
(89, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-08-28 10:18:14'),
(90, 'mikrotik', 'PPPoE ppp7 -> S1-R.NORMAL-01/Espera [R1]', NULL, '2026-08-28 10:18:14'),
(91, 'mikrotik', 'Webhook pagamento: ppp7 → S1-R.NORMAL-01/Espera (1 meses)', NULL, '2026-08-28 10:18:15'),
(92, 'whatsapp', 'Erro ao enviar WhatsApp para 5511971394441', '{\"code\":0,\"response\":false}', '2026-08-28 10:18:15'),
(93, 'mikrotik', 'Webhook pagamento: ppp7 → S1-R.NORMAL-01/Espera (1 meses)', NULL, '2026-08-28 10:18:16'),
(94, 'whatsapp', 'Erro ao enviar WhatsApp para 5511971394441', '{\"code\":0,\"response\":false}', '2026-08-28 10:18:16'),
(95, 'whatsapp', 'Erro ao enviar WhatsApp para 5511938502177', '{\"code\":0,\"response\":false}', '2026-08-28 10:20:04'),
(96, 'whatsapp', 'Erro ao enviar WhatsApp para 5511938502177', '{\"code\":0,\"response\":false}', '2026-08-28 10:20:17'),
(97, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176020432992\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176020432992\",\"topic\":\"payment\"}}', '2026-08-28 10:34:41'),
(98, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176020432992\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176020432992\"},\"date_created\":\"2026-08-28T13:34:41Z\",\"id\":136967376034,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 10:34:41'),
(99, 'webhook', 'Consulta MP 176020432992 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1498TFGQMV285BFWKQ7RDJN\\\",\\\"id\\\":\\\"176020432992-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:34:41.146-04:00\\\",\\\"execution_id\\\":\\\"01M1498TE76ZT1EHREB747VP97\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 10:34:41'),
(100, 'webhook', 'Consulta MP 176020432992 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1498TFGQMV285BFWKQ7RDJN\\\",\\\"id\\\":\\\"176020432992-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:34:41.146-04:00\\\",\\\"execution_id\\\":\\\"01M1498TE76ZT1EHREB747VP97\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 10:34:41'),
(101, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176021930130\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176021930130\",\"topic\":\"payment\"}}', '2026-08-28 10:35:29'),
(102, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176021930130\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176021930130\"},\"date_created\":\"2026-08-28T13:35:28Z\",\"id\":136967265822,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 10:35:29'),
(103, 'webhook', 'Consulta MP 176021930130 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M149A8ZFC16CB6X7N3YGCQES\\\",\\\"id\\\":\\\"176021930130-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:35:28.762-04:00\\\",\\\"execution_id\\\":\\\"01M149A8Y3W2KZZJ44KCC9VXJF\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 10:35:29'),
(104, 'webhook', 'Consulta MP 176021930130 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M149A8ZFC16CB6X7N3YGCQES\\\",\\\"id\\\":\\\"176021930130-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:35:28.762-04:00\\\",\\\"execution_id\\\":\\\"01M149A8Y3W2KZZJ44KCC9VXJF\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 10:35:29'),
(105, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 10:39:41'),
(106, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 10:40:33'),
(107, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 10:53:18'),
(108, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 10:53:49'),
(109, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 10:54:00'),
(110, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 10:58:56'),
(111, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 10:59:03'),
(112, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 11:05:54'),
(113, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176021930130\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176021930130\",\"topic\":\"payment\"}}', '2026-08-28 11:34:23'),
(114, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176021930130\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176021930130\"},\"date_created\":\"2026-08-28T13:35:28Z\",\"id\":136969275852,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 11:34:23'),
(115, 'webhook', 'Consulta MP 176021930130 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M149A8ZFC16CB6X7N3YGCQES\\\",\\\"id\\\":\\\"176021930130-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:35:28.762-04:00\\\",\\\"execution_id\\\":\\\"01M149A8Y3W2KZZJ44KCC9VXJF\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-08-28 11:34:23'),
(116, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-28 11:34:24'),
(117, 'mikrotik', 'Webhook pagamento: ppp8 → S2-R.NORMAL-01/Espera (1 meses)', NULL, '2026-08-28 11:34:26'),
(118, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 11:34:26'),
(119, 'webhook', 'Consulta MP 176021930130 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"bank_info\\\":{\\\"is_same_bank_account_owner\\\":true},\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M149A8ZFC16CB6X7N3YGCQES\\\",\\\"id\\\":\\\"176021930130-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:35:28.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:35:28.762-04:00\\\",\\\"execution_id\\\":\\\"01M149A8Y3W2KZZJ44KCC9VXJF\\\"}},\\\"collector_id\\\":142008628,\\\"corporati\"}', '2026-08-28 11:34:28'),
(120, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-28 11:34:29'),
(121, 'mikrotik', 'Webhook pagamento: ppp8 → S2-R.NORMAL-01/Espera (1 meses)', NULL, '2026-08-28 11:34:31'),
(122, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 11:34:31'),
(123, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-28 13:49:53'),
(124, 'mikrotik', 'Sync automático (cron): 2 clientes, 1 faturas criadas.', NULL, '2026-08-28 13:51:45'),
(125, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-28 13:54:54'),
(126, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-28 13:55:32'),
(127, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"175113188627\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"175113188627\"},\"date_created\":\"2026-08-28T17:12:58Z\",\"id\":136814130321,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 14:12:58'),
(128, 'webhook', 'MP notification', '{\"get\":{\"id\":\"175113188627\",\"topic\":\"payment\"},\"body\":{\"resource\":\"175113188627\",\"topic\":\"payment\"}}', '2026-08-28 14:12:58'),
(129, 'webhook', 'Consulta MP 175113188627 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T13:12:58.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M14NRGT4C5259RVEX7FDRDFK\\\",\\\"id\\\":\\\"175113188627-001\\\",\\\"last_updated\\\":\\\"2026-08-28T13:12:58.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T13:12:58.444-04:00\\\",\\\"execution_id\\\":\\\"01M14NRGRY4CG7GG345FVGQPXA\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 14:12:59'),
(130, 'webhook', 'Consulta MP 175113188627 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T13:12:58.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M14NRGT4C5259RVEX7FDRDFK\\\",\\\"id\\\":\\\"175113188627-001\\\",\\\"last_updated\\\":\\\"2026-08-28T13:12:58.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T13:12:58.444-04:00\\\",\\\"execution_id\\\":\\\"01M14NRGRY4CG7GG345FVGQPXA\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 14:12:59'),
(131, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176060255518\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176060255518\",\"topic\":\"payment\"}}', '2026-08-28 14:22:18'),
(132, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176060255518\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.created\",\"api_version\":\"v1\",\"data\":{\"id\":\"176060255518\"},\"date_created\":\"2026-08-28T17:22:18Z\",\"id\":136814385491,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-28 14:22:18'),
(133, 'webhook', 'Consulta MP 176060255518 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T13:22:18.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M14P9K7Z2Y0TZ89E3HBMP4NZ\\\",\\\"id\\\":\\\"176060255518-001\\\",\\\"last_updated\\\":\\\"2026-08-28T13:22:18.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T13:22:17.992-04:00\\\",\\\"execution_id\\\":\\\"01M14P9K6PN1AXSWMEKGH0M9R4\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 14:22:18'),
(134, 'webhook', 'Consulta MP 176060255518 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T13:22:18.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M14P9K7Z2Y0TZ89E3HBMP4NZ\\\",\\\"id\\\":\\\"176060255518-001\\\",\\\"last_updated\\\":\\\"2026-08-28T13:22:18.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T13:22:17.992-04:00\\\",\\\"execution_id\\\":\\\"01M14P9K6PN1AXSWMEKGH0M9R4\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-28 14:22:18'),
(135, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-28 14:26:29'),
(136, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-28 14:39:13'),
(137, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Bloqueado [R1]', NULL, '2026-08-28 14:39:41'),
(138, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Aviso [R1]', NULL, '2026-08-28 14:40:28'),
(139, 'telegram', 'Notificação enviada ao Telegram com sucesso', NULL, '2026-08-28 14:40:53'),
(140, 'webhook_callback', 'Notificação POST enviada com sucesso para: https://api.telegram.org/bot1953035198:AAH93nW4LVv1aQ85doi0YGvkSRFWPeFSFG0/sendMessage?chat_id=-4605577181&amp;amp;text=foi', NULL, '2026-08-28 14:40:53'),
(141, 'mikrotik', 'PPPoE ppp8 -> S2-R.NORMAL-01/Espera [R1]', NULL, '2026-08-28 14:40:55'),
(142, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:00:05'),
(143, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:01:03'),
(144, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:02:04'),
(145, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:03:04'),
(146, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:04:04'),
(147, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:05:04'),
(148, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:06:04'),
(149, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:07:04'),
(150, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:08:04'),
(151, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:09:04'),
(152, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:10:04'),
(153, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:11:04'),
(154, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:12:04'),
(155, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:13:04'),
(156, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:14:04'),
(157, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:15:04'),
(158, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:16:04'),
(159, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:17:04'),
(160, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:18:04'),
(161, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:19:04'),
(162, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:20:04'),
(163, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:21:04'),
(164, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:22:04'),
(165, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:23:03'),
(166, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:24:04'),
(167, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:25:04'),
(168, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:26:04'),
(169, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:27:03'),
(170, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:28:04'),
(171, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:29:03'),
(172, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:30:04'),
(173, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:31:03'),
(174, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:32:04'),
(175, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:33:04'),
(176, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:34:04'),
(177, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:35:04'),
(178, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:36:04'),
(179, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:37:04'),
(180, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:38:04'),
(181, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:39:04'),
(182, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:40:04'),
(183, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:41:04'),
(184, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:42:04'),
(185, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:43:04'),
(186, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:44:04'),
(187, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:45:04'),
(188, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:46:04'),
(189, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:47:04'),
(190, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:48:04'),
(191, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:49:04'),
(192, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:50:04'),
(193, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:51:04'),
(194, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:52:04');
INSERT INTO `logs` (`id`, `tipo`, `mensagem`, `detalhes`, `criado_em`) VALUES
(195, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:53:04'),
(196, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:54:04'),
(197, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:55:04'),
(198, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:56:04'),
(199, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:57:04'),
(200, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:58:04'),
(201, 'mikrotik', 'Sync automático (cron): 2 clientes, 0 faturas criadas.', NULL, '2026-08-29 04:59:04'),
(202, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176001496964\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176001496964\"},\"date_created\":\"2026-08-28T11:03:07Z\",\"id\":137006663560,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-29 08:05:33'),
(203, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176001496964\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176001496964\",\"topic\":\"payment\"}}', '2026-08-29 08:05:33'),
(204, 'webhook', 'Consulta MP 176001496964 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M140KA5MPQFYE15F4N94J1NT\\\",\\\"id\\\":\\\"176001496964-001\\\",\\\"last_updated\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T07:03:07.710-04:00\\\",\\\"execution_id\\\":\\\"01M140KA4B5ATH9Z3J3VK626PN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-29 08:05:33'),
(205, 'webhook', 'Fatura não encontrada ext FATURA_2_bca95f7298_1787914986', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.171.0-rc-1\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-08-28T07:03:07.000-04:00\",\"external_charge_id\":\"01M140KA5MPQFYE15F4N94J1NT\",\"id\":\"176001496964-001\",\"last_updated\":\"2026-08-28T07:03:07.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-08-28T07:03:07.710-04:00\",\"execution_id\":\"01M140KA4B5ATH9Z3J3VK626PN\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-08-28T07:03:07.000-04:00\",\"date_last_updated\":\"2026-08-29T07:05:32.000-04:00\",\"date_of_expiration\":\"2026-08-29T07:03:07.000-04:00\",\"deduction_schema\":null,\"description\":\"Fatura #2 - S2-40Megas-01\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_2_bca95f7298_1787914986\",\"fee_details\":[],\"financing_group\":null,\"id\":176001496964,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_2_bca95f7298_1787914986_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"http:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3648972604\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter176001496964630442F8\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKuElEQVR42uzdQXIiOxIGYDlY1NJH4CgcDY7mo\\/gIXrIgqIn2UChTUtl0uLupmfj+DY9+UPrwLkNSZhERERERERERERERERERERERERERERERERERERGRv5tp7vJWXub549f\\/DK\\/zPJ9+\\/efr7UPvpSyf\\/3zI5\\/tzfe5hvqbX469Pfvx6vdSHfH65lLLvEbS0tLS0tLS0tLS0tLS0f0D73rxftJ8LLQ\\/+VO+aB+76BQ43\\/dx8+Xh7f7p96XRTlvhafyotLS0tLS0tLS0tLS3thrWpfO1r3nIrWy\\/pNdW+73WhW+Ecat\\/0k0tSV+1SfZ9paWlpaWlpaWlpaWlp\\/+e0y4KpbJ2bcnV3U06j2veatHXb9VLf72lpaWlpaWlpaWlpaWn\\/j7Qvt3++3j68qzuo7ZdSzr225lLVtLS0tLS0tLS0tLS0tLR\\/XducFi7NAqEyX\\/Z59\\/XuaXpIOi0c9n1Pt03jdOd0+dLPzjbT0tLS0tLS0tLS0tLS\\/kvtWueiukWbFzrda95LLVeXzkWH5sjxow\\/5cZ8lWlpaWlpaWlpaWlpa2n+gHWZZKOSj\\/9Tc1b6DmreMCuiPWDhfyg9DS0tLS0tLS0tLS0tL+y+1+3jqdbDpmfrfhruna+Vq+tLhrn5JD6krX5rzt9\\/UvLS0tLS0tLS0tLS0tLTP1S6tbN+6mjc0HSpl9RbnUvMuD2kettS8gykq6e\\/VDvikpaWlpaWlpaWlpaWlpf2xNtTHqU5eOhedYnE9N02I2qPHb+Xr8aPH+JoGxkyp9S8tLS0tLS0tLS0tLS3tRrXDmje8P8Zyddj\\/NmwWt0eO+5p3eeilHjkutwurZVQw09LS0tLS0tLS0tLS0m5HG2rdtzvgurJgu1MaFuq1Ocd77Xu5vR8cOU7tj2hpaWlpaWlpaWlpaWm3q13umJ5rzVvvmr40m56Xeh53rsrm4upcy9fXpmNROIfbbr8+0q2XlpaWlpaWlpaWlpaWlvYRbZjbeWhOCS85xUq99KeG2wO+9SFty9+5ucDa9lXaP9YVipaWlpaWlpaWlpaWlva52qZs\\/e+W7FKunrot2+Wa6K5uzZbYyehcBoNjrlUZjhx\\/WYXT0tLS0tLS0tLS0tLSbkw7paGfTc0bTg3PcbNzUJbuY817bo4aD04L1586uHNKS0tLS0tLS0tLS0tLu3HttD74pG86FGrepcZN40cHOTZNc9c7F31xcZWWlpaWlpaWlpaWlpaW9je0g5kvb\\/fiOlTqoVvv8dYaKR34TT+5nfkS\\/gSn++u4Qv\\/tCTW0tLS0tLS0tLS0tLS0\\/1A79Wd207DP5c5p6mS0HDG+9Fuzh\\/vrtXlYOzim1P3e4U+mpaWlpaWlpaWlpaWl3a52ik2Iwp3T4biWS9Xua9Oh2vf23Nw1HWp36eJqX33T0tLS0tLS0tLS0tLSbk8b1LXSfKkDUMLR2dNq06E8NSV9eal9j990Llpq3m\\/739LS0tLS0tLS0tLS0tI+V7u\\/n7stzfnbR2veKfXBTedt2zZIx1Hnon3UfbVzSktLS0tLS0tLS0tLS0v7uDYsdGjGtSyvx3hKOF0X\\/bKozmV++nKbdqeZlpaWlpaWlpaWlpaWdqPaZZc1TVxpmw291I5Fa+XqPp4SPseaNzxkjjNflpUvaXbpbXN4pqWlpaWlpaWlpaWlpd2yNjUfajsX5aT+t6H2TQ9L26+p722p27DhIXUP9\\/vQ0tLS0tLS0tLS0tLSPlebro3WPrcv6Z9Oo83PsHNaE7ZfD\\/eORWs179w87PxtzUtLS0tLS0tLS0tLS0tL+\\/vaetB3eFo4tEgaHvgt\\/T5v\\/ydYyvy50ad+wbS0tLS0tLS0tLS0tLSb1OYxLalz0aG5azpH9dzv8\\/YXV+c46yUrT92R46k+7O27ypyWlpaWlpaWlpaWlpb2OdoyuumZtce44GuzUGlOC6efPNfXU1NAD2vehyfU0NLS0tLS0tLS0tLS0j5H2\\/a\\/HWxylvuC4drofl5N+lIaR7rWRHdwmJeWlpaWlpaWlpaWlpaW9qfaMDk09Vkq\\/T5v7be06x\\/YP2RO2lrm72rr39SsKfULpqWlpaWlpaWlpaWlpd2kdhrN7cxbtHOzNXvquvROo269y8yX9iFrg2OmZrOYlpaWlpaWlpaWlpaWdpPaUKbWfx80HUoLLXdOQ7OhRZm07Z3TEmveoC4ljx+lpaWlpaWlpaWlpaWl3bJ2ui0wxXI1L\\/hZnobzt7XGPdey9a2EdkgfdQe13jm99BdX930TXVpaWlpaWlpaWlpaWtqNatNdynPppqiUZozm8f7gXT\\/45DAaxRLS9sFtz99+HVpaWlpaWlpaWlpaWlrax7WhyD7cF77WBef+rmktqtuDvlPc531ZaYNUarnftvot31XotLS0tLS0tLS0tLS0tJvRllh5vtYJorV83Q3HtdRmQ1PTdOh15eLqR6x5W8n3k0NpaWlpaWlpaWlpaWlpn6jdr1wXfbsf8L2mMrVeFy2p5k2jWNrORXXHdHxa+OE5p7S0tLS0tLS0tLS0tLRP1E7NDJNznZ4ynM352szcTNNTpn4wZ\\/rJpRbO9e906WteWlpaWlpaWlpaWlpaWto\\/pk3v25kvbYuk\\/oBvbtbUVOrhIXNt1rQ8pFbo7bllWlpaWlpaWlpaWlpa2k1qQ9OhYc17ilu1oVvv3Oz31s3iz4dcqypsFp+amre2PxqIaGlpaWlpaWlpaWlpaTemDTl0m5\\/tgmGC6D7unJZm23X+vnA+reyUfnu2mZaWlpaWlpaWlpaWlvbp2rpQmqLSZpc6FrXnb2vbo7T9GsaPhvO3x27ntJ1hSktLS0tLS0tLS0tLS0v7J7T1M2Hmy6Gr1Nf6LLXF9dTPeql3TsNPD9p6enimpaWlpaWlpaWlpaWl3ax2cDb3ECeHLjNfUsPdebhQKqDLSs1bL65e6mnh9yqhpaWlpaWlpaWlpaWl3bg29b8dfDa1rg3qfqFzrH2v6acfG+1w5gstLS0tLS0tLS0tLS3t9rVzMxillGXoZ9CG6SmnUvpyNQz9rJ2Lhto5\\/eT0pUemqNDS0tLS0tLS0tLS0tI+Ubt2DjddvMwzONMAlMFPHl4F7WveVjs3V0FpaWlpaWlpaWlpaWlpaf+sttSDvnNzavh4v3Oatem0cLqouvZTP8qgDdL0GzdkaWlpaWlpaWlpaWlpaZ+jnfqi8+2unfu7ph91q7aU0P\\/2vWuiGwrn137myzzqf\\/seq25aWlpaWlpaWlpaWlraTWrfRzuny0HftulQ2\\/+2fUgdP3q9HTkObY\\/aJrr7vuYd9lKipaWlpaWlpaWlpaWl3ZS23vRMYzTzQrX2vaSjsysXV9vzt0sBvVu5czo3ElpaWlpaWlpaWlpaWlrav6DNfZZK3PdNB33Dl8JB39RnqWoHLX\\/3o7um0wO9hWlpaWlpaWlpaWlpaWk3pA0170c8+DvY593fFtp3Cz5Q84Z93tqt93zbLKalpaWlpaWlpaWlpaXdqrY5LfyS+gcd79dG88KLtjSboPWo8aDmPd5r3Evz5XN6paWlpaWlpaWlpaWlpd2otu9c1LasHdw5TZNDS7PQ1Pe7PTb9cE+3L\\/d3TsvXNS8tLS0tLS0tLS0tLS0t7YNaERERERERERERERERERERERERERERERERERERkU3nPwEAAP\\/\\/eKXR43wPixkAAAAASUVORK5CYII=\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/176001496964\\/ticket?caller_id=3648972604&hash=dfa0a65a-8253-4ba2-9197-b7ef4187da52\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-08-29 08:05:33'),
(206, 'webhook', 'Consulta MP 176001496964 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M140KA5MPQFYE15F4N94J1NT\\\",\\\"id\\\":\\\"176001496964-001\\\",\\\"last_updated\\\":\\\"2026-08-28T07:03:07.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T07:03:07.710-04:00\\\",\\\"execution_id\\\":\\\"01M140KA4B5ATH9Z3J3VK626PN\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-29 08:05:33'),
(207, 'webhook', 'Fatura não encontrada ext FATURA_2_bca95f7298_1787914986', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.171.0-rc-1\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-08-28T07:03:07.000-04:00\",\"external_charge_id\":\"01M140KA5MPQFYE15F4N94J1NT\",\"id\":\"176001496964-001\",\"last_updated\":\"2026-08-28T07:03:07.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-08-28T07:03:07.710-04:00\",\"execution_id\":\"01M140KA4B5ATH9Z3J3VK626PN\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-08-28T07:03:07.000-04:00\",\"date_last_updated\":\"2026-08-29T07:05:32.000-04:00\",\"date_of_expiration\":\"2026-08-29T07:03:07.000-04:00\",\"deduction_schema\":null,\"description\":\"Fatura #2 - S2-40Megas-01\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_2_bca95f7298_1787914986\",\"fee_details\":[],\"financing_group\":null,\"id\":176001496964,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_2_bca95f7298_1787914986_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"http:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3648972604\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter176001496964630442F8\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKuElEQVR42uzdQXIiOxIGYDlY1NJH4CgcDY7mo\\/gIXrIgqIn2UChTUtl0uLupmfj+DY9+UPrwLkNSZhERERERERERERERERERERERERERERERERERERGRv5tp7vJWXub549f\\/DK\\/zPJ9+\\/efr7UPvpSyf\\/3zI5\\/tzfe5hvqbX469Pfvx6vdSHfH65lLLvEbS0tLS0tLS0tLS0tLS0f0D73rxftJ8LLQ\\/+VO+aB+76BQ43\\/dx8+Xh7f7p96XRTlvhafyotLS0tLS0tLS0tLS3thrWpfO1r3nIrWy\\/pNdW+73WhW+Ecat\\/0k0tSV+1SfZ9paWlpaWlpaWlpaWlp\\/+e0y4KpbJ2bcnV3U06j2veatHXb9VLf72lpaWlpaWlpaWlpaWn\\/j7Qvt3++3j68qzuo7ZdSzr225lLVtLS0tLS0tLS0tLS0tLR\\/XducFi7NAqEyX\\/Z59\\/XuaXpIOi0c9n1Pt03jdOd0+dLPzjbT0tLS0tLS0tLS0tLS\\/kvtWueiukWbFzrda95LLVeXzkWH5sjxow\\/5cZ8lWlpaWlpaWlpaWlpa2n+gHWZZKOSj\\/9Tc1b6DmreMCuiPWDhfyg9DS0tLS0tLS0tLS0tL+y+1+3jqdbDpmfrfhruna+Vq+tLhrn5JD6krX5rzt9\\/UvLS0tLS0tLS0tLS0tLTP1S6tbN+6mjc0HSpl9RbnUvMuD2kettS8gykq6e\\/VDvikpaWlpaWlpaWlpaWlpf2xNtTHqU5eOhedYnE9N02I2qPHb+Xr8aPH+JoGxkyp9S8tLS0tLS0tLS0tLS3tRrXDmje8P8Zyddj\\/NmwWt0eO+5p3eeilHjkutwurZVQw09LS0tLS0tLS0tLS0m5HG2rdtzvgurJgu1MaFuq1Ocd77Xu5vR8cOU7tj2hpaWlpaWlpaWlpaWm3q13umJ5rzVvvmr40m56Xeh53rsrm4upcy9fXpmNROIfbbr8+0q2XlpaWlpaWlpaWlpaWlvYRbZjbeWhOCS85xUq99KeG2wO+9SFty9+5ucDa9lXaP9YVipaWlpaWlpaWlpaWlva52qZs\\/e+W7FKunrot2+Wa6K5uzZbYyehcBoNjrlUZjhx\\/WYXT0tLS0tLS0tLS0tLSbkw7paGfTc0bTg3PcbNzUJbuY817bo4aD04L1586uHNKS0tLS0tLS0tLS0tLu3HttD74pG86FGrepcZN40cHOTZNc9c7F31xcZWWlpaWlpaWlpaWlpaW9je0g5kvb\\/fiOlTqoVvv8dYaKR34TT+5nfkS\\/gSn++u4Qv\\/tCTW0tLS0tLS0tLS0tLS0\\/1A79Wd207DP5c5p6mS0HDG+9Fuzh\\/vrtXlYOzim1P3e4U+mpaWlpaWlpaWlpaWl3a52ik2Iwp3T4biWS9Xua9Oh2vf23Nw1HWp36eJqX33T0tLS0tLS0tLS0tLSbk8b1LXSfKkDUMLR2dNq06E8NSV9eal9j990Llpq3m\\/739LS0tLS0tLS0tLS0tI+V7u\\/n7stzfnbR2veKfXBTedt2zZIx1Hnon3UfbVzSktLS0tLS0tLS0tLS0v7uDYsdGjGtSyvx3hKOF0X\\/bKozmV++nKbdqeZlpaWlpaWlpaWlpaWdqPaZZc1TVxpmw291I5Fa+XqPp4SPseaNzxkjjNflpUvaXbpbXN4pqWlpaWlpaWlpaWlpd2yNjUfajsX5aT+t6H2TQ9L26+p722p27DhIXUP9\\/vQ0tLS0tLS0tLS0tLSPlebro3WPrcv6Z9Oo83PsHNaE7ZfD\\/eORWs179w87PxtzUtLS0tLS0tLS0tLS0tL+\\/vaetB3eFo4tEgaHvgt\\/T5v\\/ydYyvy50ad+wbS0tLS0tLS0tLS0tLSb1OYxLalz0aG5azpH9dzv8\\/YXV+c46yUrT92R46k+7O27ypyWlpaWlpaWlpaWlpb2OdoyuumZtce44GuzUGlOC6efPNfXU1NAD2vehyfU0NLS0tLS0tLS0tLS0j5H2\\/a\\/HWxylvuC4drofl5N+lIaR7rWRHdwmJeWlpaWlpaWlpaWlpaW9qfaMDk09Vkq\\/T5v7be06x\\/YP2RO2lrm72rr39SsKfULpqWlpaWlpaWlpaWlpd2kdhrN7cxbtHOzNXvquvROo269y8yX9iFrg2OmZrOYlpaWlpaWlpaWlpaWdpPaUKbWfx80HUoLLXdOQ7OhRZm07Z3TEmveoC4ljx+lpaWlpaWlpaWlpaWl3bJ2ui0wxXI1L\\/hZnobzt7XGPdey9a2EdkgfdQe13jm99BdX930TXVpaWlpaWlpaWlpaWtqNatNdynPppqiUZozm8f7gXT\\/45DAaxRLS9sFtz99+HVpaWlpaWlpaWlpaWlrax7WhyD7cF77WBef+rmktqtuDvlPc531ZaYNUarnftvot31XotLS0tLS0tLS0tLS0tJvRllh5vtYJorV83Q3HtdRmQ1PTdOh15eLqR6x5W8n3k0NpaWlpaWlpaWlpaWlpn6jdr1wXfbsf8L2mMrVeFy2p5k2jWNrORXXHdHxa+OE5p7S0tLS0tLS0tLS0tLRP1E7NDJNznZ4ynM352szcTNNTpn4wZ\\/rJpRbO9e906WteWlpaWlpaWlpaWlpaWto\\/pk3v25kvbYuk\\/oBvbtbUVOrhIXNt1rQ8pFbo7bllWlpaWlpaWlpaWlpa2k1qQ9OhYc17ilu1oVvv3Oz31s3iz4dcqypsFp+amre2PxqIaGlpaWlpaWlpaWlpaTemDTl0m5\\/tgmGC6D7unJZm23X+vnA+reyUfnu2mZaWlpaWlpaWlpaWlvbp2rpQmqLSZpc6FrXnb2vbo7T9GsaPhvO3x27ntJ1hSktLS0tLS0tLS0tLS0v7J7T1M2Hmy6Gr1Nf6LLXF9dTPeql3TsNPD9p6enimpaWlpaWlpaWlpaWl3ax2cDb3ECeHLjNfUsPdebhQKqDLSs1bL65e6mnh9yqhpaWlpaWlpaWlpaWl3bg29b8dfDa1rg3qfqFzrH2v6acfG+1w5gstLS0tLS0tLS0tLS3t9rVzMxillGXoZ9CG6SmnUvpyNQz9rJ2Lhto5\\/eT0pUemqNDS0tLS0tLS0tLS0tI+Ubt2DjddvMwzONMAlMFPHl4F7WveVjs3V0FpaWlpaWlpaWlpaWlpaf+sttSDvnNzavh4v3Oatem0cLqouvZTP8qgDdL0GzdkaWlpaWlpaWlpaWlpaZ+jnfqi8+2unfu7ph91q7aU0P\\/2vWuiGwrn137myzzqf\\/seq25aWlpaWlpaWlpaWlraTWrfRzuny0HftulQ2\\/+2fUgdP3q9HTkObY\\/aJrr7vuYd9lKipaWlpaWlpaWlpaWl3ZS23vRMYzTzQrX2vaSjsysXV9vzt0sBvVu5czo3ElpaWlpaWlpaWlpaWlrav6DNfZZK3PdNB33Dl8JB39RnqWoHLX\\/3o7um0wO9hWlpaWlpaWlpaWlpaWk3pA0170c8+DvY593fFtp3Cz5Q84Z93tqt93zbLKalpaWlpaWlpaWlpaXdqrY5LfyS+gcd79dG88KLtjSboPWo8aDmPd5r3Evz5XN6paWlpaWlpaWlpaWlpd2otu9c1LasHdw5TZNDS7PQ1Pe7PTb9cE+3L\\/d3TsvXNS8tLS0tLS0tLS0tLS0t7YNaERERERERERERERERERERERERERERERERERERkU3nPwEAAP\\/\\/eKXR43wPixkAAAAASUVORK5CYII=\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/176001496964\\/ticket?caller_id=3648972604&hash=dfa0a65a-8253-4ba2-9197-b7ef4187da52\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-08-29 08:05:33'),
(208, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176020432992\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176020432992\"},\"date_created\":\"2026-08-28T13:34:41Z\",\"id\":137010188668,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-29 10:37:19'),
(209, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176020432992\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176020432992\",\"topic\":\"payment\"}}', '2026-08-29 10:37:19'),
(210, 'webhook', 'Consulta MP 176020432992 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1498TFGQMV285BFWKQ7RDJN\\\",\\\"id\\\":\\\"176020432992-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:34:41.146-04:00\\\",\\\"execution_id\\\":\\\"01M1498TE76ZT1EHREB747VP97\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-29 10:37:19'),
(211, 'webhook', 'Consulta MP 176020432992 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1498TFGQMV285BFWKQ7RDJN\\\",\\\"id\\\":\\\"176020432992-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:34:41.146-04:00\\\",\\\"execution_id\\\":\\\"01M1498TE76ZT1EHREB747VP97\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-29 10:37:19'),
(212, 'webhook', 'Fatura não encontrada ext FATURA_10_d959f9beb0_1787924080', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.171.0-rc-1\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"external_charge_id\":\"01M1498TFGQMV285BFWKQ7RDJN\",\"id\":\"176020432992-001\",\"last_updated\":\"2026-08-28T09:34:41.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-08-28T09:34:41.146-04:00\",\"execution_id\":\"01M1498TE76ZT1EHREB747VP97\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"date_last_updated\":\"2026-08-29T09:37:19.000-04:00\",\"date_of_expiration\":\"2026-08-29T09:34:40.000-04:00\",\"deduction_schema\":null,\"description\":\"Fatura #10 - S2-40Megas-01\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_10_d959f9beb0_1787924080\",\"fee_details\":[],\"financing_group\":null,\"id\":176020432992,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_10_d959f9beb0_1787924080_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"http:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3649185312\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17602043299263047428\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKoklEQVR42uzdQXIavxIH4KFYsPQROIqP5hyNo3AEL1lQ6NWfMKi7Ndjk2TGk6vttKKfM6BvvOi21JhERERERERERERERERERERERERERERERERERERH5u9m0Ibv\\/\\/v2lf57zfvn9l\\/ibx2najl9u7VB++fzlVfq9X9P6\\/Hn+ve2IoKWlpaWlpaWlpaWlpaX9Bu2+\\/Ly7PPj8+T5Nb+10XvjX5Vfe\\/lOGdN3m8oopq4tu\\/nK7PPT3q87a9JVXWlpaWlpaWlpaWlpa2mfW9kozLbgqheixa+cydV\\/U80Kv\\/73i74V7zXv+XF+0LdW8vfo+0NLS0tLS0tLS0tLS0v5b2lVZYLrUvOsOP39pVh9KDdyWCudWtLXmpaWlpaWlpaWlpaWlpf3HtfMW2tPl85jU40KtL9gL5oW26\\/wzLS0tLS0tLS0tLS0tLe1f15bdwqHPGyr1tNB0KbZb6fe+Xs+eLrxy+NL5lecvfW1vMy0tLS0tLS0tLS0tLe1PasfJRb8Xer2Wq1W7Tn3eXjjP5ermzx\\/yhTlLtLS0tLS0tLS0tLS0tD+mXUxoek5xctE6ja7tu4ZzzVvL18uXVuMQ3f30HaGlpaWlpaWlpaWlpaX9SW3dQrsbLjwJZ07f+\\/dSzTuWq6t+Jct0+8xp2vk7zk6ipaWlpaWlpaWlpaWlfWrtoTc709Ch1k9xtjh0qKbPv21l7NHCw+oQ3e0dHVNaWlpaWlpaWlpaWlpa2ju1YXLRrk8wGjf6Ju28wK1jo5t4xnSVyvz6yr1ZfEh\\/N1paWlpaWlpaWlpaWtrn1abu6uugDa3a1M9dp4XmM6dj4dziK4d+b3rlzR27h2lpaWlpaWlpaWlpaWkfqw3lah9dO10WmtKZ03qLSj022gvnhfbrtLRruN7fcs\\/kIlpaWlpaWlpaWlpaWtoHautdnGkr7fI1mqnmbeXYaL2C5XWpgzqrQ9s1dU53d+y\\/paWlpaWlpaWlpaWlpaX9fHLRFHcJhym9adBuK+pt1IY+77TULE7adVnseBEsPISWlpaWlpaWlpaWlpb2ybRht3AatPveFxzvfJmSNg3aHccfTUm7eOZ0XpmWlpaWlpaWlpaWlpb2H9Nu4gbfW\\/Nvly\\/9nBe6rZ3vepninS\\/HLrlztzAtLS0tLS0tLS0tLS3to7T1zOkhNjvrMdFpPHPaytzbcYjuwpc\\/nFx0z82htLS0tLS0tLS0tLS0tLR3aW\\/tGt5dFwi7hG+V+eHMaZ\\/aG9Rv1z9B3S28cHPo6x33ndLS0tLS0tLS0tLS0tI+TFsG7ebjordq3nGDby1XX8byNTWNt1F7Z5+XlpaWlpaWlpaWlpaW9oHadEy07hauCx1T2dq1oWxNDwk17xQL6Jex1u3zbz8KLS0tLS0tLS0tLS0t7TNp0\\/7bNP\\/2Pd6icixt1kPZf3uI15Cu0hDdzyYX0dLS0tLS0tLS0tLS0j6ztp7ibGO5mrbOvi\\/Vvrf2387jj6q2Ti6qHdQdLS0tLS0tLS0tLS0tLe13acfdwiHjQnNRHbT7+OXDFO54aWn0b+r3hor87ntOaWlpaWlpaWlpaWlpaZ9G2yvOl1L7phq45pD6vpfHrkrNm+ffvt28OfSTE7K0tLS0tLS0tLS0tLS0D9Ru0nHRxclFfcEwuraOrN32DmovW8+7gutDcsZXPnww\\/5aWlpaWlpaWlpaWlpb2sdowN6h2THdLC9Qzp4uja8P4o3QXZ51\\/W+9t2fdJvLS0tLS0tLS0tLS0tLS0X9XWab1T3Oh7KgN285ylVGTXab2tKPurtvQn6A8LW44nWlpaWlpaWlpaWlpa2ufW1nK19V3DtTX7di1XFxYaR\\/6ekrLFmjdMLvqzm0NpaWlpaWlpaWlpaWlpH6ntn6Hmrdq3WOvWXcJpy3EomNPnYs\\/2uLhvmZaWlpaWlpaWlpaWlvZ5tYsTitKW2fPP+RaVevlnOj6ablEJ447SwdV2+8u0tLS0tLS0tLS0tLS0tN+lPXwyZylp593B+c6X9NB+5vRUyvy6Wzj0dbf9+lFaWlpaWlpaWlpaWlra59defl5oyabjoh9M7Z2urdrT5eKYKb3y29Kkon0Zg0RLS0tLS0tLS0tLS0v7pNpQee7isdHFSz\\/z7uEPN\\/re6pzO44\\/6K4f2Ky0tLS0tLS0tLS0tLe2Ta8NZ0\\/m46C6Wredm51wD1\\/23LY2s7aNrN\\/3AahvOoIYhumlyUSicPz0hS0tLS0tLS0tLS0tLS\\/sYbbiLc4o1b1ognOqca95tbH5m7eL8219R\\/x5XrkN077w5lJaWlpaWlpaWlpaWlpb2Lm2aYNSL6zxwd27N1uOi6dho2oL8Xsr8+pCgPb\\/idpgbTEtLS0tLS0tLS0tLS\\/tU2k0qW8sZ09PiLuHU5229YC7a07hruEXtOh1YpaWlpaWlpaWlpaWlpf0XtKEJuhv6lqtybPTYdw2HkbXzQukClDq56O1a+7ZPJhgdPj4eS0tLS0tLS0tLS0tLS\\/tY7XQ9Y9q6su6CfRnv6Lx95nTxS6txclG4imVsv9LS0tLS0tLS0tLS0tLSfk372Zyl84NX410vrQzYXVS\\/9H5vrdCnuFt4G594+MJUKFpaWlpaWlpaWlpaWtq\\/rt0v3fly\\/jlc1xL6vL3fm8celY2+q8uZ03Z51dVdd77Q0tLS0tLS0tLS0tLSPrN2Sht9S827sFDKupep29j83LQPcixfPt7eckxLS0tLS0tLS0tLS0v7lNqxXJ1r3hY7p1Nvfp5\\/OQwfCpOM+quG+bdpP25ow46bedvd03ppaWlpaWlpaWlpaWlpaT\\/Xplbt7lqR36rQ10lbF7o8bFWm9NayPs9XSluOX2lpaWlpaWlpaWlpaWmfU1tbsocpDBk6lRtEW194Wx449nk\\/uPPl\\/aI+647l7zXR0tLS0tLS0tLS0tLSPrM2DR2adwsvjK5NN4huy+SiWdkvjgmvPE3D\\/NuuzNq0X5mWlpaWlpaWlpaWlpb2+bQtlqtT3zL7WmrdViYY1X2380Jj5zR9hj\\/FvuwA3v9ZhU5LS0tLS0tLS0tLS0v709pFfW16zqc38zWa4wUoC9ktKdPEojbux91NEy0tLS0tLS0tLS0tLS3td2unabiupVfmCwulY6Nzcb2JzeJTeuh45vSY\\/q+gzFCipaWlpaWlpaWlpaWlfSrtZqlMnXrN28qZ0\\/fY3z32Pu8+Xjt6KE3idP1oWzxz+v90pWlpaWlpaWlpaWlpaWkfoN2Xn3fxFpXQ9JwvPlnsnO7jKx5i4Xy6tF1bqnnTQ9Lf7fBxX5eWlpaWlpaWlpaWlpb24dp+5nTTlXPZ+uvy81s5c5rK1XRwddML5XEr7brdE1paWlpaWlpaWlpaWlraH9QuLrQvc5bGh7Q0Z+ntOq03qEKf99sqdFpaWlpaWlpaWlpaWtqf0ua8Da3aeYF1Kk\\/nrcZ913BqFtcJRnmr8fzQ\\/6PmpaWlpaWlpaWlpaWlpf1h7bhbONwY2spG377Bd51uDk2Xf7bhwOrCK6f269Q\\/X2lpaWlpaWlpaWlpaWmfVvvZ5KJfV3VVrkvn9BAfGpSL148utF3317\\/XREtLS0tLS0tLS0tLS0v7Va2IiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIjIU+d\\/AQAA\\/\\/83+cDS8WLeCAAAAABJRU5ErkJggg==\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/176020432992\\/ticket?caller_id=3649185312&hash=82e0fb68-6f7e-4122-8ab0-548ee67f02d0\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-08-29 10:37:19'),
(213, 'webhook', 'Fatura não encontrada ext FATURA_10_d959f9beb0_1787924080', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.171.0-rc-1\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"external_charge_id\":\"01M1498TFGQMV285BFWKQ7RDJN\",\"id\":\"176020432992-001\",\"last_updated\":\"2026-08-28T09:34:41.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-08-28T09:34:41.146-04:00\",\"execution_id\":\"01M1498TE76ZT1EHREB747VP97\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"date_last_updated\":\"2026-08-29T09:37:19.000-04:00\",\"date_of_expiration\":\"2026-08-29T09:34:40.000-04:00\",\"deduction_schema\":null,\"description\":\"Fatura #10 - S2-40Megas-01\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_10_d959f9beb0_1787924080\",\"fee_details\":[],\"financing_group\":null,\"id\":176020432992,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_10_d959f9beb0_1787924080_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"http:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3649185312\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17602043299263047428\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKoklEQVR42uzdQXIavxIH4KFYsPQROIqP5hyNo3AEL1lQ6NWfMKi7Ndjk2TGk6vttKKfM6BvvOi21JhERERERERERERERERERERERERERERERERERERH5u9m0Ibv\\/\\/v2lf57zfvn9l\\/ibx2najl9u7VB++fzlVfq9X9P6\\/Hn+ve2IoKWlpaWlpaWlpaWlpaX9Bu2+\\/Ly7PPj8+T5Nb+10XvjX5Vfe\\/lOGdN3m8oopq4tu\\/nK7PPT3q87a9JVXWlpaWlpaWlpaWlpa2mfW9kozLbgqheixa+cydV\\/U80Kv\\/73i74V7zXv+XF+0LdW8vfo+0NLS0tLS0tLS0tLS0v5b2lVZYLrUvOsOP39pVh9KDdyWCudWtLXmpaWlpaWlpaWlpaWlpf3HtfMW2tPl85jU40KtL9gL5oW26\\/wzLS0tLS0tLS0tLS0tLe1f15bdwqHPGyr1tNB0KbZb6fe+Xs+eLrxy+NL5lecvfW1vMy0tLS0tLS0tLS0tLe1PasfJRb8Xer2Wq1W7Tn3eXjjP5ermzx\\/yhTlLtLS0tLS0tLS0tLS0tD+mXUxoek5xctE6ja7tu4ZzzVvL18uXVuMQ3f30HaGlpaWlpaWlpaWlpaX9SW3dQrsbLjwJZ07f+\\/dSzTuWq6t+Jct0+8xp2vk7zk6ipaWlpaWlpaWlpaWlfWrtoTc709Ch1k9xtjh0qKbPv21l7NHCw+oQ3e0dHVNaWlpaWlpaWlpaWlpa2ju1YXLRrk8wGjf6Ju28wK1jo5t4xnSVyvz6yr1ZfEh\\/N1paWlpaWlpaWlpaWtrn1abu6uugDa3a1M9dp4XmM6dj4dziK4d+b3rlzR27h2lpaWlpaWlpaWlpaWkfqw3lah9dO10WmtKZ03qLSj022gvnhfbrtLRruN7fcs\\/kIlpaWlpaWlpaWlpaWtoHautdnGkr7fI1mqnmbeXYaL2C5XWpgzqrQ9s1dU53d+y\\/paWlpaWlpaWlpaWlpaX9fHLRFHcJhym9adBuK+pt1IY+77TULE7adVnseBEsPISWlpaWlpaWlpaWlpb2ybRht3AatPveFxzvfJmSNg3aHccfTUm7eOZ0XpmWlpaWlpaWlpaWlpb2H9Nu4gbfW\\/Nvly\\/9nBe6rZ3vepninS\\/HLrlztzAtLS0tLS0tLS0tLS3to7T1zOkhNjvrMdFpPHPaytzbcYjuwpc\\/nFx0z82htLS0tLS0tLS0tLS0tLR3aW\\/tGt5dFwi7hG+V+eHMaZ\\/aG9Rv1z9B3S28cHPo6x33ndLS0tLS0tLS0tLS0tI+TFsG7ebjordq3nGDby1XX8byNTWNt1F7Z5+XlpaWlpaWlpaWlpaW9oHadEy07hauCx1T2dq1oWxNDwk17xQL6Jex1u3zbz8KLS0tLS0tLS0tLS0t7TNp0\\/7bNP\\/2Pd6icixt1kPZf3uI15Cu0hDdzyYX0dLS0tLS0tLS0tLS0j6ztp7ibGO5mrbOvi\\/Vvrf2387jj6q2Ti6qHdQdLS0tLS0tLS0tLS0tLe13acfdwiHjQnNRHbT7+OXDFO54aWn0b+r3hor87ntOaWlpaWlpaWlpaWlpaZ9G2yvOl1L7phq45pD6vpfHrkrNm+ffvt28OfSTE7K0tLS0tLS0tLS0tLS0D9Ru0nHRxclFfcEwuraOrN32DmovW8+7gutDcsZXPnww\\/5aWlpaWlpaWlpaWlpb2sdowN6h2THdLC9Qzp4uja8P4o3QXZ51\\/W+9t2fdJvLS0tLS0tLS0tLS0tLS0X9XWab1T3Oh7KgN285ylVGTXab2tKPurtvQn6A8LW44nWlpaWlpaWlpaWlpa2ufW1nK19V3DtTX7di1XFxYaR\\/6ekrLFmjdMLvqzm0NpaWlpaWlpaWlpaWlpH6ntn6Hmrdq3WOvWXcJpy3EomNPnYs\\/2uLhvmZaWlpaWlpaWlpaWlvZ5tYsTitKW2fPP+RaVevlnOj6ablEJ447SwdV2+8u0tLS0tLS0tLS0tLS0tN+lPXwyZylp593B+c6X9NB+5vRUyvy6Wzj0dbf9+lFaWlpaWlpaWlpaWlra59defl5oyabjoh9M7Z2urdrT5eKYKb3y29Kkon0Zg0RLS0tLS0tLS0tLS0v7pNpQee7isdHFSz\\/z7uEPN\\/re6pzO44\\/6K4f2Ky0tLS0tLS0tLS0tLe2Ta8NZ0\\/m46C6Wredm51wD1\\/23LY2s7aNrN\\/3AahvOoIYhumlyUSicPz0hS0tLS0tLS0tLS0tLS\\/sYbbiLc4o1b1ognOqca95tbH5m7eL8219R\\/x5XrkN077w5lJaWlpaWlpaWlpaWlpb2Lm2aYNSL6zxwd27N1uOi6dho2oL8Xsr8+pCgPb\\/idpgbTEtLS0tLS0tLS0tLS\\/tU2k0qW8sZ09PiLuHU5229YC7a07hruEXtOh1YpaWlpaWlpaWlpaWlpf0XtKEJuhv6lqtybPTYdw2HkbXzQukClDq56O1a+7ZPJhgdPj4eS0tLS0tLS0tLS0tLS\\/tY7XQ9Y9q6su6CfRnv6Lx95nTxS6txclG4imVsv9LS0tLS0tLS0tLS0tLSfk372Zyl84NX410vrQzYXVS\\/9H5vrdCnuFt4G594+MJUKFpaWlpaWlpaWlpaWtq\\/rt0v3fly\\/jlc1xL6vL3fm8celY2+q8uZ03Z51dVdd77Q0tLS0tLS0tLS0tLSPrN2Sht9S827sFDKupep29j83LQPcixfPt7eckxLS0tLS0tLS0tLS0v7lNqxXJ1r3hY7p1Nvfp5\\/OQwfCpOM+quG+bdpP25ow46bedvd03ppaWlpaWlpaWlpaWlpaT\\/Xplbt7lqR36rQ10lbF7o8bFWm9NayPs9XSluOX2lpaWlpaWlpaWlpaWmfU1tbsocpDBk6lRtEW194Wx449nk\\/uPPl\\/aI+647l7zXR0tLS0tLS0tLS0tLSPrM2DR2adwsvjK5NN4huy+SiWdkvjgmvPE3D\\/NuuzNq0X5mWlpaWlpaWlpaWlpb2+bQtlqtT3zL7WmrdViYY1X2380Jj5zR9hj\\/FvuwA3v9ZhU5LS0tLS0tLS0tLS0v709pFfW16zqc38zWa4wUoC9ktKdPEojbux91NEy0tLS0tLS0tLS0tLS3td2unabiupVfmCwulY6Nzcb2JzeJTeuh45vSY\\/q+gzFCipaWlpaWlpaWlpaWlfSrtZqlMnXrN28qZ0\\/fY3z32Pu8+Xjt6KE3idP1oWzxz+v90pWlpaWlpaWlpaWlpaWkfoN2Xn3fxFpXQ9JwvPlnsnO7jKx5i4Xy6tF1bqnnTQ9Lf7fBxX5eWlpaWlpaWlpaWlpb24dp+5nTTlXPZ+uvy81s5c5rK1XRwddML5XEr7brdE1paWlpaWlpaWlpaWlraH9QuLrQvc5bGh7Q0Z+ntOq03qEKf99sqdFpaWlpaWlpaWlpaWtqf0ua8Da3aeYF1Kk\\/nrcZ913BqFtcJRnmr8fzQ\\/6PmpaWlpaWlpaWlpaWlpf1h7bhbONwY2spG377Bd51uDk2Xf7bhwOrCK6f269Q\\/X2lpaWlpaWlpaWlpaWmfVvvZ5KJfV3VVrkvn9BAfGpSL148utF3317\\/XREtLS0tLS0tLS0tLS0v7Va2IiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIjIU+d\\/AQAA\\/\\/83+cDS8WLeCAAAAABJRU5ErkJggg==\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/176020432992\\/ticket?caller_id=3649185312&hash=82e0fb68-6f7e-4122-8ab0-548ee67f02d0\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-08-29 10:37:19'),
(214, 'webhook', 'MP notification', '{\"get\":{\"id\":\"176020432992\",\"topic\":\"payment\"},\"body\":{\"resource\":\"176020432992\",\"topic\":\"payment\"}}', '2026-08-29 10:37:21'),
(215, 'webhook', 'MP notification', '{\"get\":{\"data_id\":\"176020432992\",\"type\":\"payment\"},\"body\":{\"action\":\"payment.updated\",\"api_version\":\"v1\",\"data\":{\"id\":\"176020432992\"},\"date_created\":\"2026-08-28T13:34:41Z\",\"id\":137010182970,\"live_mode\":true,\"type\":\"payment\",\"user_id\":\"142008628\"}}', '2026-08-29 10:37:21'),
(216, 'webhook', 'Consulta MP 176020432992 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1498TFGQMV285BFWKQ7RDJN\\\",\\\"id\\\":\\\"176020432992-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:34:41.146-04:00\\\",\\\"execution_id\\\":\\\"01M1498TE76ZT1EHREB747VP97\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-29 10:37:21');
INSERT INTO `logs` (`id`, `tipo`, `mensagem`, `detalhes`, `criado_em`) VALUES
(217, 'webhook', 'Fatura não encontrada ext FATURA_10_d959f9beb0_1787924080', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.171.0-rc-1\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"external_charge_id\":\"01M1498TFGQMV285BFWKQ7RDJN\",\"id\":\"176020432992-001\",\"last_updated\":\"2026-08-28T09:34:41.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-08-28T09:34:41.146-04:00\",\"execution_id\":\"01M1498TE76ZT1EHREB747VP97\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"date_last_updated\":\"2026-08-29T09:37:20.000-04:00\",\"date_of_expiration\":\"2026-08-29T09:34:40.000-04:00\",\"deduction_schema\":null,\"description\":\"Fatura #10 - S2-40Megas-01\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_10_d959f9beb0_1787924080\",\"fee_details\":[],\"financing_group\":null,\"id\":176020432992,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_10_d959f9beb0_1787924080_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"http:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3649185312\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17602043299263047428\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKoklEQVR42uzdQXIavxIH4KFYsPQROIqP5hyNo3AEL1lQ6NWfMKi7Ndjk2TGk6vttKKfM6BvvOi21JhERERERERERERERERERERERERERERERERERERH5u9m0Ibv\\/\\/v2lf57zfvn9l\\/ibx2najl9u7VB++fzlVfq9X9P6\\/Hn+ve2IoKWlpaWlpaWlpaWlpaX9Bu2+\\/Ly7PPj8+T5Nb+10XvjX5Vfe\\/lOGdN3m8oopq4tu\\/nK7PPT3q87a9JVXWlpaWlpaWlpaWlpa2mfW9kozLbgqheixa+cydV\\/U80Kv\\/73i74V7zXv+XF+0LdW8vfo+0NLS0tLS0tLS0tLS0v5b2lVZYLrUvOsOP39pVh9KDdyWCudWtLXmpaWlpaWlpaWlpaWlpf3HtfMW2tPl85jU40KtL9gL5oW26\\/wzLS0tLS0tLS0tLS0tLe1f15bdwqHPGyr1tNB0KbZb6fe+Xs+eLrxy+NL5lecvfW1vMy0tLS0tLS0tLS0tLe1PasfJRb8Xer2Wq1W7Tn3eXjjP5ermzx\\/yhTlLtLS0tLS0tLS0tLS0tD+mXUxoek5xctE6ja7tu4ZzzVvL18uXVuMQ3f30HaGlpaWlpaWlpaWlpaX9SW3dQrsbLjwJZ07f+\\/dSzTuWq6t+Jct0+8xp2vk7zk6ipaWlpaWlpaWlpaWlfWrtoTc709Ch1k9xtjh0qKbPv21l7NHCw+oQ3e0dHVNaWlpaWlpaWlpaWlpa2ju1YXLRrk8wGjf6Ju28wK1jo5t4xnSVyvz6yr1ZfEh\\/N1paWlpaWlpaWlpaWtrn1abu6uugDa3a1M9dp4XmM6dj4dziK4d+b3rlzR27h2lpaWlpaWlpaWlpaWkfqw3lah9dO10WmtKZ03qLSj022gvnhfbrtLRruN7fcs\\/kIlpaWlpaWlpaWlpaWtoHautdnGkr7fI1mqnmbeXYaL2C5XWpgzqrQ9s1dU53d+y\\/paWlpaWlpaWlpaWlpaX9fHLRFHcJhym9adBuK+pt1IY+77TULE7adVnseBEsPISWlpaWlpaWlpaWlpb2ybRht3AatPveFxzvfJmSNg3aHccfTUm7eOZ0XpmWlpaWlpaWlpaWlpb2H9Nu4gbfW\\/Nvly\\/9nBe6rZ3vepninS\\/HLrlztzAtLS0tLS0tLS0tLS3to7T1zOkhNjvrMdFpPHPaytzbcYjuwpc\\/nFx0z82htLS0tLS0tLS0tLS0tLR3aW\\/tGt5dFwi7hG+V+eHMaZ\\/aG9Rv1z9B3S28cHPo6x33ndLS0tLS0tLS0tLS0tI+TFsG7ebjordq3nGDby1XX8byNTWNt1F7Z5+XlpaWlpaWlpaWlpaW9oHadEy07hauCx1T2dq1oWxNDwk17xQL6Jex1u3zbz8KLS0tLS0tLS0tLS0t7TNp0\\/7bNP\\/2Pd6icixt1kPZf3uI15Cu0hDdzyYX0dLS0tLS0tLS0tLS0j6ztp7ibGO5mrbOvi\\/Vvrf2387jj6q2Ti6qHdQdLS0tLS0tLS0tLS0tLe13acfdwiHjQnNRHbT7+OXDFO54aWn0b+r3hor87ntOaWlpaWlpaWlpaWlpaZ9G2yvOl1L7phq45pD6vpfHrkrNm+ffvt28OfSTE7K0tLS0tLS0tLS0tLS0D9Ru0nHRxclFfcEwuraOrN32DmovW8+7gutDcsZXPnww\\/5aWlpaWlpaWlpaWlpb2sdowN6h2THdLC9Qzp4uja8P4o3QXZ51\\/W+9t2fdJvLS0tLS0tLS0tLS0tLS0X9XWab1T3Oh7KgN285ylVGTXab2tKPurtvQn6A8LW44nWlpaWlpaWlpaWlpa2ufW1nK19V3DtTX7di1XFxYaR\\/6ekrLFmjdMLvqzm0NpaWlpaWlpaWlpaWlpH6ntn6Hmrdq3WOvWXcJpy3EomNPnYs\\/2uLhvmZaWlpaWlpaWlpaWlvZ5tYsTitKW2fPP+RaVevlnOj6ablEJ447SwdV2+8u0tLS0tLS0tLS0tLS0tN+lPXwyZylp593B+c6X9NB+5vRUyvy6Wzj0dbf9+lFaWlpaWlpaWlpaWlra59defl5oyabjoh9M7Z2urdrT5eKYKb3y29Kkon0Zg0RLS0tLS0tLS0tLS0v7pNpQee7isdHFSz\\/z7uEPN\\/re6pzO44\\/6K4f2Ky0tLS0tLS0tLS0tLe2Ta8NZ0\\/m46C6Wredm51wD1\\/23LY2s7aNrN\\/3AahvOoIYhumlyUSicPz0hS0tLS0tLS0tLS0tLS\\/sYbbiLc4o1b1ognOqca95tbH5m7eL8219R\\/x5XrkN077w5lJaWlpaWlpaWlpaWlpb2Lm2aYNSL6zxwd27N1uOi6dho2oL8Xsr8+pCgPb\\/idpgbTEtLS0tLS0tLS0tLS\\/tU2k0qW8sZ09PiLuHU5229YC7a07hruEXtOh1YpaWlpaWlpaWlpaWlpf0XtKEJuhv6lqtybPTYdw2HkbXzQukClDq56O1a+7ZPJhgdPj4eS0tLS0tLS0tLS0tLS\\/tY7XQ9Y9q6su6CfRnv6Lx95nTxS6txclG4imVsv9LS0tLS0tLS0tLS0tLSfk372Zyl84NX410vrQzYXVS\\/9H5vrdCnuFt4G594+MJUKFpaWlpaWlpaWlpaWtq\\/rt0v3fly\\/jlc1xL6vL3fm8celY2+q8uZ03Z51dVdd77Q0tLS0tLS0tLS0tLSPrN2Sht9S827sFDKupep29j83LQPcixfPt7eckxLS0tLS0tLS0tLS0v7lNqxXJ1r3hY7p1Nvfp5\\/OQwfCpOM+quG+bdpP25ow46bedvd03ppaWlpaWlpaWlpaWlpaT\\/Xplbt7lqR36rQ10lbF7o8bFWm9NayPs9XSluOX2lpaWlpaWlpaWlpaWmfU1tbsocpDBk6lRtEW194Wx449nk\\/uPPl\\/aI+647l7zXR0tLS0tLS0tLS0tLSPrM2DR2adwsvjK5NN4huy+SiWdkvjgmvPE3D\\/NuuzNq0X5mWlpaWlpaWlpaWlpb2+bQtlqtT3zL7WmrdViYY1X2380Jj5zR9hj\\/FvuwA3v9ZhU5LS0tLS0tLS0tLS0v709pFfW16zqc38zWa4wUoC9ktKdPEojbux91NEy0tLS0tLS0tLS0tLS3td2unabiupVfmCwulY6Nzcb2JzeJTeuh45vSY\\/q+gzFCipaWlpaWlpaWlpaWlfSrtZqlMnXrN28qZ0\\/fY3z32Pu8+Xjt6KE3idP1oWzxz+v90pWlpaWlpaWlpaWlpaWkfoN2Xn3fxFpXQ9JwvPlnsnO7jKx5i4Xy6tF1bqnnTQ9Lf7fBxX5eWlpaWlpaWlpaWlpb24dp+5nTTlXPZ+uvy81s5c5rK1XRwddML5XEr7brdE1paWlpaWlpaWlpaWlraH9QuLrQvc5bGh7Q0Z+ntOq03qEKf99sqdFpaWlpaWlpaWlpaWtqf0ua8Da3aeYF1Kk\\/nrcZ913BqFtcJRnmr8fzQ\\/6PmpaWlpaWlpaWlpaWlpf1h7bhbONwY2spG377Bd51uDk2Xf7bhwOrCK6f269Q\\/X2lpaWlpaWlpaWlpaWmfVvvZ5KJfV3VVrkvn9BAfGpSL148utF3317\\/XREtLS0tLS0tLS0tLS0v7Va2IiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIjIU+d\\/AQAA\\/\\/83+cDS8WLeCAAAAABJRU5ErkJggg==\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/176020432992\\/ticket?caller_id=3649185312&hash=82e0fb68-6f7e-4122-8ab0-548ee67f02d0\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-08-29 10:37:21'),
(218, 'webhook', 'Consulta MP 176020432992 HTTP 200', '{\"resp\":\"{\\\"accounts_info\\\":null,\\\"acquirer_reconciliation\\\":[],\\\"additional_info\\\":{\\\"tracking_id\\\":\\\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\\\"},\\\"authorization_code\\\":null,\\\"binary_mode\\\":false,\\\"brand_id\\\":null,\\\"build_version\\\":\\\"3.171.0-rc-1\\\",\\\"call_for_authorize_id\\\":null,\\\"callback_url\\\":null,\\\"captured\\\":true,\\\"card\\\":{},\\\"charges_details\\\":[{\\\"accounts\\\":{\\\"from\\\":\\\"collector\\\",\\\"to\\\":\\\"mp\\\"},\\\"amounts\\\":{\\\"original\\\":0.01,\\\"refunded\\\":0},\\\"client_id\\\":0,\\\"date_created\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"external_charge_id\\\":\\\"01M1498TFGQMV285BFWKQ7RDJN\\\",\\\"id\\\":\\\"176020432992-001\\\",\\\"last_updated\\\":\\\"2026-08-28T09:34:41.000-04:00\\\",\\\"metadata\\\":{\\\"reason\\\":\\\"\\\",\\\"source\\\":\\\"proc-svc-charges\\\",\\\"source_detail\\\":\\\"processing_fee_charge\\\"},\\\"name\\\":\\\"mercadopago_fee\\\",\\\"refund_charges\\\":[],\\\"reserve_id\\\":null,\\\"type\\\":\\\"fee\\\",\\\"update_charges\\\":[]}],\\\"charges_execution_info\\\":{\\\"internal_execution\\\":{\\\"date\\\":\\\"2026-08-28T09:34:41.146-04:00\\\",\\\"execution_id\\\":\\\"01M1498TE76ZT1EHREB747VP97\\\"}},\\\"collector_id\\\":142008628,\\\"corporation_id\\\":null,\\\"counter_currency\\\":null,\\\"coupon_amou\"}', '2026-08-29 10:37:21'),
(219, 'webhook', 'Fatura não encontrada ext FATURA_10_d959f9beb0_1787924080', '{\"accounts_info\":null,\"acquirer_reconciliation\":[],\"additional_info\":{\"tracking_id\":\"platform:v1-whitelabel,so:ALL,type:N\\/A,security:none\"},\"authorization_code\":null,\"binary_mode\":false,\"brand_id\":null,\"build_version\":\"3.171.0-rc-1\",\"call_for_authorize_id\":null,\"callback_url\":null,\"captured\":true,\"card\":[],\"charges_details\":[{\"accounts\":{\"from\":\"collector\",\"to\":\"mp\"},\"amounts\":{\"original\":0.01,\"refunded\":0},\"client_id\":0,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"external_charge_id\":\"01M1498TFGQMV285BFWKQ7RDJN\",\"id\":\"176020432992-001\",\"last_updated\":\"2026-08-28T09:34:41.000-04:00\",\"metadata\":{\"reason\":\"\",\"source\":\"proc-svc-charges\",\"source_detail\":\"processing_fee_charge\"},\"name\":\"mercadopago_fee\",\"refund_charges\":[],\"reserve_id\":null,\"type\":\"fee\",\"update_charges\":[]}],\"charges_execution_info\":{\"internal_execution\":{\"date\":\"2026-08-28T09:34:41.146-04:00\",\"execution_id\":\"01M1498TE76ZT1EHREB747VP97\"}},\"collector_id\":142008628,\"corporation_id\":null,\"counter_currency\":null,\"coupon_amount\":0,\"currency_id\":\"BRL\",\"date_approved\":null,\"date_created\":\"2026-08-28T09:34:41.000-04:00\",\"date_last_updated\":\"2026-08-29T09:37:20.000-04:00\",\"date_of_expiration\":\"2026-08-29T09:34:40.000-04:00\",\"deduction_schema\":null,\"description\":\"Fatura #10 - S2-40Megas-01\",\"differential_pricing_id\":null,\"external_reference\":\"FATURA_10_d959f9beb0_1787924080\",\"fee_details\":[],\"financing_group\":null,\"id\":176020432992,\"idempotency_key\":\"idempotencyKeyPostPay_FATURA_10_d959f9beb0_1787924080_5748377013323719\",\"installments\":1,\"integrator_id\":null,\"issuer_id\":\"12501\",\"live_mode\":true,\"marketplace_owner\":null,\"merchant_account_id\":null,\"merchant_number\":null,\"metadata\":[],\"money_release_date\":null,\"money_release_schema\":null,\"money_release_status\":\"released\",\"notification_url\":\"http:\\/\\/aplicacao.spaconett.com\\/webhook\\/mercadopago.php\",\"operation_type\":\"regular_payment\",\"order\":[],\"payer\":{\"email\":null,\"entity_type\":null,\"first_name\":null,\"id\":\"3649185312\",\"identification\":{\"number\":null,\"type\":null},\"last_name\":null,\"operator_id\":null,\"phone\":{\"number\":null,\"extension\":null,\"area_code\":null},\"type\":null},\"payment_method\":{\"id\":\"pix\",\"issuer_id\":\"12501\",\"type\":\"bank_transfer\"},\"payment_method_id\":\"pix\",\"payment_type_id\":\"bank_transfer\",\"platform_id\":null,\"point_of_interaction\":{\"application_data\":{\"name\":null,\"operating_system\":null,\"version\":null},\"business_info\":{\"branch\":\"Merchant Services\",\"sub_unit\":\"default\",\"unit\":\"online_payments\"},\"location\":{\"source\":\"null\",\"state_id\":\"null\"},\"transaction_data\":{\"bank_info\":{\"collector\":{\"account_alias\":null,\"account_holder_name\":\"Rafael Augusto da Conceicao\",\"account_id\":null,\"check_digit\":null,\"id\":null,\"long_name\":null,\"transfer_account_id\":null},\"is_same_bank_account_owner\":null,\"origin_bank_id\":null,\"origin_wallet_id\":null,\"payer\":{\"account_alias\":null,\"account_id\":null,\"branch\":null,\"check_digit\":null,\"external_account_id\":null,\"id\":null,\"identification\":[],\"long_name\":null}},\"bank_transfer_id\":null,\"e2e_id\":null,\"financial_institution\":null,\"is_end_consumer\":null,\"merchant_category_code\":null,\"qr_code\":\"00020126580014br.gov.bcb.pix013644ee3ade-c572-42a0-9fcf-64f606b302e852040000530398654041.005802BR5918R.AUGUSTO.SPAONETT6009Sao Paulo62250521mpqrinter17602043299263047428\",\"qr_code_base64\":\"iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQMAAABpQ4TyAAAABlBMVEX\\/\\/\\/8AAABVwtN+AAAKoklEQVR42uzdQXIavxIH4KFYsPQROIqP5hyNo3AEL1lQ6NWfMKi7Ndjk2TGk6vttKKfM6BvvOi21JhERERERERERERERERERERERERERERERERERERH5u9m0Ibv\\/\\/v2lf57zfvn9l\\/ibx2najl9u7VB++fzlVfq9X9P6\\/Hn+ve2IoKWlpaWlpaWlpaWlpaX9Bu2+\\/Ly7PPj8+T5Nb+10XvjX5Vfe\\/lOGdN3m8oopq4tu\\/nK7PPT3q87a9JVXWlpaWlpaWlpaWlpa2mfW9kozLbgqheixa+cydV\\/U80Kv\\/73i74V7zXv+XF+0LdW8vfo+0NLS0tLS0tLS0tLS0v5b2lVZYLrUvOsOP39pVh9KDdyWCudWtLXmpaWlpaWlpaWlpaWlpf3HtfMW2tPl85jU40KtL9gL5oW26\\/wzLS0tLS0tLS0tLS0tLe1f15bdwqHPGyr1tNB0KbZb6fe+Xs+eLrxy+NL5lecvfW1vMy0tLS0tLS0tLS0tLe1PasfJRb8Xer2Wq1W7Tn3eXjjP5ermzx\\/yhTlLtLS0tLS0tLS0tLS0tD+mXUxoek5xctE6ja7tu4ZzzVvL18uXVuMQ3f30HaGlpaWlpaWlpaWlpaX9SW3dQrsbLjwJZ07f+\\/dSzTuWq6t+Jct0+8xp2vk7zk6ipaWlpaWlpaWlpaWlfWrtoTc709Ch1k9xtjh0qKbPv21l7NHCw+oQ3e0dHVNaWlpaWlpaWlpaWlpa2ju1YXLRrk8wGjf6Ju28wK1jo5t4xnSVyvz6yr1ZfEh\\/N1paWlpaWlpaWlpaWtrn1abu6uugDa3a1M9dp4XmM6dj4dziK4d+b3rlzR27h2lpaWlpaWlpaWlpaWkfqw3lah9dO10WmtKZ03qLSj022gvnhfbrtLRruN7fcs\\/kIlpaWlpaWlpaWlpaWtoHautdnGkr7fI1mqnmbeXYaL2C5XWpgzqrQ9s1dU53d+y\\/paWlpaWlpaWlpaWlpaX9fHLRFHcJhym9adBuK+pt1IY+77TULE7adVnseBEsPISWlpaWlpaWlpaWlpb2ybRht3AatPveFxzvfJmSNg3aHccfTUm7eOZ0XpmWlpaWlpaWlpaWlpb2H9Nu4gbfW\\/Nvly\\/9nBe6rZ3vepninS\\/HLrlztzAtLS0tLS0tLS0tLS3to7T1zOkhNjvrMdFpPHPaytzbcYjuwpc\\/nFx0z82htLS0tLS0tLS0tLS0tLR3aW\\/tGt5dFwi7hG+V+eHMaZ\\/aG9Rv1z9B3S28cHPo6x33ndLS0tLS0tLS0tLS0tI+TFsG7ebjordq3nGDby1XX8byNTWNt1F7Z5+XlpaWlpaWlpaWlpaW9oHadEy07hauCx1T2dq1oWxNDwk17xQL6Jex1u3zbz8KLS0tLS0tLS0tLS0t7TNp0\\/7bNP\\/2Pd6icixt1kPZf3uI15Cu0hDdzyYX0dLS0tLS0tLS0tLS0j6ztp7ibGO5mrbOvi\\/Vvrf2387jj6q2Ti6qHdQdLS0tLS0tLS0tLS0tLe13acfdwiHjQnNRHbT7+OXDFO54aWn0b+r3hor87ntOaWlpaWlpaWlpaWlpaZ9G2yvOl1L7phq45pD6vpfHrkrNm+ffvt28OfSTE7K0tLS0tLS0tLS0tLS0D9Ru0nHRxclFfcEwuraOrN32DmovW8+7gutDcsZXPnww\\/5aWlpaWlpaWlpaWlpb2sdowN6h2THdLC9Qzp4uja8P4o3QXZ51\\/W+9t2fdJvLS0tLS0tLS0tLS0tLS0X9XWab1T3Oh7KgN285ylVGTXab2tKPurtvQn6A8LW44nWlpaWlpaWlpaWlpa2ufW1nK19V3DtTX7di1XFxYaR\\/6ekrLFmjdMLvqzm0NpaWlpaWlpaWlpaWlpH6ntn6Hmrdq3WOvWXcJpy3EomNPnYs\\/2uLhvmZaWlpaWlpaWlpaWlvZ5tYsTitKW2fPP+RaVevlnOj6ablEJ447SwdV2+8u0tLS0tLS0tLS0tLS0tN+lPXwyZylp593B+c6X9NB+5vRUyvy6Wzj0dbf9+lFaWlpaWlpaWlpaWlra59defl5oyabjoh9M7Z2urdrT5eKYKb3y29Kkon0Zg0RLS0tLS0tLS0tLS0v7pNpQee7isdHFSz\\/z7uEPN\\/re6pzO44\\/6K4f2Ky0tLS0tLS0tLS0tLe2Ta8NZ0\\/m46C6Wredm51wD1\\/23LY2s7aNrN\\/3AahvOoIYhumlyUSicPz0hS0tLS0tLS0tLS0tLS\\/sYbbiLc4o1b1ognOqca95tbH5m7eL8219R\\/x5XrkN077w5lJaWlpaWlpaWlpaWlpb2Lm2aYNSL6zxwd27N1uOi6dho2oL8Xsr8+pCgPb\\/idpgbTEtLS0tLS0tLS0tLS\\/tU2k0qW8sZ09PiLuHU5229YC7a07hruEXtOh1YpaWlpaWlpaWlpaWlpf0XtKEJuhv6lqtybPTYdw2HkbXzQukClDq56O1a+7ZPJhgdPj4eS0tLS0tLS0tLS0tLS\\/tY7XQ9Y9q6su6CfRnv6Lx95nTxS6txclG4imVsv9LS0tLS0tLS0tLS0tLSfk372Zyl84NX410vrQzYXVS\\/9H5vrdCnuFt4G594+MJUKFpaWlpaWlpaWlpaWtq\\/rt0v3fly\\/jlc1xL6vL3fm8celY2+q8uZ03Z51dVdd77Q0tLS0tLS0tLS0tLSPrN2Sht9S827sFDKupep29j83LQPcixfPt7eckxLS0tLS0tLS0tLS0v7lNqxXJ1r3hY7p1Nvfp5\\/OQwfCpOM+quG+bdpP25ow46bedvd03ppaWlpaWlpaWlpaWlpaT\\/Xplbt7lqR36rQ10lbF7o8bFWm9NayPs9XSluOX2lpaWlpaWlpaWlpaWmfU1tbsocpDBk6lRtEW194Wx449nk\\/uPPl\\/aI+647l7zXR0tLS0tLS0tLS0tLSPrM2DR2adwsvjK5NN4huy+SiWdkvjgmvPE3D\\/NuuzNq0X5mWlpaWlpaWlpaWlpb2+bQtlqtT3zL7WmrdViYY1X2380Jj5zR9hj\\/FvuwA3v9ZhU5LS0tLS0tLS0tLS0v709pFfW16zqc38zWa4wUoC9ktKdPEojbux91NEy0tLS0tLS0tLS0tLS3td2unabiupVfmCwulY6Nzcb2JzeJTeuh45vSY\\/q+gzFCipaWlpaWlpaWlpaWlfSrtZqlMnXrN28qZ0\\/fY3z32Pu8+Xjt6KE3idP1oWzxz+v90pWlpaWlpaWlpaWlpaWkfoN2Xn3fxFpXQ9JwvPlnsnO7jKx5i4Xy6tF1bqnnTQ9Lf7fBxX5eWlpaWlpaWlpaWlpb24dp+5nTTlXPZ+uvy81s5c5rK1XRwddML5XEr7brdE1paWlpaWlpaWlpaWlraH9QuLrQvc5bGh7Q0Z+ntOq03qEKf99sqdFpaWlpaWlpaWlpaWtqf0ua8Da3aeYF1Kk\\/nrcZ913BqFtcJRnmr8fzQ\\/6PmpaWlpaWlpaWlpaWlpf1h7bhbONwY2spG377Bd51uDk2Xf7bhwOrCK6f269Q\\/X2lpaWlpaWlpaWlpaWmfVvvZ5KJfV3VVrkvn9BAfGpSL148utF3317\\/XREtLS0tLS0tLS0tLS0v7Va2IiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIjIU+d\\/AQAA\\/\\/83+cDS8WLeCAAAAABJRU5ErkJggg==\",\"ticket_url\":\"https:\\/\\/www.mercadopago.com.br\\/payments\\/176020432992\\/ticket?caller_id=3649185312&hash=82e0fb68-6f7e-4122-8ab0-548ee67f02d0\",\"transaction_id\":null},\"type\":\"OPENPLATFORM\"},\"pos_id\":null,\"processing_mode\":\"aggregator\",\"refunds\":[],\"release_info\":null,\"shipping_amount\":0,\"sponsor_id\":null,\"statement_descriptor\":null,\"status\":\"cancelled\",\"status_detail\":\"expired\",\"store_id\":null,\"tags\":null,\"taxes_amount\":0,\"tenant_context\":\"mp\",\"transaction_amount\":1,\"transaction_amount_refunded\":0,\"transaction_details\":{\"acquirer_reference\":null,\"bank_transfer_id\":null,\"external_resource_url\":null,\"financial_institution\":null,\"installment_amount\":0,\"net_received_amount\":0,\"overpaid_amount\":0,\"payable_deferral_period\":null,\"payment_method_reference_id\":null,\"total_paid_amount\":1,\"transaction_id\":null}}', '2026-08-29 10:37:21'),
(220, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-08-29 10:41:16'),
(221, 'whatsapp', 'Mensagem enviada com sucesso para 558296934434', NULL, '2026-08-29 10:43:28');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mikrotik_payment_history`
--

CREATE TABLE `mikrotik_payment_history` (
  `id` int NOT NULL,
  `cliente_id` int NOT NULL,
  `ano` int NOT NULL,
  `mes` int NOT NULL,
  `status` enum('paid','warning','overdue','npago') DEFAULT 'paid',
  `valor` decimal(10,2) DEFAULT '0.00',
  `data_atualizacao` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `mikrotik_payment_history`
--

INSERT INTO `mikrotik_payment_history` (`id`, `cliente_id`, `ano`, `mes`, `status`, `valor`, `data_atualizacao`) VALUES
(80, 5, 2026, 8, 'paid', 0.00, '2026-08-28 14:40:52'),
(81, 7, 2026, 8, 'warning', 0.00, '2026-08-28 14:19:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `planos`
--

CREATE TABLE `planos` (
  `id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `prefixo_grupo` varchar(20) DEFAULT 'S1',
  `profile_mikrotik` varchar(100) NOT NULL,
  `profile_aviso` varchar(100) DEFAULT NULL,
  `profile_bloqueado` varchar(100) NOT NULL,
  `velocidade_down` varchar(50) DEFAULT '40M',
  `velocidade_up` varchar(50) DEFAULT '20M',
  `valor` decimal(10,2) NOT NULL DEFAULT '0.00',
  `dias_validade` int NOT NULL DEFAULT '30',
  `descricao` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `planos`
--

INSERT INTO `planos` (`id`, `nome`, `prefixo_grupo`, `profile_mikrotik`, `profile_aviso`, `profile_bloqueado`, `velocidade_down`, `velocidade_up`, `valor`, `dias_validade`, `descricao`, `criado_em`) VALUES
(1, 'S1-40Megas-01', 'S1', 'S1-R.NORMAL-01/Espera', 'S1-R.NORMAL-01/Aviso', 'S1-R.NORMAL-01/Bloqueado', '40M', '20M', 1.00, 30, 'Plano Teste 40 Mega Grupo S1', '2026-08-19 15:50:59'),
(2, 'S2-40Megas-01', 'S2', 'S2-R.NORMAL-01/Espera', 'S2-R.NORMAL-01/Aviso', 'S2-R.NORMAL-01/Bloqueado', '40M', '20M', 1.00, 30, 'Plano 40 Mega Grupo S2', '2026-08-19 15:50:59'),
(3, 'S1-40Megas-10', 'S1', 'S1-R.NORMAL-10/Espera', NULL, 'S1-R.NORMAL-10/Bloqueado', '40M', '20M', 50.00, 30, 'Plano 40 Mega Variação 10', '2026-08-19 15:50:59'),
(7, 'S1-80Megas-01', 'S1', 'S1-R.MAIOR-01/Espera', NULL, 'S1-R.MAIOR-01/Bloqueado', '80M', '40M', 65.00, 30, 'Plano 80 Mega Grupo S1', '2026-08-19 15:50:59'),
(13, 'S1-100Megas-01', 'S1', 'S1-R.SUPER-01/Espera', NULL, 'S1-R.SUPER-01/Bloqueado', '100M', '50M', 80.00, 30, 'Plano Ultra 100 Mega Grupo S1', '2026-08-19 15:50:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `roteadores`
--

CREATE TABLE `roteadores` (
  `id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `ip_host` varchar(100) NOT NULL,
  `porta_api` int DEFAULT '8728',
  `usuario` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `usar_ssl` tinyint(1) DEFAULT '0',
  `status` varchar(20) DEFAULT 'desconectado',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `roteadores`
--

INSERT INTO `roteadores` (`id`, `nome`, `ip_host`, `porta_api`, `usuario`, `senha`, `usar_ssl`, `status`, `criado_em`) VALUES
(1, 'MikroTik Principal', 'd4440d2c5836.sn.mynetname.net', 8828, 'aplicacao', '81660848agape99334425', 0, 'desconectado', '2026-08-19 15:50:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `webhook_logs`
--

CREATE TABLE `webhook_logs` (
  `id` int NOT NULL,
  `tipo` varchar(50) DEFAULT 'webhook',
  `mensagem` text,
  `dados` longtext,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `administradores`
--
ALTER TABLE `administradores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf_cnpj` (`cpf_cnpj`),
  ADD UNIQUE KEY `pppoe_usuario` (`pppoe_usuario`),
  ADD KEY `plano_id` (`plano_id`),
  ADD KEY `roteador_id` (`roteador_id`);

--
-- Índices para tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `faturas`
--
ALTER TABLE `faturas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `plano_id` (`plano_id`),
  ADD KEY `idx_external_reference` (`external_reference`),
  ADD KEY `idx_gateway_status` (`gateway_status`);

--
-- Índices para tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Índices para tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `mikrotik_payment_history`
--
ALTER TABLE `mikrotik_payment_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_cli_ano_mes` (`cliente_id`,`ano`,`mes`);

--
-- Índices para tabela `planos`
--
ALTER TABLE `planos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `roteadores`
--
ALTER TABLE `roteadores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `webhook_logs`
--
ALTER TABLE `webhook_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `administradores`
--
ALTER TABLE `administradores`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `faturas`
--
ALTER TABLE `faturas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;

--
-- AUTO_INCREMENT de tabela `mikrotik_payment_history`
--
ALTER TABLE `mikrotik_payment_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;

--
-- AUTO_INCREMENT de tabela `planos`
--
ALTER TABLE `planos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `roteadores`
--
ALTER TABLE `roteadores`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `webhook_logs`
--
ALTER TABLE `webhook_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`plano_id`) REFERENCES `planos` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `clientes_ibfk_2` FOREIGN KEY (`roteador_id`) REFERENCES `roteadores` (`id`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `faturas`
--
ALTER TABLE `faturas`
  ADD CONSTRAINT `faturas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `faturas_ibfk_2` FOREIGN KEY (`plano_id`) REFERENCES `planos` (`id`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  ADD CONSTRAINT `historico_pagamentos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `mikrotik_payment_history`
--
ALTER TABLE `mikrotik_payment_history`
  ADD CONSTRAINT `mikrotik_payment_history_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
