<?php

/**
 * Serviço de Integração com Telegram Bot API
 */
class TelegramService {
    private string $botToken;
    private string $chatId;
    private bool $ativo;

    public function __construct() {
        $db = Database::getInstance();
        $stmt = $db->query("SELECT telegram_bot_token, telegram_chat_id, telegram_ativo FROM configuracoes WHERE id = 1");
        $config = $stmt->fetch();

        $this->botToken = $config['telegram_bot_token'] ?? '';
        $this->chatId = $config['telegram_chat_id'] ?? '';
        $this->ativo = !empty($config['telegram_ativo']);
    }

    /**
     * Enviar mensagem para o Telegram
     */
    public function sendMessage($message): bool {
        if (!$this->ativo || empty($this->botToken) || empty($this->chatId)) {
            return false;
        }

        $endpoint = "https://api.telegram.org/bot{$this->botToken}/sendMessage";
        $payload = [
            'chat_id' => $this->chatId,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];

        $ch = curl_init($endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
        curl_setopt($ch, CURLOPT_TIMEOUT, 6);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300) {
            Database::log('telegram', 'Notificação enviada ao Telegram com sucesso');
            return true;
        } else {
            Database::log('telegram', 'Erro ao enviar Telegram', ['code' => $httpCode, 'response' => $response]);
            return false;
        }
    }

    /**
     * Notificar pagamento no Telegram
     */
    public function notifyPaymentReceived($clienteNome, $valor, $faturaId, $forma = 'PIX') {
        $msg = "<b>💰 NOVO PAGAMENTO RECEBIDO!</b>\n\n";
        $msg .= "👤 <b>Cliente:</b> {$clienteNome}\n";
        $msg .= "💵 <b>Valor:</b> " . formatMoeda($valor) . "\n";
        $msg .= "📄 <b>Fatura:</b> #{$faturaId}\n";
        $msg .= "💳 <b>Forma:</b> {$forma}\n";
        $msg .= "⏰ <b>Data:</b> " . date('d/m/Y H:i:s') . "\n";

        return $this->sendMessage($msg);
    }
}
